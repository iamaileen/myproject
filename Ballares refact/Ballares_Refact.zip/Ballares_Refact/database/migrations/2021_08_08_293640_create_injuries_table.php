<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateInjuriesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('injuries', function (Blueprint $table) {
            $table->id();
            $table->string('injury_name');
            $table->string('injury_type');
            $table->string('injury_description');
            $table->timestamps();
        });

        Schema::create('animal_injury', function (Blueprint $table) {
            $table->unsignedBigInteger('animal_id')->nullable();
            $table->unsignedBigInteger('injury_id')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('injuries');
    }
}
