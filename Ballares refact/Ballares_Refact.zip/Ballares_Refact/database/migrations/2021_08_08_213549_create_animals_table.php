<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAnimalsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('animals', function (Blueprint $table) {
            $table->id();
            $table->string('animal_name');
            $table->string('animal_type');
            $table->string('animal_breed');
            $table->string('animal_gender');
            $table->unsignedBigInteger('animal_age');
            $table->string('img_path');
            $table->unsignedBigInteger('rescuer_id')->nullable();
            $table->Date('rescue_date')->nullable();
            $table->timestamps();
            $table->unsignedBigInteger('adopter_id')->nullable();
            $table->string('adopt_stat')->nullable();
            $table->unsignedBigInteger('personnel_id')->nullable();
            $table->foreign('rescuer_id')->references('id')->on('rescuers');
            $table->foreign('adopter_id')->references('id')->on('adopters');
            $table->foreign('personnel_id')->references('id')->on('personnels');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('animals');
    }
}
