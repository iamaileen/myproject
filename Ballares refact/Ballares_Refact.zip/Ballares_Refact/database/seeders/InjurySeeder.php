<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Injury;

class InjurySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
       $injuries = new \App\Models\Injury([
        'injury_name' => 'Q fever',
        'injury_type' => 'disease',
        'injury_description' => 'A widespread disease caused by the bacteria Coxiella burnetii, which is able to infect mammals, birds, reptiles and arthropods.',
        ]);
        $injuries->save();

        $injuries = new \App\Models\Injury([
        'injury_name' => 'Foot and mouth disease',
        'injury_type' => 'disease',
        'injury_description' => 'Foot and mouth disease (FMD) is a contagious viral disease that can spread very rapidly of cloven-hoofed animals.',
        ]);
        $injuries->save();

        $injuries = new \App\Models\Injury([
        'injury_name' => 'Canine distemper',
        'injury_type' => 'disease',
        'injury_description' => 'Canine distemper is caused by a very contagious virus.',
        ]);
        $injuries->save();

        $injuries = new \App\Models\Injury([
        'injury_name' => 'Poisoning',
        'injury_type' => 'injury',
        'injury_description' => 'Many plants, human medications, household chemicals and even common foods – grapes, onions, and chewing gum – can cause illness or death.',
        ]);
        $injuries->save();

        $injuries = new \App\Models\Injury([
        'injury_name' => 'Cat Bite Abscesses',
        'injury_type' => 'injury',
        'injury_description' => ' Thats because cat bites are like holes from hypodermic needles, the tissue closes over the wound and traps bacteria and contaminants.',
        ]);
        $injuries->save();
    }
}
