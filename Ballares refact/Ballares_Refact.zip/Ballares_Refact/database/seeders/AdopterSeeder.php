<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Adopter;

class AdopterSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $adopters = new \App\Models\Adopter([
        'adopter_name' => 'John',
        'adopter_contact' => '12345',
        'adopter_address' => 'Makati City',
        'adopter_age' => '21',
        'adopter_gender' => 'male',
        'user_id' => '4'
        ]);
        $adopters->save();

        $adopters = new \App\Models\Adopter([
        'adopter_name' => 'Kim',
        'adopter_contact' => '54321',
        'adopter_address' => 'Taguig City',
        'adopter_age' => '20',
        'adopter_gender' => 'female',
        'user_id' => '4'
        ]);
        $adopters->save();
    }
}
