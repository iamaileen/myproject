<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Rescuer;

class RescuerSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $rescuers = new\App\Models\Rescuer([
            'rescuer_name' => 'Jecille Laurilla',
            'rescuer_address' => 'Marikina City',
            'rescuer_contact' => '22212',
            'rescuer_age' => '24',
            'rescuer_gender' => 'female',
            'user_id' => '3',
        ]);
        $rescuers->save();

            $rescuers = new\App\Models\Rescuer([
            'rescuer_name' => 'Ana Melflores',
            'rescuer_address' => 'Pasig City',
            'rescuer_contact' => '12123',
            'rescuer_age' => '21',
            'rescuer_gender' => 'female',
            'user_id' => '3',
        ]);
        $rescuers->save();

            $rescuers = new\App\Models\Rescuer([
            'rescuer_name' => 'Karl Apacible',
            'rescuer_address' => 'Makati City',
            'rescuer_contact' => '72777',
            'rescuer_age' => '21',
            'rescuer_gender' => 'male',
            'user_id' => '3',
        ]);
        $rescuers->save();
    }
}
