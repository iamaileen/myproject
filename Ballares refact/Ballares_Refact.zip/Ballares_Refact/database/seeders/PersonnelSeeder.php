<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Personnel;

class PersonnelSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $personnels = new\App\Models\Personnel([
            'personnel_name' => 'Jane',
            'personnel_role' => 'Employee',
            'personnel_contact' => '13457',
            'personnel_address' => 'Pasay City',
            'personnel_gender' => 'female',
            'user_id' => '2',
        ]);
        $personnels->save();

        $personnels = new\App\Models\Personnel([
            'personnel_name' => 'Mia',
            'personnel_role' => 'Employee',
            'personnel_contact' => '44232',
            'personnel_address' => 'Pasig City',
            'personnel_gender' => 'female',
            'user_id' => '2',
        ]);
        $personnels->save();

    }
}
