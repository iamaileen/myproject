<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Animal;

class AnimalSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $animals = new \App\Models\Animal([
        'animal_name' => 'Betty',
        'animal_type' => 'Cat',
        'animal_breed' => 'Ragdoll',
        'animal_gender' => 'female',
        'animal_age' => '1',
        'img_path' => 'https://upload.wikimedia.org/wikipedia/commons/6/64/Ragdoll_from_Gatil_Ragbelas.jpg',
        ]);
        $animals->save();

        $animals = new \App\Models\Animal([
        'animal_name' => 'King',
        'animal_type' => 'Dog',
        'animal_breed' => 'Golden Retriever',
        'animal_gender' => 'male',
        'animal_age' => '1',
        'img_path' => 'https://www.petmd.com/sites/default/files/2020-11/picture-of-golden-retriever-dog_0.jpg',
        ]);
        $animals->save();
    
        $animals = new \App\Models\Animal([
        'animal_name' => 'Sweet',
        'animal_type' => 'Cat',
        'animal_breed' => 'Persian',
        'animal_gender' => 'female',
        'animal_age' => '2',
        'img_path' => 'https://vetstreet.brightspotcdn.com/dims4/default/5c40e17/2147483647/thumbnail/645x380/quality/90/?url=https%3A%2F%2Fvetstreet-brightspot.s3.amazonaws.com%2F51%2F45%2Fa7f47de448fabce6e4a908cb878d%2FPersian-AP-J6XREO-645sm3614.jpg',
        ]);
        $animals->save();

        $animals = new \App\Models\Animal([
        'animal_name' => 'Browny',
        'animal_type' => 'Dog',
        'animal_breed' => 'Bulldog',
        'animal_gender' => 'female',
        'animal_age' => '3',
        'img_path' => 'https://upload.wikimedia.org/wikipedia/commons/thumb/1/11/Bulldog_adult_male.jpg/220px-Bulldog_adult_male.jpg',
        ]);
        $animals->save();

        $animals = new \App\Models\Animal([
        'animal_name' => 'Mina',
        'animal_type' => 'Dog',
        'animal_breed' => 'Golden Retriever',
        'animal_gender' => 'female',
        'animal_age' => '4',
        'img_path' => 'https://upload.wikimedia.org/wikipedia/commons/c/ca/Pomeranian.JPG',
        ]);
        $animals->save();
    }
}
