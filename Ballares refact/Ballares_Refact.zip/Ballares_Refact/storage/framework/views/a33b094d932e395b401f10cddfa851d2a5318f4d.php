
<?php $__env->startSection('content'); ?>
    <div class = "card-header">
        Add Adopter Record
    </div>
        <div class = "card-body">
          <?php echo Form::open(['route' => 'adopters.store']); ?>

              <div class = "form-group">
                  <label for="adopter_name">Name</label>
                  <input type="text" name="adopter_name" class="form-control" placeholder="Enter Adopter Name"/>
                  <?php if($errors->has('adopter_name')): ?>
                        <div class="alert alert-danger">
                            <?php echo e($errors->first('adopter_name')); ?>

                        </div>
                    <?php endif; ?>
              </div>

              <div class = "from-group pt-3">
                  <label for="adopter_contact">Contact</label>
                  <input type="text" name="adopter_contact" class="form-control" placeholder="Enter Adopter Contact"/>
                  <?php if($errors->has('adopter_contact')): ?>
                        <div class="alert alert-danger">
                            <?php echo e($errors->first('adopter_contact')); ?>

                        </div>
                    <?php endif; ?>
              </div>

              <div class = "from-group pt-3">
                  <label for="adopter_address">Address</label>
                  <input type="text" name="adopter_address" class="form-control" placeholder="Enter Adopter Address"/>
                  <?php if($errors->has('adopter_address')): ?>
                        <div class="alert alert-danger">
                            <?php echo e($errors->first('adopter_address')); ?>

                        </div>
                    <?php endif; ?>
              </div>

              <div class = "from-group pt-3">
                  <label for="adopter_age">Age</label>
                  <input type="integer" name="adopter_age" class="form-control" placeholder="Enter adopter age"/>
                  <?php if($errors->has('adopter_age')): ?>
                        <div class="alert alert-danger">
                            <?php echo e($errors->first('adopter_age')); ?>

                        </div>
                    <?php endif; ?>
              </div>

              <div class = "from-group pt-3">
                  <label for="adopter_gender">Gender</label><br>
                  <label for="male">
                  <input type="radio" name="adopter_gender" value="male">
                  Male</label> 
                  <label for="female">
                  <input type="radio" name="adopter_gender" value="female">
                  Female</label> 
                  <?php if($errors->has('adopter_gender')): ?>
                        <div class="alert alert-danger">
                            <?php echo e($errors->first('adopter_gender')); ?>

                        </div>
                    <?php endif; ?>
              </div>
              <div class = "from-group pt-3">
                    <label>Animal for Adoption</label>
                    <?php $__currentLoopData = $adopt_animal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adopt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($adopt->injury_name == null): ?>
                        <div class="form-check form-check-block">
                            <?php echo Form::checkbox('id[]', $adopt->id, null, array('class' => 'form-check-input','id'=>'animal_id')); ?>

                            <?php echo Form::label('animal_name', $adopt->animal_name, array('class' => 'form-check-label')); ?>

                        </div>
                        <?php endif; ?>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                     <?php if($errors->has('id')): ?>
                        <div class="alert alert-danger">
                            <?php echo e($errors->first('id')); ?>

                        </div>
                    <?php endif; ?>
                </div>

              
              <div class="pr-2 pt-4">
                  <button type="submit" class="btn btn-success">Create</button>
                  <a href="<?php echo e(route('adopters.index')); ?>" type="submit" class="btn btn-primary">Back</a>
              </div>
                          
    </div>
        <?php echo csrf_field(); ?>
        <?php echo Form::close(); ?>

                
<?php $__env->stopSection(); ?>
                    
<?php echo $__env->make('layouts.design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Josh\JLT\resources\views/adopters/create.blade.php ENDPATH**/ ?>