

<?php $__env->startSection('content'); ?>
<div class="container pt-3 ">
<body style="background-color:GhostWhite;">
		<div class="row">
			<div class="col-md-15 col-md-offset-1">
				<h2>Admin Profile</h2>
			<?php if($message = Session::get('success')): ?>
				<div class="alert alert-success alert-block">
					<button type="button" class="close" data-dismiss="alert">×</button> 
						<strong><?php echo e($message); ?></strong>
				</div>
			<?php endif; ?>
			<div class="row">
				<div class="col-md-15 col-md-offset-1">
					<table class="table table-bordered table-responsive table-striped" style="text-align:center">
						<thead>
							<th>ID</th>
							<th>Name</th>
                            <th>Email</th>
							<th>Role</th>
							<th>Action</th>
						</thead>
						<tbody>
                            <tr>
                                <td><?php echo e($admin->id); ?></td>
                                <td><?php echo e($admin->name); ?></td>
                                <td><?php echo e($admin->email); ?></td>
                                <td><?php echo e($admin->role); ?></td>
                                <td><a href="<?php echo e(route('admin.edit',$admin->id)); ?>" data-toggle="modal" class="btn btn-success"><i class='fa fa-edit'></i> Edit</a></td>
                            </tr>
						</tbody>
					</table>
				</div>
			</div>
		</div>
</body>
<?php $__env->stopSection(); ?>	
</html>
<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Josh\JLT\resources\views/users/dashboard.blade.php ENDPATH**/ ?>