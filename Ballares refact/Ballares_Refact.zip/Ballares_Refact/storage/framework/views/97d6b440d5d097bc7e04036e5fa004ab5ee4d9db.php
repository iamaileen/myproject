

<?php $__env->startSection('content'); ?>
<div class="container pt-3 ">
<body style="background-color:GhostWhite;">
		<div class="row">
			<div class="col-md-15 col-md-offset-1">
				<h2>Animals Table
					<a class="btn btn-primary pull-right" type="button" href="<?php echo e(route('animals.create')); ?>" ><i class="fa fa-plus"></i> Animal</a>
				</h2>
			<?php if($message = Session::get('success')): ?>
				<div class="alert alert-success alert-block">
					<button type="button" class="close" data-dismiss="alert">×</button> 
						<strong><?php echo e($message); ?></strong>
				</div>
			<?php endif; ?>
			<div class="row">
				<div class="col-md-15 col-md-offset-1">
					<table class="table table-bordered table-responsive table-striped" style="text-align:center">

						<thead>
							<th>ID</th>
							<th>Image</th>
							<th>Name</th>
							<th>Type</th>
							<th>Breed</th>
							<th>Gender</th>
							<th>Age</th>
							<th>Injury/Disease</th>
							<th>Rescuer</th>
							<th>Date Rescued</th>
							<th>Adopt Status</th>
							<th>Action</th>
						</thead>
						<tbody>
							<?php $__currentLoopData = $animals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $animal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e($animal->id); ?></td>
									<td><img src="<?php echo e(asset($animal->img_path)); ?>" width="100px" height="100px"></td>
									<td><?php echo e($animal->animal_name); ?></td>
									<td><?php echo e($animal->animal_type); ?></td>
									<td><?php echo e($animal->animal_breed); ?></td>
									<td><?php echo e($animal->animal_gender); ?></td>
									<td><?php echo e($animal->animal_age); ?></td>
									<td>
									<?php $__currentLoopData = $animal_injury; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $injure): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php if($animal->id == $injure->animal_id): ?>
											- <?php echo e($injure->injury_name); ?> <br>
										<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</td>
									<td><?php echo e($animal->rescuer_name); ?></td>
									<td><?php echo e($animal->rescue_date); ?></td>
									<td><?php echo e($animal->adopt_stat); ?></td>
									
									<?php echo Form::open(['method' => 'DELETE', 'route' => ['animals.destroy', $animal->id]]); ?>

									<td>
										<a href="<?php echo e(route('animals.edit',$animal->id)); ?>" data-toggle="modal" class="btn btn-success"><i class='fa fa-edit'></i> Edit</a> 
										<button type="submit" data-toggle="modal" class="btn btn-danger"><i class='fa fa-trash'></i> Delete</button>		
									</td>
									<?php echo Form::close(); ?>

								</div>
									
								</tr>
							
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
</body>
<?php $__env->stopSection(); ?>	
</html>

<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Josh\JLT\resources\views/animals/index.blade.php ENDPATH**/ ?>