<a href="javascript:void(0)" data-toggle="tooltip" data-id="<?php echo e($id); ?>" data-original-title="Edit" class="edit btn btn-success edit">
    Edit
</a>
<a href="javascript:void(0);" id="delete-animal" data-toggle="tooltip" data-original-title="Delete" data-id="<?php echo e($id); ?>" class="delete btn btn-danger">
    Delete
</a><?php /**PATH C:\Ballares_Refact\resources\views/data_animal/action.blade.php ENDPATH**/ ?>