
<?php $__env->startSection('content'); ?>
    <div class = "card-header">
        Edit The Admin
    </div>
    <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class = "card-body">
          <?php echo e(Form::model($user,['method'=>'PATCH','route' => ['admin.update', $user->id]])); ?>


          
              <div class = "form-group">
                  <label for="name">Name:</label>
                  <?php echo e(Form::text('name',null,array('class'=>'form-control','id'=>'name'))); ?>

              </div>

              <div class = "form-group">
                  <label for="email">Email:</label>
                  <?php echo e(Form::text('email',null,array('class'=>'form-control','id'=>'email'))); ?>

              </div>
              
              <div class="pr-2 pt-2">
                <a href="<?php echo e(route('multiuser')); ?>" address="submit" class="btn btn-primary">Back</a>
                  <button address="submit" class="btn btn-success">Update</button>
                  
              </div>
                          
    </div>
        <?php echo csrf_field(); ?>
        <?php echo Form::close(); ?>

                
<?php $__env->stopSection(); ?>
                    
<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Ballares_Refact\resources\views/users/edit.blade.php ENDPATH**/ ?>