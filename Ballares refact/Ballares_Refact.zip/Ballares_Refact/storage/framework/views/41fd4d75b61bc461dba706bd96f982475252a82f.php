
<?php $__env->startSection('content'); ?>
    <div class = "card-header">
        Send Email
    </div>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <div class = "card-body">
        <?php echo Form::open(['route' => 'inquiries.store']); ?>

              <div class = "form-group">
                  <label for="inquiry_name">Name</label>
                  <input type="text" name="inquiry_name" class="form-control" placeholder="Enter Name" value="<?php echo e(old('inquiry_name')); ?>" required/>
              </div>

              <div class = "from-group pt-3">
                  <label for="inquiry_email">Email Address<input type="text" name="inquiry_email" class="form-control" placeholder="sample@gmail.com" value="<?php echo e(old('inquiry_name')); ?>" required/>
              </div>

              <div class = "from-group pt-3">
                  <label for="inquiry_phone">Phone</label>
                  <input type="text" name="inquiry_phone" class="form-control" placeholder="+63 --- ---- ---" value="<?php echo e(old('inquiry_name')); ?>" required/>
              </div>

              <div class = "from-group pt-3">
                  <label for="inquiry_subject">Subject</label>
                  <input type="text" name="inquiry_subject" class="form-control" placeholder="Subject" value="<?php echo e(old('inquiry_name')); ?>" required/>
              </div>
              
              <div class = "from-group pt-3">
                  <label for="inquiry_message">Message</label>
                  <textarea name="inquiry_message" class="form-control" rows="5" placeholder="Message" value="<?php echo e(old('inquiry_name')); ?>" required></textarea>
              </div>
              
              <div class="pr-2 pt-4">
                  <button type="submit" class="btn btn-success">Create</button>
                  <a href="<?php echo e(url('/')); ?>" type="submit" class="btn btn-primary">Back</a>   
            </div>
    </div>
         <?php echo csrf_field(); ?>
        <?php echo Form::close(); ?>           
<?php $__env->stopSection(); ?>
                    
<?php echo $__env->make('layouts.design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Josh\JLT\resources\views/inquiries/create.blade.php ENDPATH**/ ?>