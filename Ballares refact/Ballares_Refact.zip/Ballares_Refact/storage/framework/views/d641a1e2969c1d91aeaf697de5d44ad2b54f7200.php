
<?php $__env->startSection('content'); ?>
	<table id="elbat">
		<thead>
			<tr>
				<th>Animal Name</th>
				<th>Breed</th>
				<th>Type</th>
				<th>Gender</th>
				<th>Age</th>
				<th>Rescue Date</th>
                <th>Status</th>
                <th>Image</th>
                
			</tr>
		</thead>
		<tbody>
			<tr>
				<td><?php echo e($animal->animal_name); ?></td>
				<td><?php echo e($animal->animal_breed); ?></td>
				<td><?php echo e($animal->animal_type); ?></td>
				<td><?php echo e($animal->animal_gender); ?></td>
				<td><?php echo e($animal->animal_age); ?></td>
                <td><?php echo e($animal->rescue_date); ?></td>
                <td><?php echo e($animal->adopt_stat); ?></td>
				<td><img src="<?php echo e(asset($animal->img_path)); ?>" width="100px" height="100px"></td>
			</tr>
		</tbody>
	</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Josh\JLT\resources\views/show.blade.php ENDPATH**/ ?>