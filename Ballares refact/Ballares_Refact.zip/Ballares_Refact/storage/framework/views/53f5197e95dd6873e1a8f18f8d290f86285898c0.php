<nav style="background-color:#233342" class="navbar navbar-default">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" style="color:233342" href=" ">Animal Shelter</a>
    </div>
     <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav navbar-right">
      <li>

        <li class="dropdown" >
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" style="background-color:#CE8054" ><i style="color:white" class="fas fa-user-circle"></i><span style="color:white" class="caret"></span></a>
          <ul style="background-color:#CE8054" class="dropdown-menu">
          
          <?php if(Auth::user()->role == "adopter"): ?>
      <li class="nav-item">
        <a href=""><?php echo e(Auth::user()->name); ?></a>
      </li> 
        <li class="nav-item">
        <form method="POST" action="<?php echo e(route('logout')); ?>">
          <?php echo csrf_field(); ?>
          <button type="submit" class="btn btn-danger"><?php echo e(__('Logout')); ?></button>          
        </form>
        </li> 

        <?php elseif(Auth::user()->role == "employee"): ?>
              <li class="nav-item" position="topnav-right">
                <a href="" class="nav-link"><?php echo e(Auth::user()->name); ?></a>
              </li> 
                <li class="nav-item">
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                  <?php echo csrf_field(); ?>
                  <button type="submit" class="btn btn-danger"><?php echo e(__('Logout')); ?></button>          
                </form>
                </li> 
        <?php elseif(Auth::user()->role == "rescuer"): ?>

      <li class="nav-item">
        <a href=''><?php echo e(Auth::user()->name); ?></a>
      </li> 
        <li class="nav-item">
        <form method="POST" action="<?php echo e(route('logout')); ?>">
          <?php echo csrf_field(); ?>
          <button type="submit" class="btn btn-danger"><?php echo e(__('Logout')); ?></button>          
        </form>
        </li> 
      
      <?php else: ?>
        <li class="nav-item">
          <a class="nav-link" aria-current="page" href="<?php echo e(route('animals.index')); ?>">Animals</a>
        </li>
        
        <li class="nav-item">
          <a class="nav-link" aria-current="page" href="<?php echo e(route('rescuers.index')); ?>">Rescuers</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" aria-current="page" href="<?php echo e(route('injuries.index')); ?>">Injury/Disease</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" aria-current="page" href="<?php echo e(route('adopters.index')); ?>">Adopters</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" aria-current="page" href="<?php echo e(route('personnels.index')); ?>">Personnels</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" aria-current="page" href="<?php echo e(route('messages.index')); ?>">Messages</a>
        </li>
        
        <li class="nav-item">
        <form method="POST" action="<?php echo e(route('logout')); ?>">
          <?php echo csrf_field(); ?>
          <button type="submit" class="btn btn-danger"><?php echo e(__('Logout')); ?></button>          
        </form>
        </li> 
      <?php endif; ?>
          </ul>
        </li> 
      </ul>
    </div>
  </div>
</nav><?php /**PATH C:\Ballares_Refact\resources\views/partials/_header.blade.php ENDPATH**/ ?>