
<?php $__env->startSection('title', 'Animal Shelter'); ?>
<?php $__env->startSection('content'); ?>


<h1>Injuries and Diseases Table </h1>
<div class="row">
<div class="col-md-10 mt-4 mb-8"><button type="button" id="addinjury" class="btn btn-success">Add</button></div>
	<div class="col-md-15 col-md-offset-1">
        <table id="injuries" class="table table-bordered table-responsive table-striped" style="text-align:center">
			    <thead >
				    <tr>
					    <th>ID</th>
					    <th>NAME</th>
					    <th>TYPE</th>
					    <th>DESCRIPTION</th>
					    <th>ACTION</th>
				    </tr>
			    </thead>
	    </table>
    <div class="modal fade" id="ipakita" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title" id="ajaxBookModel"></h4>
          </div>
          <div class="modal-body">
            <form action="javascript:void(0)" id="addEditBookForm" name="addEditBookForm" class="form-horizontal" method="POST">
              <input type="hidden" name="id" id="id">
              <div class="form-group">
                <label for="name" class="col-sm-1 control-label">Name</label>
                <div class="col-sm-12">
                  <input type="text" class="form-control" id="injury_name" name="injury_name" placeholder="Enter Name" maxlength="50" required="">
                </div>
              </div>  
              <div class="form-group">
                <label for="name" class="col-sm-1 control-label">Type</label>
                <div class="col-sm-12">
                  <input type="text" class="form-control" id="injury_type" name="injury_type" placeholder="Enter Type" maxlength="50" required="">
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-1 control-label">Description</label>
                <div class="col-sm-12">
                  <input type="text" class="form-control" id="injury_description" name="injury_description" placeholder="Enter Description" required="">
                </div>
              </div>
              <div class="col-sm-offset-5">
                <button type="submit" class="btn btn-success" id="save_injury" value="addinjury">Save changes
                </button>
                <a href="<?php echo e(route('data_injury.index')); ?>" type="submit" class="btn btn-primary">Back</a>
              </div>
            </form>
          </div>
          <div class="modal-footer">
            
          </div>
        </div>
      </div>
    </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function() {
	$.ajaxSetup({
        headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
      $('#injuries').DataTable({
            processing: true,
            serverSide: true,
            ajax: "<?php echo e(url('injury')); ?>",
            columns: [
              { data: 'id', name: 'id' },
			  { data: 'injury_name', name: 'injury_name' },
              { data: 'injury_type', name: 'injury_type' },
              { data: 'injury_description', name: 'injury_description' },
			  {data: 'Actions', name: 'Actions',orderable:false,},
             ]
        });

        $('body').on('click', '.delete', function () {
       if (confirm("Delete Record?") == true) {
        var id = $(this).data('id');
         
        // ajaxs
        $.ajax({
			type:'POST',
            url: "<?php echo e(url('delete-injury')); ?>",
            data: { id: id },
            dataType: 'json',
            success: function(res){
              var oTable = $('#injuries').dataTable();
              oTable.fnDraw(false);
           }
        });
       }
    });

    $('#addinjury').click(function () {
       $('#addEditBookForm').trigger("reset");
       $('#ajaxBookModel').html("Add Injuries or Diseases");
       $('#ipakita').modal('show');
    });

    $('body').on('click', '.edit', function () {
        var id = $(this).data('id');
         
        // ajax
        $.ajax({
            type:"POST",
            url: "<?php echo e(url('edit-injury')); ?>",
            data: { id: id },
            dataType: 'json',
            success: function(res){
              $('#ajaxBookModel').html("Edit Book");
              $('#ipakita').modal('show');
              $('#id').val(res.id);
              $('#injury_name').val(res.injury_name);
              $('#injury_type').val(res.injury_type);
              $('#injury_description').val(res.injury_description);
           }
        });
    });

    $('body').on('click', '#save_injury', function (event) {
          var id = $("#id").val();
          var injury_name = $("#injury_name").val();
          var injury_type = $("#injury_type").val();
          var injury_description = $("#injury_description").val();
          $("#save_injury").html('Please Wait...');
          $("#save_injury"). attr("disabled", true);
         
          // ajax
          $.ajax({
            type:"POST",
            url: "<?php echo e(url('add-injury')); ?>",
            data: {
              id:id,
              injury_name:injury_name,
              injury_type:injury_type,
              injury_description:injury_description,
            },
            dataType: 'json',
            success: function(res){
            $("#ajax-book-model").modal('hide');
            var oTable = $('#injuries').dataTable();
            oTable.fnDraw(false);
            $("#save_injury").html('Submit');
            $("#save_injury"). attr("disabled", false);
           }
        });
    });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Ballares_Refact\resources\views/data_injury/index.blade.php ENDPATH**/ ?>