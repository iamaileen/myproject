
<?php $__env->startSection('content'); ?>
    <div class = "card-header">
        Edit Rescuer Record
    </div>
    <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class = "card-body">
          <?php echo e(Form::model($rescuer,['method'=>'PATCH','route' => ['rescuers.update', $rescuer->id]])); ?>


          
              <div class = "form-group">
                  <label for="rescuer_name">Name</label>
                  <?php echo e(Form::text('rescuer_name',null,array('class'=>'form-control','id'=>'rescuer_name'))); ?>

              </div>

              <div class = "from-group pt-3">
                  <label for="rescuer_gender">Gender</label><br>
                  <label>
                  <?php if($rescuer->rescuer_gender == 'male'): ?>
                    <?php echo e(Form::radio('rescuer_gender', 'male', true)); ?>

                    Male</label> 
                    <label>
                    <?php echo e(Form::radio('rescuer_gender', 'female', false)); ?>

                    Female</label> 
                  <?php else: ?>
                    <?php echo e(Form::radio('rescuer_gender', 'male', false)); ?>

                    Male</label> 
                    <label>
                    <?php echo e(Form::radio('rescuer_gender', 'female', true)); ?>

                    Female</label> 
                  <?php endif; ?>
              </div>

              <div class = "from-group pt-3">
                  <label for="rescuer_address">Address</label>
                  <?php echo e(Form::text('rescuer_address',null,array('class'=>'form-control','id'=>'rescuer_address'))); ?>

              </div>

              <div class = "from-group pt-3">
                  <label for="rescuer_contact">contact</label>
                  <?php echo e(Form::text('rescuer_contact',null,array('class'=>'form-control','id'=>'rescuer_contact'))); ?>

              </div>

              <div class = "from-group pt-3">
                  <label for="rescuer_age">Age</label>
                  <?php echo e(Form::text('rescuer_age',null,array('class'=>'form-control','id'=>'rescuer_age'))); ?>

              </div>

              
              <div class="pr-2 pt-4">
                  <button address="submit" class="btn btn-success">Update</button>
                  <a href="<?php echo e(url()->previous()); ?>" address="submit" class="btn btn-primary">Back</a>
              </div>
                          
    </div>
        <?php echo csrf_field(); ?>
        <?php echo Form::close(); ?>

                
<?php $__env->stopSection(); ?>
                    
<?php echo $__env->make('layouts.design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Josh\JLT\resources\views/rescuers/edit.blade.php ENDPATH**/ ?>