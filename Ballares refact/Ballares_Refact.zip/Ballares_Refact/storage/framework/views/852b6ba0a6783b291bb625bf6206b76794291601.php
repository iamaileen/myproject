
<?php $__env->startSection('content'); ?>
    <div class = "card-header">
        Add Animal Record
    </div>
        <!-- <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?> -->
        <div class = "card-body">
          <?php echo Form::open(['route' => 'animals.store', 'files' => true]); ?>

              <div class = "form-group">
                  <label for="animal_name">Name</label>
                  <?php echo e(Form::text('animal_name',null,array('class'=>'form-control', 'placeholder'=>'Enter animal name'))); ?>

                  <?php if($errors->has('animal_name')): ?>
                        <div class="alert alert-danger">
                            <?php echo e($errors->first('animal_name')); ?>

                        </div>
                    <?php endif; ?>
              </div>

              <div class = "from-group pt-3">
              <label for="animal_type">Type</label><br>     
                <label for="Cat">Cat</label>
                <?php echo e(Form::radio('animal_type', 'cat', false)); ?>

                <label for="Dog">Dog</label>
                <?php echo e(Form::radio('animal_type', 'dog', false)); ?>

                  <?php if($errors->has('animal_type')): ?>
                        <div class="alert alert-danger">
                            <?php echo e($errors->first('animal_type')); ?>

                        </div>
                    <?php endif; ?>
              </div>

              <div class = "from-group pt-3">
              <label for="animal_gender">Gender</label><br>     
                <label for="animal_gender">Male</label>
                <?php echo e(Form::radio('animal_gender', 'male', false)); ?>

                <label for="animal_gender">Female</label>
                <?php echo e(Form::radio('animal_gender', 'female', false)); ?>

                  <?php if($errors->has('animal_gender')): ?>
                        <div class="alert alert-danger">
                            <?php echo e($errors->first('animal_gender')); ?>

                        </div>
                    <?php endif; ?>
              </div>

              <div class = "from-group pt-3">
                  <label for="animal_breed">Breed</label>
                  <?php echo e(Form::text('animal_breed',null,array('class'=>'form-control', 'placeholder'=>'Enter animal breed'))); ?>

                  <?php if($errors->has('animal_breed')): ?>
                        <div class="alert alert-danger">
                            <?php echo e($errors->first('animal_breed')); ?>

                        </div>
                    <?php endif; ?>
              </div>

              <div class = "from-group pt-3">
                  <label for="animal_age">Age</label>
                  <?php echo e(Form::text('animal_age',null,array('class'=>'form-control', 'placeholder'=>'Enter animal age'))); ?>

                  <?php if($errors->has('animal_age')): ?>
                        <div class="alert alert-danger">
                            <?php echo e($errors->first('animal_age')); ?>

                        </div>
                    <?php endif; ?>
              </div>
                
              <div class = "from-group pt-3">
                    <label>Injury</label>
                    <?php $__currentLoopData = $injure; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $desc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-check form-check-block">
                            <?php echo Form::checkbox('injury_id[]',$id, null, array('class' => 'form-check-input','id'=>'description')); ?>

                            <?php echo Form::label('description', $desc, array('class' => 'form-check-label')); ?>

                        </div>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                </div>
              <div>
                    <br><label for="rescuer_name">Rescuer</label>
                    <?php echo Form::select('rescuer_id', $rescuer, null,['class' => 'form-control', 'rescuer_id' => 'rescuer_id', 
                    'placeholder' => 'Select Rescuer']); ?>

                    <?php if($errors->has('rescuer_id')): ?>
                        <div class="alert alert-danger">
                            <?php echo e($errors->first('rescuer_id')); ?>

                        </div>
                    <?php endif; ?>
              </div>
                        
              <div class = "from-group pt-3">
                  <label for="rescue_date">Date Rescued</label>
                  <?php echo e(Form::date('rescue_date',null,array('class'=>'form-control'))); ?>

                  <?php if($errors->has('rescue_date')): ?>
                        <div class="alert alert-danger">
                            <?php echo e($errors->first('rescue_date')); ?>

                        </div>
                    <?php endif; ?>
              </div>

              <div class="from-group pt-3">
                  <label for="image"  class="control-label">Choose image</label>
                  <input type="file" class="form-control" id="image" name="img_path"/>
                  <?php if($errors->has('img_path')): ?>
                        <div class="alert alert-danger">
                            <?php echo e($errors->first('img_path')); ?>

                        </div>
                    <?php endif; ?>
              </div>

              <div class="pr-2 pt-4">
                  <button type="submit" class="btn btn-success">Create</button>
                  <a href="<?php echo e(route('animals.index')); ?>" type="submit" class="btn btn-primary">Back</a>
              </div>
                          
    </div>
        <?php echo csrf_field(); ?>
        <?php echo Form::close(); ?>

                
<?php $__env->stopSection(); ?>
                    
<?php echo $__env->make('layouts.design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Josh\JLT\resources\views/animals/create.blade.php ENDPATH**/ ?>