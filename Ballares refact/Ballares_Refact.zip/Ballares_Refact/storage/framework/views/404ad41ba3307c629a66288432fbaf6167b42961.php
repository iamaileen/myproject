
<?php $__env->startSection('content'); ?>
  <h1>Search</h1>
    There are <?php echo e($results->count()); ?> results.
    <?php $__currentLoopData = $results->groupByType(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $modelSearchResults): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <h2><?php echo e($type); ?></h2>
      <?php $__currentLoopData = $modelSearchResults; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $searchResult): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <ul>
          <li>
            <a href="<?php echo e($searchResult->url); ?>"><?php echo e($searchResult->title); ?></a>
          </li>
        </ul>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Josh\JLT\resources\views/search.blade.php ENDPATH**/ ?>