<!DOCTYPE html>
<html lang="en">
<head>

    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
</head>
<body style="background-color:Lavender">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="<?php echo e(route('animals.index')); ?>">JLT Shelter </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">

      <?php if(Auth::user()->role == "adopter"): ?>
      <li class="nav-item">
        <a href=""><?php echo e(Auth::user()->name); ?></a>
      </li> 
        <li class="nav-item">
        <form method="POST" action="<?php echo e(route('logout')); ?>">
          <?php echo csrf_field(); ?>
          <button type="submit" class="btn btn-danger"><?php echo e(__('Logout')); ?></button>          
        </form>
        </li> 

        <?php elseif(Auth::user()->role == "employee"): ?>
              <li class="nav-item" position="topnav-right">
                <a href="" class="nav-link"><?php echo e(Auth::user()->name); ?></a>
              </li> 
                <li class="nav-item">
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                  <?php echo csrf_field(); ?>
                  <button type="submit" class="btn btn-danger"><?php echo e(__('Logout')); ?></button>          
                </form>
                </li> 
        <?php elseif(Auth::user()->role == "rescuer"): ?>

      <li class="nav-item">
        <a href=''><?php echo e(Auth::user()->name); ?></a>
      </li> 
        <li class="nav-item">
        <form method="POST" action="<?php echo e(route('logout')); ?>">
          <?php echo csrf_field(); ?>
          <button type="submit" class="btn btn-danger"><?php echo e(__('Logout')); ?></button>          
        </form>
        </li> 
      
      <?php elseif(Auth::user()->role == "admin"): ?>
        <li class="nav-item">
          <a class="nav-link" aria-current="page" href="<?php echo e(route('animals.index')); ?>">Animals</a>
        </li>
        
        <li class="nav-item">
          <a class="nav-link" aria-current="page" href="<?php echo e(route('rescuers.index')); ?>">Rescuers</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" aria-current="page" href="<?php echo e(route('injuries.index')); ?>">Injury/Disease</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" aria-current="page" href="<?php echo e(route('adopters.index')); ?>">Adopters</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" aria-current="page" href="<?php echo e(route('personnels.index')); ?>">Personnels</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" aria-current="page" href="<?php echo e(route('inquiries.index')); ?>">Inquiries</a>
        </li>
        
        <li class="nav-item">
        <form method="POST" action="<?php echo e(route('logout')); ?>">
          <?php echo csrf_field(); ?>
          <button type="submit" class="btn btn-danger"><?php echo e(__('Logout')); ?></button>          
        </form>
        </li> 
      <?php endif; ?>
      </ul>
    </div>
    
  </div>
</nav>
    <?php echo $__env->yieldContent('content'); ?>

</body>
</html><?php /**PATH C:\Users\Josh\JLT\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>