<?php echo e($slot); ?>

<?php /**PATH C:\Ballares_Refact\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>