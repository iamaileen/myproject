
<?php $__env->startSection('content'); ?>
    <div class = "card-header">
        Add Rescuers Record
    </div>
        <div class = "card-body">
          <?php echo Form::open(['route' => 'rescuers.store', 'files' => true]); ?>

              <div class = "form-group">
                  <label for="rescuer_name">Name</label>
                  <input type="text" name="rescuer_name" class="form-control" placeholder="Enter Rescuer Name"/>
                  <?php if($errors->has('rescuer_name')): ?>
                        <div class="alert alert-danger">
                            <?php echo e($errors->first('rescuer_name')); ?>

                        </div>
                    <?php endif; ?>
              </div>

              <div class = "from-group pt-3">
                  <label for="rescuer_type">Address</label>
                    <input type="text" name="rescuer_address" class="form-control" placeholder="Rescuer Address"/>
                  <?php if($errors->has('rescuer_address')): ?>
                        <div class="alert alert-danger">
                            <?php echo e($errors->first('rescuer_address')); ?>

                        </div>
                    <?php endif; ?>
                </div>

              <div class = "from-group pt-3">
                  <label for="rescuer_age">Age</label>
                  <input type="text" name="rescuer_age" class="form-control" placeholder="Enter Rescuer Age"/>
                  <?php if($errors->has('rescuer_age')): ?>
                        <div class="alert alert-danger">
                            <?php echo e($errors->first('rescuer_age')); ?>

                        </div>
                    <?php endif; ?>
              </div>

              <div class = "from-group pt-3">
                  <label for="rescuer_gender">Gender</label><br>
                  <label for="male">Male</label> <input type="radio" name="rescuer_gender" value="male">
                  <label for="female">Female</label> <input type="radio" name="rescuer_gender" value="female">
                  <?php if($errors->has('rescuer_gender')): ?>
                        <div class="alert alert-danger">
                            <?php echo e($errors->first('rescuer_gender')); ?>

                        </div>
                    <?php endif; ?>
              </div>

              <div class = "from-group pt-3">
                  <label for="rescuer_breed">Contact</label>
                  <input type="text" name="rescuer_contact" class="form-control" placeholder="Enter Rescuer Contact"/>
                  <?php if($errors->has('rescuer_contact')): ?>
                        <div class="alert alert-danger">
                            <?php echo e($errors->first('rescuer_contact')); ?>

                        </div>
                    <?php endif; ?>
              </div>
              
              <div class="pr-2 pt-4">
                  <button type="submit" class="btn btn-success">Create</button>
                  <a href="<?php echo e(route('rescuers.index')); ?>" type="submit" class="btn btn-primary">Back</a>
              </div>
                          
    </div>
        <?php echo csrf_field(); ?>
        <?php echo Form::close(); ?>

                
<?php $__env->stopSection(); ?>
                    
<?php echo $__env->make('layouts.design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Ballares_Refact\resources\views/rescuers/create.blade.php ENDPATH**/ ?>