

<?php $__env->startSection('content'); ?>
<div class="container pt-3 ">
<body style="background-color:GhostWhite;">
		<div class="row">
			<div class="col-md-15 col-md-offset-1">
				<h2>Rescuers Table
					<a class="btn btn-primary pull-right" type="button" href="<?php echo e(route('rescuers.create')); ?>" ><i class="fa fa-plus"></i>	Rescuer</a>
				</h2>
			<?php if($message = Session::get('success')): ?>
				<div class="alert alert-success alert-block">
					<button type="button" class="close" data-dismiss="alert">×</button> 
						<strong><?php echo e($message); ?></strong>
				</div>
			<?php endif; ?>
			<div class="row">
				<div class="col-md-15 col-md-offset-1">
					<table class="table table-bordered table-responsive table-striped" style="text-align:center">
						<thead>
							<th>ID</th>
							<th>Name</th>
							<th>Address</th>
							<th>Contact</th>
							<th>Age</th>
							<th>Gender</th>
							<th>Action</th>
						</thead>
						<tbody>
							<?php $__currentLoopData = $rescuers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rescuer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
								<!-- <?php echo e(dump(asset($rescuer->img_path))); ?> -->
									<td><?php echo e($rescuer->id); ?></td>
									<td><?php echo e($rescuer->rescuer_name); ?></td>
									<td><?php echo e($rescuer->rescuer_address); ?></td>
									<td><?php echo e($rescuer->rescuer_contact); ?></td>
									<td><?php echo e($rescuer->rescuer_age); ?></td>
									<td><?php echo e($rescuer->rescuer_gender); ?></td>
								<?php echo Form::open(['method' => 'DELETE', 'route' => ['rescuers.destroy', $rescuer->id]]); ?>

									<td><a href="<?php echo e(route('rescuers.edit',$rescuer->id)); ?>" data-toggle="modal" class="btn btn-success"><i class='fa fa-edit'></i> Edit</a> 
									<button type="submit" data-toggle="modal" class="btn btn-danger"><i class='fa fa-trash'></i> Delete</button>		
									<?php echo Form::close(); ?>

									</td>
								</div>
									
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
</body>
<?php $__env->stopSection(); ?>	
</html>
<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Josh\JLT\resources\views/rescuers/index.blade.php ENDPATH**/ ?>