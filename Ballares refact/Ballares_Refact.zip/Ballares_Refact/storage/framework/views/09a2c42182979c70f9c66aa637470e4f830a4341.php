<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Animal Shelter</title>

    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>


    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
   
       
        <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    <style>
        #table {font-family: Arial, Helvetica, sans-serif; border-collapse: collapse; width: 90%; margin-left: auto; margin-right: auto; margin-top: 5%;}
        #table td, #table th {border: 3px solid #233342; text-align: center;}
        #table tr:hover {background-color: #CE8054;}
        #table th {padding-top: 12px;padding-bottom: 12px; background-color: #4B2B31; color: white;}


    </style>

    <style>
        body {
      color: #233342;
     background-image: url('https://wallpaperaccess.com/full/214614.jpg');
      background-repeat: no-repeat;
      background-size: cover;
      font-family: 'Varela Round', sans-serif;
      font-size: 20px;
      text-decoration-color: darkgrey;
      text-decoration-style: wavy;
    }
    </style>


</head>
<body style="background-color:palegreen;">
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    Animal Shelter
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">
                        <form class="navbar-form navbar-left" method="POST" role="search" action="<?php echo e(route('search')); ?>">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <input type="text" name="search" placeholder="Search Animals">
                            <button type="submit" class="fa fa-search" style="padding: 10px;"></button>
                        </form>
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <?php if(Auth::check()): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="/">Home</a>
                            </li>
                            <li>
                                <form method="POST" action="<?php echo e(route('logout')); ?>">
                                    <?php echo e(Form::token()); ?>

                                    <button type="submit"><?php echo e(__('Logout')); ?></button>
                                </form>
                            </li>
                        <?php else: ?>
                            <li class="nav-item">

                                <a class="nav-link" href="/">Home<i class="fas fa-home"></i></a>
                            </li>

                            <li class="dropdown">
                            <a href="#" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">User<span class="caret"></span><i class="fas fa-user-circle"></i></a>
                            <ul class="dropdown-menu">
                         <?php if(auth()->guard()->guest()): ?>
                            <?php if(Route::has('login')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                                </li>
                            <?php endif; ?>
                            
                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php endif; ?>
                        </ul>
                        
                    </li>
                </li>

                        <?php endif; ?>

                    </ul>
                </div>
            </div>
        </nav>
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</body>
</html>

<?php /**PATH C:\Ballares_Refact\resources\views/layouts/app.blade.php ENDPATH**/ ?>