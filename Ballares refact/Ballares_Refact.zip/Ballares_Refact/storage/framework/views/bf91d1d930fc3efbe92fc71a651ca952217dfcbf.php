
<?php $__env->startSection('title', 'Animals'); ?>
<?php $__env->startSection('content'); ?>
    <div align="right">
      <a href="<?php echo e(route('animal.create')); ?>" class="btn btn-success btn-sm"><i class="fa fa-plus"></i> Create Record</a>
    </div>
    <br />
    <div class="table-responsive">
      <table id="animal_table" class="table table-bordered table-striped">
        <thead>
          <tr>
          
            <th>NAME</th>
              <th>TYPE </th>
              <th>BREED</th>
              <th>GENDER</th>
              <th>AGE</th>
              <th>DATE RESCUED</th>
              <th>RESCUER</th>
              <th>PERSONNEL</th>
              <th>STATUS</th>
              <th>IMAGE</th>
              <th>ACTION</th>
          </tr>
        </thead>
      </table>
    </div>
  <br />
  <br />

  <script>
    $(document).ready(function()
    {
      $('#animal_table').DataTable({
        processing: true,
        serverSide: true,
        ajax: {
          url: "<?php echo e(route('animal.index')); ?>",
        },
        columns: [

        {
            data: 'animal_name',
            name: 'animal_name'
        },
      {
            data: 'animal_type',
            name: 'animal_type'
        },
      {
            data: 'animal_breed',
            name: 'animal_breed'
        },
        {
            data: 'animal_gender',
            name: 'animal_gender'
        },
        {
            data: 'animal_age',
            name: 'animal_age'
        },
        {
            data: 'rescue_date',
            name: 'rescue_date'
        },
      {
        data: 'rescuer_name',
        name: 'rescuer_name'
      },
      {
        data: 'personnel_name',
        name: 'personnel_name'
      },
        {
            data: 'adopt_stat',
            name: 'adopt_stat'
        },
              { 
          data: 'img_path', 
          name: 'img_path',
          "render": function (data, type, full, meta) {
              return "<img src=\"" + data + "\" height=\"100\" width=\"100\"/>";
          },orderable: false},
        {
            data: 'action',
            name: 'action',
            orderable: false
        }
        ]
      });
    });
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Ballares_Refact\resources\views/animals/index.blade.php ENDPATH**/ ?>