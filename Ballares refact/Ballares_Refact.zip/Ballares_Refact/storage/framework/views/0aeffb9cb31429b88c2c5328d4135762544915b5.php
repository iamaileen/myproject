
<?php $__env->startSection('title', 'Injuries'); ?>
<?php $__env->startSection('content'); ?>
    <div align="right">
      <a href="<?php echo e(route('injury.create')); ?>" class="btn btn-success btn-sm"><i class="fa fa-plus"></i> Create Record</a>
    </div>
    <br />
    <div class="table-responsive">
      <table id="injury_table" class="table table-bordered table-striped">
        <thead>
          <tr>
            <th>NAME</th>
              <th>TYPE </th>
              <th>DESCRIPTION</th>
              <th>ACTION</th>
          </tr>
        </thead>
      </table>
    </div>
  <br />
  <br />

  <script>
    $(document).ready(function()
    {
      $('#injury_table').DataTable({
        processing: true,
        serverSide: true,
        ajax: {
          url: "<?php echo e(route('injury.index')); ?>",
        },
        columns: [
        {
            data: 'injury_name',
            name: 'injury_name'
        },
      {
            data: 'injury_type',
            name: 'injury_type'
        },
      {
            data: 'injury_description',
            name: 'injury_description'
        },
        
        {
            data: 'action',
            name: 'action',
            orderable: false
        }
        ]
      });
    });
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Ballares_Refact\resources\views/injuries/index.blade.php ENDPATH**/ ?>