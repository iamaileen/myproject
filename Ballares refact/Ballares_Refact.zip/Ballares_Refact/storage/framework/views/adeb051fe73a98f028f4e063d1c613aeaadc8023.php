

<?php $__env->startSection('content'); ?>
<div class="container pt-3 ">
		<div class="row">
			<div class="col-md-15 col-md-offset-1">
				<h2>Animal Injury Table
					<a class="btn btn-primary pull-right" type="button" href="<?php echo e(route('animal_injury.create')); ?>" ><i class="fa fa-plus"></i> Animal</a>
				</h2>
			<?php if($message = Session::get('success')): ?>
				<div class="alert alert-success alert-block">
					<button type="button" class="close" data-dismiss="alert">×</button> 
						<strong><?php echo e($message); ?></strong>
				</div>
			<?php endif; ?>
			<div class="row">
				<div class="col-md-15 col-md-offset-1">
					<table class="table table-bordered table-responsive table-striped" style="text-align:center">

						<thead>
							<th>Animal ID</th>
							<th>Aanimal</th>
							<th>Injury ID</th>
							<th>Injury</th>
							<th>Action</th>
						</thead>
						<tbody>
							<?php $__currentLoopData = $injury; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $injure): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e($injure->animal_id); ?></td>
									<td><?php echo e($injure->animal_name); ?></td>
									<td><?php echo e($injure->injury_id); ?></td>
									<td><?php echo e($injure->description); ?></td>
								<div class="d-flex">
								<?php echo Form::open(['method' => 'DELETE', 'route' => ['animal_injury.destroy', $injure->animal_id]]); ?>

									<td><a href="<?php echo e(route('animal_injury.edit',$injure->animal_id)); ?>" data-toggle="modal" class="btn btn-success"><i class='fa fa-edit'></i> Edit</a> 
									<button type="submit" data-toggle="modal" class="btn btn-danger"><i class='fa fa-trash'></i> Delete</button>		
									<?php echo Form::close(); ?>

									</td>
								</div>
									
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
<?php $__env->stopSection(); ?>	
</html>
<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Josh\JLT\resources\views/animal_injury/index.blade.php ENDPATH**/ ?>