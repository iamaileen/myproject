

<?php $__env->startSection('content'); ?>
<div class="container pt-3 ">
		<div class="row">
			<div class="col-md-15 col-md-offset-1">
				<h2>Adopters Table
					<a class="btn btn-primary pull-right" type="button" href="<?php echo e(route('adopters.create')); ?>" ><i class="fa fa-plus"></i> Adopter</a>
				</h2>
			<?php if($message = Session::get('success')): ?>
				<div class="alert alert-success alert-block">
					<button type="button" class="close" data-dismiss="alert">×</button> 
						<strong><?php echo e($message); ?></strong>
				</div>
			<?php endif; ?>
			<div class="row">
				<div class="col-md-15 col-md-offset-1">
					<table class="table table-bordered table-responsive table-striped" style="text-align:center">

						<thead>
							<th>ID</th>
							<th>Name</th>
							<th>Contact</th>
							<th>Address</th>
							<th>Age</th>
							<th>Gender</th>
							<th>Animal Adopted</th>
							<th>Action</th>
						</thead>
						<tbody>
							<?php $__currentLoopData = $adopters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adopter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e($adopter->id); ?></td>
									<td><?php echo e($adopter->adopter_name); ?></td>
									<td><?php echo e($adopter->adopter_contact); ?></td>
									<td><?php echo e($adopter->adopter_address); ?></td>
									<td><?php echo e($adopter->adopter_age); ?></td>
									<td><?php echo e($adopter->adopter_gender); ?></td>
									<td>
									<?php $__currentLoopData = $animals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $animal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php if($animal->adopter_id == $adopter->id): ?>
											- <?php echo e($animal->animal_name); ?> <br>
										<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</td>
								<?php echo Form::open(['method' => 'DELETE', 'route' => ['adopters.destroy', $adopter->id]]); ?>

									<td><a href="<?php echo e(route('adopters.edit',$adopter->id)); ?>" data-toggle="modal" class="btn btn-success"><i class='fa fa-edit'></i> Edit</a> 
									<button type="submit" data-toggle="modal" class="btn btn-danger"><i class='fa fa-trash'></i> Delete</button>		
									<?php echo Form::close(); ?>

									</td>
								</div>
									
								</tr>
							
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
<?php $__env->stopSection(); ?>	
</html>
<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Josh\JLT\resources\views/adopters/index.blade.php ENDPATH**/ ?>