


<?php $__env->startSection('content'); ?>
<style>
   .row{
       padding-top: 20;
       padding-left: 30;
       padding-bottom: 30
   }
   
</style>

    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
    
                <h2>  <?php echo e($animal->animal_name); ?> 's Data</h2>
            </div>
        <br><br>
        <div class="col-xs-12 col-sm-12 col-md-12"  >
                <img src="<?php echo e(asset($animal->img_path)); ?>" width="200px" height="200px">
            </div>
    </div>
  
    <div class="row">
            
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Animal Name:</strong>
                <?php echo e($animal->animal_name); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Animal Kind:</strong>
                <?php echo e($animal->animal_type); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Animal Breed:</strong>
                <?php echo e($animal->animal_breed); ?>

            </div>
        </div>
       
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Animal Gender:</strong>
                <?php echo e($animal->animal_gender); ?>

            </div>
        </div>
      

        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Date Rescued:</strong>  
                <?php echo e(($animal->rescue_date)); ?>

            </div>
        </div>

        <div class="pull-right">
                <a class="btn btn-primary" href="<?php echo e(url('/')); ?>" title="Go back"> Back</a>
        </div>
    </div>
    <?php echo csrf_field(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Josh\JLT\resources\views/animals/show.blade.php ENDPATH**/ ?>