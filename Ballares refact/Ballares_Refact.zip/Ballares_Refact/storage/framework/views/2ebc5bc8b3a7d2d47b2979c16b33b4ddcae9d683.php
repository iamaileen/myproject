

<?php $__env->startSection('content'); ?>
<div class="container pt-3 ">
<body style="background-color:GhostWhite;">
		<div class="row">
			<div class="col-md-15 col-md-offset-1">
				<h2>Emails Table</h2>
			<?php if($message = Session::get('success')): ?>
				<div class="alert alert-success alert-block">
					<button type="button" class="close" data-dismiss="alert">×</button> 
						<strong><?php echo e($message); ?></strong>
				</div>
			<?php endif; ?>
			<div class="row">
				<div class="col-md-15 col-md-offset-1">
					<table class="table table-bordered table-responsive table-striped" style="text-align:center">
						<thead>
							<th>Name</th>
							<th>Email</th>
							<th>Phone</th>
							<th>Subject</th>
							<th>Message</th>
							<th>Action</th>
						</thead>
						<tbody>
							<?php $__currentLoopData = $inquiries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inquiry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e($inquiry->inquiry_name); ?></td>
									<td><?php echo e($inquiry->inquiry_email); ?></td>
									<td><?php echo e($inquiry->inquiry_phone); ?></td>
									<td><?php echo e($inquiry->inquiry_subject); ?></td>
									<td><?php echo e($inquiry->inquiry_message); ?></td>
                                    <td>
								    <?php echo Form::open(['method' => 'DELETE', 'route' => ['inquiries.destroy', $inquiry->id]]); ?> 
									<button type="submit" data-toggle="modal" class="btn btn-danger"><i class='fa fa-trash'></i> Delete</button>		
									<?php echo Form::close(); ?>

									</td>
								</div>
									
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
</body>
<?php $__env->stopSection(); ?>	
</html>
<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Ballares_Refact\resources\views/inquiries/index.blade.php ENDPATH**/ ?>