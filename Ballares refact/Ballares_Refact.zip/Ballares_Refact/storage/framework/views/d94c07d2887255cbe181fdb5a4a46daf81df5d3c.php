
<?php $__env->startSection('content'); ?>
    <div class = "card-header">
        Add Injuries Record
    </div>
        <div class = "card-body">
        <?php echo Form::open(['route' => 'injury.store', 'files' => true]); ?>


              <div class = "form-group">
                  <label for="injury_name">Name</label>
                  <input type="text" name="injury_name" class="form-control" placeholder="Enter Injury/Disease Name"/>
                  <?php if($errors->has('injury_name')): ?>
                        <div class="alert alert-danger">
                            <?php echo e($errors->first('injury_name')); ?>

                        </div>
                    <?php endif; ?>
              </div>

              <div class = "from-group pt-3">
              <label for="injury_type">Type</label><br>
                  <label for="injury_type">
                  <input type="radio" name="injury_type" value="Injury">
                  Injury</label> 
                  <label for="injury_type">
                  <input type="radio" name="injury_type" value="Disease">
                  Disease</label> 
                  <?php if($errors->has('injury_type')): ?>
                        <div class="alert alert-danger">
                            <?php echo e($errors->first('injury_type')); ?>

                        </div>
                    <?php endif; ?>
              </div>

              <div class = "from-group pt-3">
                  <label for="injury_description">Description</label>
                  <input type="text" name="injury_description" class="form-control" placeholder="Add Description"/>
                  <?php if($errors->has('injury_description')): ?>
                        <div class="alert alert-danger">
                            <?php echo e($errors->first('injury_description')); ?>

                        </div>
                    <?php endif; ?>
              </div>
              
              <div class="pr-2 pt-4">
                <a href="<?php echo e(route('injury.index')); ?>" type="submit" class="btn btn-primary">Back</a>
                  <button type="submit" class="btn btn-success">Create</button>
                  
              </div>
                          
    </div>

        <?php echo Form::close(); ?>

                
<?php $__env->stopSection(); ?>
                    
<?php echo $__env->make('layouts.design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Ballares_Refact\resources\views/injuries/create.blade.php ENDPATH**/ ?>