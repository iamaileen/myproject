
<?php $__env->startSection('content'); ?>
    <div class = "card-header">
        Edit Animal Record
    </div>
        <div class = "card-body">
          <?php echo e(Form::model($animal,['method'=>'PATCH','route' => ['animal.update', $animal->id], 'files' => true])); ?>


          
              <div class = "form-group">
                  <label for="animal_name">Name</label>
                  <?php echo e(Form::text('animal_name',null,array('class'=>'form-control','id'=>'animal_name'))); ?>

                  <?php if($errors->has('animal_name')): ?>
                        <div class="alert alert-danger">
                            <?php echo e($errors->first('animal_name')); ?>

                        </div>
                    <?php endif; ?>
              </div>

              <div class = "from-group pt-3">
                  <label for="animal_type">Type</label><br>
                  <label>
                  <?php if($animal->animal_type == 'cat'): ?>
                    <?php echo e(Form::radio('animal_type', 'cat', true)); ?>

                    Cat</label> 
                    <label>
                    <?php echo e(Form::radio('animal_type', 'dog', false)); ?>

                    Dog</label> 
                  <?php else: ?>
                    <?php echo e(Form::radio('animal_type', 'cat', false)); ?>

                    Cat</label> 
                    <label>
                    <?php echo e(Form::radio('animal_type', 'dog', true)); ?>

                    Dog</label> 
                  <?php endif; ?>
              </div>

              <div class = "from-group pt-3">
                  <label for="animal_gender">Gender</label><br>
                  <label>
                  <?php if($animal->animal_gender == 'male'): ?>
                    <?php echo e(Form::radio('animal_gender', 'male', true)); ?>

                    Male</label> 
                    <label>
                    <?php echo e(Form::radio('animal_gender', 'female', false)); ?>

                    Female</label> 
                  <?php else: ?>
                    <?php echo e(Form::radio('animal_gender', 'male', false)); ?>

                    Male</label> 
                    <label>
                    <?php echo e(Form::radio('animal_gender', 'female', true)); ?>

                    Female</label> 
                  <?php endif; ?>
              </div>

              <div class = "from-group pt-3">
                  <label for="animal_breed">Breed</label>
                  <?php echo e(Form::text('animal_breed',null,array('class'=>'form-control','id'=>'animal_breed'))); ?>

                  <?php if($errors->has('animal_breed')): ?>
                        <div class="alert alert-danger">
                            <?php echo e($errors->first('animal_breed')); ?>

                        </div>
                    <?php endif; ?>
              </div>

              <div class = "from-group pt-3">
                  <label for="animal_age">Age</label>
                  <?php echo e(Form::text('animal_age',null,array('class'=>'form-control','id'=>'animal_age'))); ?>

                  <?php if($errors->has('animal_age')): ?>
                        <div class="alert alert-danger">
                            <?php echo e($errors->first('animal_age')); ?>

                        </div>
                    <?php endif; ?>
              </div>
            
              <div class = "from-group pt-3">
              <label>Injury</label>
                    <?php $__currentLoopData = $injury; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $injury_id => $injure): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-check form-check-block">
                            <?php if(in_array($injury_id, $animal_injury)): ?>
                                <?php echo Form::checkbox('injury_id[]', $injury_id, true, array('class' => 'form-check-input', 
                                'id' => 'injure')); ?>


                                <?php echo Form::label('injure',$injure, array('class' => 'form-check-label')); ?>

                            <?php else: ?>
                                <?php echo Form::checkbox('injury_id[]', $injury_id, null, array('class' => 'form-check-input', 
                                'id' => 'injure')); ?>


                                <?php echo Form::label('injure',$injure, array('class' => 'form-check-label')); ?>

                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

              <div >
                    <br><label for="rescuer_name">Rescuer</label>
                    <?php echo Form::select('rescuer_id', $rescuer, null,['class' => 'form-control', 'rescuer_id' => 'rescuer_id']); ?>

                    <?php if($errors->has('rescuer_name')): ?>
                        <div class="alert alert-danger">
                            <?php echo e($errors->first('rescuer_name')); ?>

                        </div>
                    <?php endif; ?>
              </div>


              <div >
                    <br><label for="personnel_name">Personnel</label>
                    <?php echo Form::select('personnel_id', $employee, null,['class' => 'form-control', 'personnel_id' => 'personnel_id']); ?>

                    <?php if($errors->has('personnel_name')): ?>
                        <div class="alert alert-danger">
                            <?php echo e($errors->first('personnel_name')); ?>

                        </div>
                    <?php endif; ?>
              </div>

              <div class = "from-group pt-3">
                  <label for="rescue_date">Date Rescued</label>
                  <?php echo Form::date('rescue_date',null,array('class'=>'form-control','id'=>'rescue_date')); ?>

              </div>
                
              <div class="from-group pt-3">
                  <label for="image"  class="control-label">Choose image</label>
                  <input type="file" class="form-control" id="image" name="img_path"/><br>
                  <img src="<?php echo e(asset($animal->img_path)); ?>" width="100px" height="100px">
              </div>
              
              <div class="pr-2 pt-4">
                  <button type="submit" class="btn btn-success">Update</button>
                  <a href="<?php echo e(route('animal.index')); ?>" type="submit" class="btn btn-primary">Back</a>
              </div>
                          
    </div>
        <?php echo csrf_field(); ?>
        <?php echo Form::close(); ?>

                
<?php $__env->stopSection(); ?>
                    
<?php echo $__env->make('layouts.design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Ballares_Refact\resources\views/animals/edit.blade.php ENDPATH**/ ?>