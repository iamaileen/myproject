
<?php $__env->startSection('content'); ?>
    <div class = "card-header">
        Edit Adopter Record
    </div>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <div class = "card-body">
          <?php echo e(Form::model($adopter,['method'=>'PATCH','route' => ['adopters.update', $adopter->id]])); ?>


          
              <div class = "form-group">
                  <label for="adopter_name">Name</label>
                  <?php echo e(Form::text('adopter_name',null,array('class'=>'form-control','id'=>'adopter_name'))); ?>

              </div>

              <div class = "from-group pt-3">
                  <label for="adopter_contact">Contact</label>
                  <?php echo e(Form::text('adopter_contact',null,array('class'=>'form-control','id'=>'adopter_contact'))); ?>

              </div>

              <div class = "from-group pt-3">
                  <label for="adopter_address">Age</label>
                  <?php echo e(Form::text('adopter_address',null,array('class'=>'form-control','id'=>'adopter_address'))); ?>

              </div>

              <div class = "from-group pt-3">
                  <label for="adopter_age">Age</label>
                  <?php echo e(Form::text('adopter_age',null,array('class'=>'form-control','id'=>'adopter_age'))); ?>

              </div>

              <div class = "from-group pt-3">
                  <label for="adopter_gender">Gender</label><br>
                  <label>
                  <?php if($adopter->adopter_gender == 'male'): ?>
                    <?php echo e(Form::radio('adopter_gender', 'male', true)); ?>

                    Male</label> 
                    <label>
                    <?php echo e(Form::radio('adopter_gender', 'female', false)); ?>

                    Female</label> 
                  <?php else: ?>
                    <?php echo e(Form::radio('adopter_gender', 'male', false)); ?>

                    Male</label> 
                    <label>
                    <?php echo e(Form::radio('adopter_gender', 'female', true)); ?>

                    Female</label> 
                  <?php endif; ?>
              </div>
            
              <div class = "from-group pt-3">
              <label>Animal for Adoption:</label>
                    <?php $__currentLoopData = $animal_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adopted_id => $id_animal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-check form-check-block">
                            <?php if(in_array($adopted_id, $adopted_animal)): ?>
                                <?php echo Form::checkbox('adopted_id[]', $adopted_id, true, array('class' => 'form-check-input', 
                                'id' => 'id_animal')); ?>


                                <?php echo Form::label('id_animal',$id_animal, array('class' => 'form-check-label')); ?>

                            <?php else: ?>
                                <?php echo Form::checkbox('adopted_id[]', $adopted_id, null, array('class' => 'form-check-input', 
                                'id' => 'id_animal')); ?>


                                <?php echo Form::label('id_animal',$id_animal, array('class' => 'form-check-label')); ?>

                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

               <div class = "from-group pt-3">
                  <label for="adopted_date">Adopted Date</label>
                  <?php echo Form::date('adopted_date',null,array('class'=>'form-control','id'=>'adopted_date')); ?>

              </div>

              
              <div class="pr-2 pt-4">
                  <button type="submit" class="btn btn-success">Update</button>
                  <a href="<?php echo e(url()->previous()); ?>" type="submit" class="btn btn-primary">Back</a>
              </div>
                          
    </div>
        <?php echo csrf_field(); ?>
        <?php echo Form::close(); ?>

                
<?php $__env->stopSection(); ?>
                    
<?php echo $__env->make('layouts.design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Ballares_Refact\resources\views/adopters/edit.blade.php ENDPATH**/ ?>