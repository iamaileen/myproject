
<?php $__env->startSection('content'); ?>
    <div class = "card-header">
        Add Personnel Record
    </div>
        <div class = "card-body">
          <?php echo Form::open(['route' => 'personnels.store']); ?>

              <div class = "form-group">
                  <label for="personnel_name">Name</label>
                  <input type="text" name="personnel_name" class="form-control" placeholder="Enter Personnel Name"/>
                  <?php if($errors->has('personnel_name')): ?>
                        <div class="alert alert-danger">
                            <?php echo e($errors->first('personnel_name')); ?>

                        </div>
                    <?php endif; ?>
              </div>

              <div class = "from-group pt-3">
                  <label for="personnel_role">Role</label><br>
                  <input type="radio" name="personnel_role" value="employee"> <label for="Employee">Employee</label>
                  <input type="radio" name="personnel_role" value="veterinarian"> <label for="Veterinarian">Veterinarian</label>
                  <input type="radio" name="personnel_role" value="volunteer"> <label for="Volunteer">Volunteer</label>
                  <?php if($errors->has('personnel_role')): ?>
                        <div class="alert alert-danger">
                            <?php echo e($errors->first('personnel_role')); ?>

                        </div>
                    <?php endif; ?>
              </div>

              <div class = "from-group pt-3">
                  <label for="personnel_gender">Gender</label><br>
                  <label for="Male">Male</label> <input type="radio" name="personnel_gender" value="male">
                  <label for="Female">Female</label> <input type="radio" name="personnel_gender" value="female">
                  <?php if($errors->has('personnel_gender')): ?>
                        <div class="alert alert-danger">
                            <?php echo e($errors->first('personnel_gender')); ?>

                        </div>
                    <?php endif; ?>
              </div>

              <div class = "from-group pt-3">
                  <label for="personnel_contact">Contact</label>
                  <input type="text" name="personnel_contact" class="form-control" placeholder="Enter Personnel Contact"/>
                  <?php if($errors->has('personnel_contact')): ?>
                        <div class="alert alert-danger">
                            <?php echo e($errors->first('personnel_contact')); ?>

                        </div>
                    <?php endif; ?>
              </div>

              <div class = "from-group pt-3">
                  <label for="personnel_address">Address</label>
                  <input type="text" name="personnel_address" class="form-control" placeholder="Enter Personnel Address"/>
                  <?php if($errors->has('personnel_address')): ?>
                        <div class="alert alert-danger">
                            <?php echo e($errors->first('personnel_address')); ?>

                        </div>
                    <?php endif; ?>
              </div>
              
              <div class="pr-2 pt-4">
                  <button type="submit" class="btn btn-success">Create</button>
                  <a href="<?php echo e(route('personnels.index')); ?>" type="submit" class="btn btn-primary">Back</a>
              </div>
                          
    </div>
        <?php echo csrf_field(); ?>
        <?php echo Form::close(); ?>

                
<?php $__env->stopSection(); ?>
                    
<?php echo $__env->make('layouts.design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Josh\JLT\resources\views/personnels/create.blade.php ENDPATH**/ ?>