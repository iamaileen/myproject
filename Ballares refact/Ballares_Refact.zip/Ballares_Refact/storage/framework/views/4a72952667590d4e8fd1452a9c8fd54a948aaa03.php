<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
<body style="background-color:Lavender;">
    <section styles = "padding-top:70px;">
        <div class = "container">
            <div class = "row">
                <div class = "col-md-6 offset-md-3 pt-5">
                    <div class = "card">
                        <?php echo $__env->yieldContent('home'); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
</body>
</html><?php /**PATH C:\Users\Josh\JLT\resources\views/layouts/landingdesign.blade.php ENDPATH**/ ?>