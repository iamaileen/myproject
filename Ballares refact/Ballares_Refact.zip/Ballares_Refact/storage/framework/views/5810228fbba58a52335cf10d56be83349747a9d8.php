<?php $__env->startComponent('mail::message'); ?>
<b>Name</b> <?php echo e($data['inquiry_name']); ?>

<b>Email</b> <?php echo e($data['inquiry_email']); ?>

<b>Phone</b> <?php echo e($data['inquiry_phone']); ?>

<b>Subject</b> <?php echo e($data['inquiry_subject']); ?>

<b>Message</b> <?php echo e($data['inquiry_message']); ?>


The body of your message.

<?php $__env->startComponent('mail::button', ['url' => 'mailto:',$data['inquiry_email']]); ?>
Reply to <?php echo e($data['inquiry_name']); ?>

<?php if (isset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e)): ?>
<?php $component = $__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e; ?>
<?php unset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\Josh\JLT\resources\views/emails/contactMail.blade.php ENDPATH**/ ?>