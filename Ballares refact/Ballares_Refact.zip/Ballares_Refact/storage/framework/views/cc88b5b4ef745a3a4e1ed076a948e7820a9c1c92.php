
<?php $__env->startSection('title', 'Personnels'); ?>
<?php $__env->startSection('content'); ?>
    <div align="right">
      <a href="<?php echo e(route('personnels.create')); ?>" class="btn btn-success btn-sm"><i class="fa fa-plus"></i> Create Record</a>
    </div>
    <br />
    <div class="table-responsive">
      <table id="personnel_table" class="table table-bordered table-striped">
        <thead>
          <tr>
            <th>NAME</th>
              <th>ROLE </th>
              <th>CONTACT</th>
              <th>ADDRESS</th>
              <th>GENDER</th>
              <th>ACTION</th>
          </tr>
        </thead>
      </table>
    </div>
  <br />
  <br />

  <script>
    $(document).ready(function()
    {
      $('#personnel_table').DataTable({
        processing: true,
        serverSide: true,
        ajax: {
          url: "<?php echo e(route('personnels.index')); ?>",
        },
        columns: [
        {
            data: 'personnel_name',
            name: 'personnel_name'
        },
      {
            data: 'personnel_role',
            name: 'personnel_role'
        },
      {
            data: 'personnel_contact',
            name: 'personnel_contact'
        },
        {
            data: 'personnel_address',
            name: 'personnel_address'
        },
         {
            data: 'personnel_gender',
            name: 'personnel_gender'
        },
        
        {
            data: 'action',
            name: 'action',
            orderable: false
        }
        ]
      });
    });
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Ballares_Refact\resources\views/personnels/index.blade.php ENDPATH**/ ?>