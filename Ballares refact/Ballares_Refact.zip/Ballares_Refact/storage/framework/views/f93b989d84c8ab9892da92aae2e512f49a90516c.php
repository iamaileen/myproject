

<?php $__env->startSection('content'); ?>

<?php if(Auth::user()->role == "employee"): ?>
<div class="container pt-3 ">
<body style="background-color:GhostWhite;">
		<div class="row">
			<div class="col-md-15 col-md-offset-1">
				<h2>Personnels Profile</h2>
			<?php if($message = Session::get('success')): ?>
				<div class="alert alert-success alert-block">
					<button type="button" class="close" data-dismiss="alert">×</button> 
						<strong><?php echo e($message); ?></strong>
				</div>
			<?php endif; ?>
			<div class="row">
				<div class="col-md-15 col-md-offset-1">
					<table class="table table-bordered table-responsive table-striped" style="text-align:center">
						<thead>
							<th>ID</th>
							<th>Name</th>
                            <th>Address</th>
                            <th>Role</th>
							<th>Contat</th>
							<th>Gender</th>
                            <th>Edit</th>
						</thead>
						<tbody>
                            <tr>
                                <td><?php echo e($profile->id); ?></td>
                                <td><?php echo e($profile->personnel_name); ?></td>
                                <td><?php echo e($profile->personnel_address); ?></td>
                                <td><?php echo e($profile->personnel_role); ?></td>
                                <td><?php echo e($profile->personnel_contact); ?></td>
                                <td><?php echo e($profile->personnel_gender); ?></td>
                                <td><a href="<?php echo e(route('personnels.edit',$profile->id)); ?>" data-toggle="modal" class="btn btn-success"><i class='fa fa-edit'></i> Edit</a> 
                                </td>
                            </div>
                                
                            </tr>
						</tbody>
					</table>
				</div>
			</div>

            <h2>Animal Helped</h2>
            <div class="row">
				<div class="col-md-15 col-md-offset-1">
					<table class="table table-bordered table-responsive table-striped" style="text-align:center">
						<thead>
							<th>Name</th>
                            <th>Type</th>
							<th>Breed</th>
							<th>Gender</th>
                            <th>Age</th>
                            <th>Image</th>
                            <th>Status</th>
                            <th>Injury</th>
						</thead>
						<tbody>
                            <?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($row->animal_name); ?></td>
                                <td><?php echo e($row->animal_type); ?></td>
                                <td><?php echo e($row->animal_breed); ?></td>
                                <td><?php echo e($row->animal_gender); ?></td>
                                <td><?php echo e($row->animal_age); ?></td>
                                <td><img src="<?php echo e(asset($row->img_path)); ?>" width="100px" height="100px"></td>
                                <td><?php echo e($row->adopt_stat); ?></td>
                                <td>
                                    <?php $__currentLoopData = $animal_injury; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $injure): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php if($row->id == $injure->animal_id): ?>
											- <?php echo e($injure->injury_name); ?> <br>
										<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					            </td>
				            </tr>
				            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
</body>
</html>

<?php elseif(Auth::user()->role == "rescuer"): ?>
<div class="container pt-3 ">
<body style="background-color:GhostWhite;">
		<div class="row">
			<div class="col-md-15 col-md-offset-1">
				<h2>Rescuer Profile</h2>
			<?php if($message = Session::get('success')): ?>
				<div class="alert alert-success alert-block">
					<button type="button" class="close" data-dismiss="alert">×</button> 
						<strong><?php echo e($message); ?></strong>
				</div>
			<?php endif; ?>
			<div class="row">
				<div class="col-md-15 col-md-offset-1">
					<table class="table table-bordered table-responsive table-striped" style="text-align:center">
						<thead>
							<th>ID</th>
							<th>Name</th>
                            <th>Address</th>
							<th>Contat</th>
							<th>Gender</th>
                            <th>Edit</th>
						</thead>
						<tbody>
                            <tr>
                                <td><?php echo e($profile->id); ?></td>
                                <td><?php echo e($profile->rescuer_name); ?></td>
                                <td><?php echo e($profile->rescuer_address); ?></td>
                                <td><?php echo e($profile->rescuer_contact); ?></td>
                                <td><?php echo e($profile->rescuer_gender); ?></td>
                                <td><a href="<?php echo e(route('rescuers.edit',$profile->id)); ?>" data-toggle="modal" class="btn btn-success"><i class='fa fa-edit'></i> Edit</a> 
                                </td>
                            </div>
                            </tr>
						</tbody>
					</table>
				</div>
			</div>

            <h2>Animal Rescued</h2>
            <div class="row">
				<div class="col-md-15 col-md-offset-1">
					<table class="table table-bordered table-responsive table-striped" style="text-align:center">
						<thead>
							<th>Name</th>
                            <th>Type</th>
							<th>Breed</th>
							<th>Gender</th>
                            <th>Age</th>
                            <th>Image</th>
                            <th>Status</th>
                            <th>Injury</th>
						</thead>
						<tbody>
                            <?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($row->animal_name); ?></td>
                                <td><?php echo e($row->animal_type); ?></td>
                                <td><?php echo e($row->animal_breed); ?></td>
                                <td><?php echo e($row->animal_gender); ?></td>
                                <td><?php echo e($row->animal_age); ?></td>
                                <td><img src="<?php echo e(asset($row->img_path)); ?>" width="100px" height="100px"></td>
                                <td><?php echo e($row->adopt_stat); ?></td>
                                <td>
                                    <?php $__currentLoopData = $animal_injury; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $injure): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php if($row->id == $injure->animal_id): ?>
											- <?php echo e($injure->injury_name); ?> <br>
										<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					            </td>
				            </tr>
				            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
			</div>

		</div>
</body>
</html>

<?php elseif(Auth::user()->role == "adopter"): ?>
<div class="container pt-3 ">
<body style="background-color:GhostWhite;">
		<div class="row">
			<div class="col-md-15 col-md-offset-1">
				<h2>Adopter Profile</h2>
			<?php if($message = Session::get('success')): ?>
				<div class="alert alert-success alert-block">
					<button type="button" class="close" data-dismiss="alert">×</button> 
						<strong><?php echo e($message); ?></strong>
				</div>
			<?php endif; ?>
			<div class="row">
				<div class="col-md-15 col-md-offset-1">
					<table class="table table-bordered table-responsive table-striped" style="text-align:center">
						<thead>
							<th>ID</th>
							<th>Name</th>
                            <th>Address</th>
							<th>Contat</th>
							<th>Gender</th>
                            <th>Edit</th>
						</thead>
						<tbody>
                            <tr>
                                <td><?php echo e($profile->id); ?></td>
                                <td><?php echo e($profile->adopter_name); ?></td>
                                <td><?php echo e($profile->adopter_address); ?></td>
                                <td><?php echo e($profile->adopter_contact); ?></td>
                                <td><?php echo e($profile->adopter_gender); ?></td>
                                <td><a href="<?php echo e(route('adopters.edit',$profile->id)); ?>" data-toggle="modal" class="btn btn-success"><i class='fa fa-edit'></i> Edit</a> 
                                </td>
                            </div>
                                
                            </tr>
						</tbody>
					</table>
				</div>
			</div>

            <h2>Animal Adopted</h2>
            <div class="row">
				<div class="col-md-15 col-md-offset-1">
					<table class="table table-bordered table-responsive table-striped" style="text-align:center">
						<thead>
							<th>Name</th>
                            <th>Type</th>
							<th>Breed</th>
							<th>Gender</th>
                            <th>Age</th>
                            <th>Image</th>
						</thead>
						<tbody>
                            <?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($row->animal_name); ?></td>
                                <td><?php echo e($row->animal_type); ?></td>
                                <td><?php echo e($row->animal_breed); ?></td>
                                <td><?php echo e($row->animal_gender); ?></td>
                                <td><?php echo e($row->animal_age); ?></td>
                                <td><img src="<?php echo e(asset($row->img_path)); ?>" width="100px" height="100px"></td>
				            </tr>
				            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
</body>
</html>
<?php endif; ?>
<?php $__env->stopSection(); ?>	
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Josh\JLT\resources\views/users/profile.blade.php ENDPATH**/ ?>