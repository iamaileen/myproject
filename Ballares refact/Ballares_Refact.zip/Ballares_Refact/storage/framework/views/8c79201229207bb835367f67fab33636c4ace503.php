<?php $__env->startSection('content'); ?>
	<table id="table">
			<thead>
				<th>ID</th>
				<th>Name</th>
				<th>Type</th>
				<th>Breed</th>
				<th>Gender</th>
				<th>Age</th>
				
				<th>Date Rescued</th>
				
				<th>Image</th>
			</thead>
			<tbody>
				<?php $__currentLoopData = $animals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $animal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($animal->id); ?></td>
						
						<td><?php echo e($animal->animal_name); ?></td>
						<td><?php echo e($animal->animal_type); ?></td>
						<td><?php echo e($animal->animal_breed); ?></td>
						<td><?php echo e($animal->animal_gender); ?></td>
						<td><?php echo e($animal->animal_age); ?></td>
						
						<td><?php echo e($animal->rescue_date); ?></td>
						
						<td><img src="<?php echo e(asset($animal->img_path)); ?>" width="100px" height="100px"></td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
	</table>
<?php $__env->stopSection(); ?>	

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Ballares_Refact\resources\views/welcome.blade.php ENDPATH**/ ?>