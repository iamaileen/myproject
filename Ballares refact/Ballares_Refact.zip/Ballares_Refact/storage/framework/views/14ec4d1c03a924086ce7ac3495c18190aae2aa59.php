
<?php $__env->startSection('content'); ?>
    <div class = "card-header">
        Add Animal Injury Record
    </div>
        <div class = "card-body">
          <?php echo Form::open(['route' => 'animal_injury.store', 'files' => true]); ?>

              <div>
                    <label for="animal_name">Animal Name</label>
                    <?php echo Form::select('animal_name', $animal, null,['class' => 'form-control', 'animal_name' => 'animal_name', 
                    'placeholder' => 'Select Animal']); ?>

              </div>
              <br>
              <?php $__currentLoopData = $injure; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $desc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="form-check form-check-block">
                    <?php echo Form::checkbox('injury_id[]',$id, null, array('class' => 'form-check-input','id'=>'description')); ?>

                    <?php echo Form::label('description', $desc, array('class' => 'form-check-label')); ?>

                </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
              
              <div class="pr-2 pt-4">
                  <button type="submit" class="btn btn-success">Create</button>
                  <a href="<?php echo e(route('animal_injury.store')); ?>" type="submit" class="btn btn-primary">Back</a>
              </div>
                        
                          
    </div>
        <?php echo csrf_field(); ?>
        <?php echo Form::close(); ?>

                
<?php $__env->stopSection(); ?>
                    
<?php echo $__env->make('layouts.design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Josh\JLT\resources\views/animal_injury/create.blade.php ENDPATH**/ ?>