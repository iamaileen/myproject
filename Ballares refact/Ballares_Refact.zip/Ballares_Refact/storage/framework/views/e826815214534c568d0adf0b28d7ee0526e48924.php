
<?php $__env->startSection('content'); ?>
    <div class = "card-header">
        Edit Injuries/Diseases Record
    </div>
    <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class = "card-body">
          <?php echo e(Form::model($injuries,['method'=>'PATCH','route' => ['injuries.update', $injuries->id]])); ?>


          
              <div class = "form-group">
                  <label for="injury_name">Injury/Disease Name</label>
                  <?php echo e(Form::text('injury_name',null,array('class'=>'form-control','id'=>'injury_name'))); ?>

              </div>

              <div class = "from-group pt-3">
                  <label for="injury_type">Type</label><br>
                  <label>
                  <?php if($injuries->injury_type == 'Injury'): ?>
                    <?php echo e(Form::radio('injury_type', 'injury', true)); ?>

                    Injury</label> 
                    <label>
                    <?php echo e(Form::radio('injury_type', 'Disease', false)); ?>

                    Female</label> 
                  <?php else: ?>
                    <?php echo e(Form::radio('injury_type', 'Injury', false)); ?>

                    Injury</label> 
                    <label>
                    <?php echo e(Form::radio('injury_type', 'Disease', true)); ?>

                    Disease</label> 
                  <?php endif; ?>
              </div>

              <div class = "from-group pt-3">
                  <label for="injury_description">Description</label>
                  <?php echo e(Form::text('injury_description',null,array('class'=>'form-control','id'=>'injury_description'))); ?>

              </div>
              
              <div class="pr-2 pt-4">
                  <button address="submit" class="btn btn-success">Update</button>
                  <a href="<?php echo e(route('injuries.index')); ?>" address="submit" class="btn btn-primary">Back</a>
              </div>
                          
    </div>
        <?php echo csrf_field(); ?>
        <?php echo Form::close(); ?>

                
<?php $__env->stopSection(); ?>
                    
<?php echo $__env->make('layouts.design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Josh\JLT\resources\views/injuries/edit.blade.php ENDPATH**/ ?>