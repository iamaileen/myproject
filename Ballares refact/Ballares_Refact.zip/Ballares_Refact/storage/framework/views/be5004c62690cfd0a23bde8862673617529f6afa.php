<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Welcome</title>

        <!-- Fonts -->
        <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
        <!-- Styles -->

        <style>
            body {
                font-family: 'Nunito', sans-serif;
            }

            /*Horizontal Navigation Bar*/
            /*Removing the list style of the list eg[Bullets] and adding some design*/
            .horizontal-menu ul {
                list-style-type: none;
                margin: 0;
                padding: 0;
                overflow: hidden;
                background-color: #38CF3B;
            }
            /* Navigation link Simple Default Design */
            .horizontal-menu li a {
                display: block;
                color: white;
                text-align: center;
                padding: 14px 16px;
                text-decoration: none;
            }
            /* Navigation Link Design if active */
            .horizontal-menu .active {
                background-color: #38CF3B;
                color: white;
            }
            /* Displaying the list items horizontally and adding border to the right serve as the divider of each items */
            .horizontal-menu li {
                float: left;
                border-right: 1px solid #bbb;
            }
            /*Removing the right border of the list last item*/
            .horizontal-menu li:last-child {
                border-right: none;
            }
            /* Changing the background color of the link when hovered. */
            .horizontal-menu li a:hover {
                background-color: #111;
            }
        </style>
            <nav class="navbar navbar-default" role="navigation" >
            <div class="container-fluid">
                <div class="navbar-header">
                    <div class="horizontal-menu">
                    <ul>
                        <li><a href="<?php echo e(url('/')); ?>" class="active">HOME</a></li>
                        <li><a href="<?php echo e(route('inquiries.create')); ?>">Contact Us</a></li>
                        <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
                        <li><a href="<?php echo e(route('register')); ?>">Register</a></li>
                    </ul>
                </div>
                </div>
            </div>
            </nav>
    </head>
    <body style="background-color:Lavender">
                <?php echo $__env->yieldContent('landing'); ?>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
<?php /**PATH C:\Users\Josh\JLT\resources\views/layouts/navhome.blade.php ENDPATH**/ ?>