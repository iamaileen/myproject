<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DataRescuerController;





Auth::routes(['verify' => true]);

Route::group(['middleware' => ['auth', 'role', 'verified']], function()
{


Route::get('/multiuser', [App\Http\Controllers\HomeController::class, 'index'])->name('multiuser');


Route::resource('animal', 'AnimalController');
Route::get('animal/destroy/{id}', 'AnimalController@destroy');

Route::resource('injury', 'InjuryController');
Route::get('injury/destroy/{id}', 'InjuryController@destroy');

Route::resource('personnels', 'PersonnelController');
Route::get('personnels/destroy/{id}', 'PersonnnelController@destroy');


Route::resource('rescuers', 'RescuerController');
Route::get('rescuers/destroy/{id}', 'RescuerController@destroy');

Route::resource('/adopters', 'AdopterController');

Route::get('/admin/{id}', ['uses' => 'UserController@adminEdit', 'as' => 'admin.edit']);
Route::patch('/admin/{id}', ['uses' => 'UserController@adminUpdate','as' => 'admin.update']);


Route::get('/user', ['uses' => 'UserController@getUser', 'as' => 'user.disable']);
Route::get('/status/{id}', ['uses' => 'UserController@userBan', 'as' => 'user.status']);



});
// Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::resource('/', 'LandingController');
Route::post('/search', ['uses' => 'SearchController@search', 'as' => 'search']);
Route::get('/show/{id}', ['uses' => 'SearchController@show', 'as' => 'show']);

// Route::get('/admin/{id}', ['uses' => 'UserController@adminEdit', 'as' => 'admin.edit']);
// Route::patch('/admin/{id}', ['uses' => 'UserController@adminUpdate','as' => 'admin.update']);




// Route::get('/profile', ['uses' => 'UserController@getProfile', 'as' => 'user.profile']);
// Route::get('/dashboard', ['uses' => 'UserController@getDashboard', 'as' => 'user.dashboard']);

// Route::get('/back', ['uses' => 'UserController@back', 'as' => 'user.back']);


// Route::fallback(function(){
//     return redirect()->back();
// });

// Datatables

// //Rescuers
// Route::get('data_rescuer', 'DataRescuerController@index')->middleware('role:admin');
// Route::post('delete-rescuer', 'DataRescuerController@destroy')->middleware('role:admin');
// Route::post('edit-rescuer', 'DataRescuerController@edit')->middleware('role:admin');
// Route::post('add-rescuer', 'DataRescuerController@store')->middleware('role:admin');
// //Personnels
// Route::get('data_personnel', 'DataPersonnelController@index')->middleware('role:admin');
// Route::post('delete-personnel', 'DataPersonnelController@destroy')->middleware('role:admin');
// Route::post('edit-personnel', 'DataPersonnelController@edit')->middleware('role:admin');
// Route::post('add-personnel', 'DataPersonnelController@store')->middleware('role:admin');
// //Injuries
// Route::get('data_injury', 'DataInjuryController@index')->middleware('role:admin');
// Route::post('delete-injury', 'DataInjuryController@destroy')->middleware('role:admin');
// Route::post('edit-injury', 'DataInjuryController@edit')->middleware('role:admin');
// Route::post('add-injury', 'DataInjuryController@store')->middleware('role:admin');
// //Animals
// Route::get('data_animal', 'DataAnimalController@index')->middleware('role:admin');
// Route::post('delete-animal', 'DataAnimalController@destroy')->middleware('role:admin');
// Route::post('edit-animal', 'DataAnimalController@edit')->middleware('role:admin');
// Route::post('add-animal', 'DataAnimalController@store')->middleware('role:admin');

// Route::get('data_injury', [
//     'uses' => 'DataInjuryController@index',
//     'as' => 'injury.index',
// ]);

// Route::get('data_personnel', [
//     'uses' => 'DataPersonnelController@index',
//     'as' => 'personnel.index',
// ]);

// Route::get('data_animal', [
//     'uses' => 'DataAnimalController@index',
//     'as' => 'animal.index',
// ]);

// Route::get('data_rescuer', [
//     'uses' => 'DataRescuerController@index',
//     'as' => 'rescuer.index',
// ]);

// Route::get('/user', ['uses' => 'UserController@getUser', 'as' => 'user.disable', 'middleware' => 'role:admin']);

// Route::get('/status/{id}', ['uses' => 'UserController@userBan', 'as' => 'user.status', 'middleware' => 'role:admin']);

// datatables

// Route::resource('animal', 'AnimalController')->middleware('role:employee,rescuer,admin');
// Route::get('animal/destroy/{id}', 'AnimalController@destroy')->middleware('role:employee, rescuer,admin');

// Route::resource('injury', 'InjuryController')->middleware('role:employee,rescuer,admin');
// Route::get('injury/destroy/{id}', 'InjuryController@destroy')->middleware('role:employee, rescuer,admin');

// Route::resource('personnels', 'PersonnelController')->middleware('role:employee,rescuer,admin');
// Route::get('personnels/destroy/{id}', 'PersonnnelController@destroy')->middleware('role:employee, rescuer,admin');

// Route::resource('rescuers', 'RescuerController')->middleware('role:employee,rescuer,admin');
// Route::get('rescuers/destroy/{id}', 'RescuerController@destroy')->middleware('role:employee, rescuer,admin');

// Route::get('personnels/destroy/{id}', 'PersonnelController@destroy')->middleware('role:employee, rescuer,admin');




// Auth::routes(['verify' => true]);
// [3:24 PM]
// Route::group(['middleware' => ['auth', 'role', 'verified']], function()
// {
//     Route::get('/multiuser', [App\Http\Controllers\HomeController::class, 'index'])->name('multiuser');

//     Route::resource('animal', 'AnimalController');
//     Route::get('animal/destroy/{id}', 'AnimalController@destroy');

//     Route::resource('rescuer', 'RescuerController');
//     Route::get('rescuer/destroy/{id}', 'RescuerController@destroy');

//     Route::resource('shelter_personnel', 'ShelterPersonnelController');
//     Route::get('shelter_personnel/destroy/{id}', 'ShelterPersonnelController@destroy');

//     Route::resource('disease_injury', 'DiseaseInjuryController');
//     Route::get('disease_injury/destroy/{id}', 'DiseaseInjuryController@destroy');

//     Route::resource('adopter', 'AdopterController');
//     Route::resource('inquiry', 'InquiryController');

//     Route::get('/user', ['uses' => 'UserController@getUser', 'as' => 'user.user']);
//     Route::get('/ban/{id}', ['uses' => 'UserController@userBan', 'as' => 'user.ban']);



// });

// Route::resource('/animals', 'AnimalController');
// Route::resource('/rescuers', 'RescuerController');
// Route::resource('/injuries', 'InjuryController');
// Route::resource('/adopters', 'AdopterController');
// Route::resource('/personnels', 'PersonnelController');

// Route::resource('/animals', 'AnimalController')->middleware('role:admin,rescuer,employee');
// Route::resource('/rescuers', 'RescuerController')->middleware('role:rescuer,admin');
// Route::resource('/injuries', 'InjuryController')->middleware('role:rescuer,employee,admin');
// Route::resource('/adopters', 'AdopterController')->middleware('role:adopter,admin');
// Route::resource('/personnels', 'PersonnelController')->middleware('role:employee,admin');
// Route::resource('/messages', 'MessageController')->middleware('role:employee,admin');