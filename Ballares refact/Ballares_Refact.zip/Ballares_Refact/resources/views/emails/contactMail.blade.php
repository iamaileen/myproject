@component('mail::message')
<b>Name</b> {{$data['inquiry_name']}}
<b>Email</b> {{$data['inquiry_email']}}
<b>Phone</b> {{$data['inquiry_phone']}}
<b>Subject</b> {{$data['inquiry_subject']}}
<b>Message</b> {{$data['inquiry_message']}}

The body of your message.

@component('mail::button', ['url' => 'mailto:',$data['inquiry_email']])
Reply to {{$data['inquiry_name']}}
@endcomponent

Thanks,<br>
{{ config('app.name') }}
@endcomponent
