<nav style="background-color:#233342" class="navbar navbar-default">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" style="color:233342" href=" ">Animal Shelter</a>
    </div>
     <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav navbar-right">
      <li>
{{--     <form class="navbar-form navbar-left" method="POST" role="search" action=" ">
          <input type="hidden" name="_token" value="{{ csrf_token() }}">
          <div class="form-group">
            <input type="text" name="search" class="form-control" placeholder="Search">
          </div>
          <button type="submit" class="btn btn-default"><i class="glyphicon glyphicon-search"></i></button>
      </form> --}}
        <li class="dropdown" >
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" style="background-color:#CE8054" ><i style="color:white" class="fas fa-user-circle"></i><span style="color:white" class="caret"></span></a>
          <ul style="background-color:#CE8054" class="dropdown-menu">
          
          @if(Auth::user()->role == "adopter")
      <li class="nav-item">
        <a href="">{{Auth::user()->name}}</a>
      </li> 
        <li class="nav-item">
        <form method="POST" action="{{ route('logout') }}">
          @csrf
          <button type="submit" class="btn btn-danger">{{ __('Logout') }}</button>          
        </form>
        </li> 

        @elseif(Auth::user()->role == "employee")
              <li class="nav-item" position="topnav-right">
                <a href="" class="nav-link">{{Auth::user()->name}}</a>
              </li> 
                <li class="nav-item">
                <form method="POST" action="{{ route('logout') }}">
                  @csrf
                  <button type="submit" class="btn btn-danger">{{ __('Logout') }}</button>          
                </form>
                </li> 
        @elseif(Auth::user()->role == "rescuer")

      <li class="nav-item">
        <a href=''>{{Auth::user()->name}}</a>
      </li> 
        <li class="nav-item">
        <form method="POST" action="{{ route('logout') }}">
          @csrf
          <button type="submit" class="btn btn-danger">{{ __('Logout') }}</button>          
        </form>
        </li> 
      
      @else
        <li class="nav-item">
          <a class="nav-link" aria-current="page" href="{{route('animals.index')}}">Animals</a>
        </li>
        
        <li class="nav-item">
          <a class="nav-link" aria-current="page" href="{{route('rescuers.index')}}">Rescuers</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" aria-current="page" href="{{route('injuries.index')}}">Injury/Disease</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" aria-current="page" href="{{route('adopters.index')}}">Adopters</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" aria-current="page" href="{{route('personnels.index')}}">Personnels</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" aria-current="page" href="{{route('messages.index')}}">Messages</a>
        </li>
        
        <li class="nav-item">
        <form method="POST" action="{{ route('logout') }}">
          @csrf
          <button type="submit" class="btn btn-danger">{{ __('Logout') }}</button>          
        </form>
        </li> 
      @endif
          </ul>
        </li> 
      </ul>
    </div>
  </div>
</nav>