@extends('layouts.design')
@section('content')
    <div class = "card-header">
        Edit Animal Record
    </div>
        <div class = "card-body">
          {{ Form::model($animal,['method'=>'PATCH','route' => ['animal.update', $animal->id], 'files' => true]) }}

          {{-- {{ method_field('PATCH') }} --}}
              <div class = "form-group">
                  <label for="animal_name">Name</label>
                  {{ Form::text('animal_name',null,array('class'=>'form-control','id'=>'animal_name')) }}
                  @if ($errors->has('animal_name'))
                        <div class="alert alert-danger">
                            {{ $errors->first('animal_name') }}
                        </div>
                    @endif
              </div>

              <div class = "from-group pt-3">
                  <label for="animal_type">Type</label><br>
                  <label>
                  @if ($animal->animal_type == 'cat')
                    {{ Form::radio('animal_type', 'cat', true)}}
                    Cat</label> 
                    <label>
                    {{ Form::radio('animal_type', 'dog', false)}}
                    Dog</label> 
                  @else
                    {{ Form::radio('animal_type', 'cat', false)}}
                    Cat</label> 
                    <label>
                    {{ Form::radio('animal_type', 'dog', true)}}
                    Dog</label> 
                  @endif
              </div>

              <div class = "from-group pt-3">
                  <label for="animal_gender">Gender</label><br>
                  <label>
                  @if ($animal->animal_gender == 'male')
                    {{ Form::radio('animal_gender', 'male', true)}}
                    Male</label> 
                    <label>
                    {{ Form::radio('animal_gender', 'female', false)}}
                    Female</label> 
                  @else
                    {{ Form::radio('animal_gender', 'male', false)}}
                    Male</label> 
                    <label>
                    {{ Form::radio('animal_gender', 'female', true)}}
                    Female</label> 
                  @endif
              </div>

              <div class = "from-group pt-3">
                  <label for="animal_breed">Breed</label>
                  {{ Form::text('animal_breed',null,array('class'=>'form-control','id'=>'animal_breed')) }}
                  @if ($errors->has('animal_breed'))
                        <div class="alert alert-danger">
                            {{ $errors->first('animal_breed') }}
                        </div>
                    @endif
              </div>

              <div class = "from-group pt-3">
                  <label for="animal_age">Age</label>
                  {{ Form::text('animal_age',null,array('class'=>'form-control','id'=>'animal_age')) }}
                  @if ($errors->has('animal_age'))
                        <div class="alert alert-danger">
                            {{ $errors->first('animal_age') }}
                        </div>
                    @endif
              </div>
            
              <div class = "from-group pt-3">
              <label>Injury</label>
                    @foreach($injury as $injury_id => $injure)
                        <div class="form-check form-check-block">
                            @if(in_array($injury_id, $animal_injury))
                                {!! Form::checkbox('injury_id[]', $injury_id, true, array('class' => 'form-check-input', 
                                'id' => 'injure')) !!}

                                {!! Form::label('injure',$injure, array('class' => 'form-check-label')) !!}
                            @else
                                {!! Form::checkbox('injury_id[]', $injury_id, null, array('class' => 'form-check-input', 
                                'id' => 'injure')) !!}

                                {!! Form::label('injure',$injure, array('class' => 'form-check-label')) !!}
                            @endif
                        </div>
                    @endforeach
                </div>

              <div >
                    <br><label for="rescuer_name">Rescuer</label>
                    {!! Form::select('rescuer_id', $rescuer, null,['class' => 'form-control', 'rescuer_id' => 'rescuer_id']) !!}
                    @if ($errors->has('rescuer_name'))
                        <div class="alert alert-danger">
                            {{ $errors->first('rescuer_name') }}
                        </div>
                    @endif
              </div>


              <div >
                    <br><label for="personnel_name">Personnel</label>
                    {!! Form::select('personnel_id', $employee, null,['class' => 'form-control', 'personnel_id' => 'personnel_id']) !!}
                    @if ($errors->has('personnel_name'))
                        <div class="alert alert-danger">
                            {{ $errors->first('personnel_name') }}
                        </div>
                    @endif
              </div>

              <div class = "from-group pt-3">
                  <label for="rescue_date">Date Rescued</label>
                  {!! Form::date('rescue_date',null,array('class'=>'form-control','id'=>'rescue_date')) !!}
              </div>
                
              <div class="from-group pt-3">
                  <label for="image"  class="control-label">Choose image</label>
                  <input type="file" class="form-control" id="image" name="img_path"/><br>
                  <img src="{{ asset($animal->img_path)}}" width="100px" height="100px">
              </div>
              
              <div class="pr-2 pt-4">
                  <button type="submit" class="btn btn-success">Update</button>
                  <a href="{{route('animal.index')}}" type="submit" class="btn btn-primary">Back</a>
              </div>
                          
    </div>
        @csrf
        {!! Form::close() !!}
                
@endsection
                    