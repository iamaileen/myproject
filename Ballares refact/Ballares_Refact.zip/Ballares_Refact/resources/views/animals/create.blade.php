@extends('layouts.design')
@section('content')
    <div class = "card-header">
        Add Animal Record
    </div>
        <!-- @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif -->
        <div class = "card-body">
          {!! Form::open(['route' => 'animal.store', 'files' => true]) !!}
              <div class = "form-group">
                  <label for="animal_name">Name</label>
                  {{ Form::text('animal_name',null,array('class'=>'form-control', 'placeholder'=>'Enter animal name')) }}
                  @if ($errors->has('animal_name'))
                        <div class="alert alert-danger">
                            {{ $errors->first('animal_name') }}
                        </div>
                    @endif
              </div>

              <div class = "from-group pt-3">
              <label for="animal_type">Type</label><br>     
                <label for="Cat">Cat</label>
                {{ Form::radio('animal_type', 'cat', false) }}
                <label for="Dog">Dog</label>
                {{ Form::radio('animal_type', 'dog', false) }}
                  @if ($errors->has('animal_type'))
                        <div class="alert alert-danger">
                            {{ $errors->first('animal_type') }}
                        </div>
                    @endif
              </div>

              <div class = "from-group pt-3">
              <label for="animal_gender">Gender</label><br>     
                <label for="animal_gender">Male</label>
                {{ Form::radio('animal_gender', 'male', false) }}
                <label for="animal_gender">Female</label>
                {{ Form::radio('animal_gender', 'female', false) }}
                  @if ($errors->has('animal_gender'))
                        <div class="alert alert-danger">
                            {{ $errors->first('animal_gender') }}
                        </div>
                    @endif
              </div>

              <div class = "from-group pt-3">
                  <label for="animal_breed">Breed</label>
                  {{ Form::text('animal_breed',null,array('class'=>'form-control', 'placeholder'=>'Enter animal breed')) }}
                  @if ($errors->has('animal_breed'))
                        <div class="alert alert-danger">
                            {{ $errors->first('animal_breed') }}
                        </div>
                    @endif
              </div>

              <div class = "from-group pt-3">
                  <label for="animal_age">Age</label>
                  {{ Form::text('animal_age',null,array('class'=>'form-control', 'placeholder'=>'Enter animal age')) }}
                  @if ($errors->has('animal_age'))
                        <div class="alert alert-danger">
                            {{ $errors->first('animal_age') }}
                        </div>
                    @endif
              </div>
                
              <div class = "from-group pt-3">
                    <label>Injury</label>
                    @foreach ($injure as $id => $desc)
                        <div class="form-check form-check-block">
                            {!! Form::checkbox('injury_id[]',$id, null, array('class' => 'form-check-input','id'=>'description')) !!}
                            {!! Form::label('description', $desc, array('class' => 'form-check-label')) !!}
                        </div>
                     @endforeach  
                </div>
              <div>
                    <br><label for="rescuer_name">Rescuer</label>
                    {!! Form::select('rescuer_id', $rescuer, null,['class' => 'form-control', 'rescuer_id' => 'rescuer_id', 
                    'placeholder' => 'Select Rescuer']) !!}
                    @if ($errors->has('rescuer_id'))
                        <div class="alert alert-danger">
                            {{ $errors->first('rescuer_id') }}
                        </div>
                    @endif
              </div>
                        
              <div class = "from-group pt-3">
                  <label for="rescue_date">Date Rescued</label>
                  {{ Form::date('rescue_date',null,array('class'=>'form-control')) }}
                  @if ($errors->has('rescue_date'))
                        <div class="alert alert-danger">
                            {{ $errors->first('rescue_date') }}
                        </div>
                    @endif
              </div>

              <div class="from-group pt-3">
                  <label for="image"  class="control-label">Choose image</label>
                  <input type="file" class="form-control" id="image" name="img_path"/>
                  @if ($errors->has('img_path'))
                        <div class="alert alert-danger">
                            {{ $errors->first('img_path') }}
                        </div>
                    @endif
              </div>

              <div>
                    <br><label for="personnel_name">Personnel</label>
                    {!! Form::select('personnel_id', $employee, null,['class' => 'form-control', 'personnel_id' => 'personnel_id', 
                    'placeholder' => 'Select Personnel']) !!}
                    @if ($errors->has('personnel_id'))
                        <div class="alert alert-danger">
                            {{ $errors->first('personnel_id') }}
                        </div>
                    @endif
              </div>

              <div class="pr-2 pt-4">
                  <button type="submit" class="btn btn-success">Create</button>
                  <a href="{{route('animal.index')}}" type="submit" class="btn btn-primary">Back</a>
              </div>
                          
    </div>
        @csrf
        {!! Form::close() !!}
                
@endsection
                    