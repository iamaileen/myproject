@extends('layouts.design')
@section('content')
    <div class = "card-header">
        Edit Personnel Record
    </div>
    @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <div class = "card-body">
          {{ Form::model($personnel,['method'=>'PATCH','route' => ['personnels.update', $personnel->id]]) }}

          {{-- {{ method_field('PATCH') }} --}}
              <div class = "form-group">
                  <label for="personnel_name">Name</label>
                  {{ Form::text('personnel_name',null,array('class'=>'form-control','id'=>'personnel_name')) }}
              </div>

{{--               <div class = "from-group pt-3">
                  <label for="personnel_role">Role</label><br>
                  <label>
                @if ($personnel->personnel_role == 'employee')
                    {{ Form::radio('personnel_role', 'employee', true)}}
                    Employee</label> 
                    <label>
                    {{ Form::radio('personnel_role', 'veterinarian', false)}}
                    Veterinarian</label> 
                    {{ Form::radio('personnel_role', 'volunteer', false)}}
                    Volunteer</label> 
                @endif

                @if ($personnel->personnel_role == 'veterinarian')
                    {{ Form::radio('personnel_role', 'employee', false)}}
                    Employee</label> 
                    <label>
                    {{ Form::radio('personnel_role', 'veterinarian', true)}}
                    Veterinarian</label> 
                    {{ Form::radio('personnel_role', 'volunteer', false)}}
                    Volunteer</label> 
                @endif

                @if ($personnel->personnel_role == 'volunteer')
                    {{ Form::radio('personnel_role', 'employee', false)}}
                    Employee</label> 
                    <label>
                    {{ Form::radio('personnel_role', 'veterinarian', false)}}
                    Veterinarian</label> 
                    {{ Form::radio('personnel_role', 'volunteer', true)}}
                    Volunteer</label> 
                @endif
              </div> --}}
              

              <div class = "from-group pt-3">
                  <label for="personnel_gender">Gender</label><br>
                  <label>
                  @if ($personnel->personnel_gender == 'male')
                    {{ Form::radio('personnel_gender', 'male', true)}}
                    Male</label> 
                    <label>
                    {{ Form::radio('personnel_gender', 'female', false)}}
                    Female</label> 
                  @else
                    {{ Form::radio('personnel_gender', 'male', false)}}
                    Male</label> 
                    <label>
                    {{ Form::radio('personnel_gender', 'female', true)}}
                    Female</label> 
                  @endif
              </div>

              <div class = "from-group pt-3">
                  <label for="personnel_contact">contact</label>
                  {{ Form::text('personnel_contact',null,array('class'=>'form-control','id'=>'personnel_contact')) }}
              </div>

              <div class = "from-group pt-3">
                  <label for="personnel_address">Address</label>
                  {{ Form::text('personnel_address',null,array('class'=>'form-control','id'=>'personnel_address')) }}
              </div>

              
              <div class="pr-2 pt-4">
                  <button address="submit" class="btn btn-success" >Update</button>
                  <a href="{{url()->previous()}}" address="submit" class="btn btn-primary">Back</a>
              </div>
                          
    </div>
        @csrf
        {!! Form::close() !!}
                
@endsection
                    