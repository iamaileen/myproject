@extends('layouts.design')
@section('content')
    <div class = "card-header">
        Add Personnel Record
    </div>
        <div class = "card-body">
          {!! Form::open(['route' => 'personnels.store']) !!}
              <div class = "form-group">
                  <label for="personnel_name">Name</label>
                  <input type="text" name="personnel_name" class="form-control" placeholder="Enter Personnel Name"/>
                  @if ($errors->has('personnel_name'))
                        <div class="alert alert-danger">
                            {{ $errors->first('personnel_name') }}
                        </div>
                    @endif
              </div>

              <div class = "from-group pt-3">
                  <label for="personnel_role">Role</label><br>
                  <input type="radio" name="personnel_role" value="employee"> <label for="Employee">Employee</label>
                  <input type="radio" name="personnel_role" value="veterinarian"> <label for="Veterinarian">Veterinarian</label>
                  <input type="radio" name="personnel_role" value="volunteer"> <label for="Volunteer">Volunteer</label>
                  @if ($errors->has('personnel_role'))
                        <div class="alert alert-danger">
                            {{ $errors->first('personnel_role') }}
                        </div>
                    @endif
              </div>

              <div class = "from-group pt-3">
                  <label for="personnel_gender">Gender</label><br>
                  <label for="Male">Male</label> <input type="radio" name="personnel_gender" value="male">
                  <label for="Female">Female</label> <input type="radio" name="personnel_gender" value="female">
                  @if ($errors->has('personnel_gender'))
                        <div class="alert alert-danger">
                            {{ $errors->first('personnel_gender') }}
                        </div>
                    @endif
              </div>

              <div class = "from-group pt-3">
                  <label for="personnel_contact">Contact</label>
                  <input type="text" name="personnel_contact" class="form-control" placeholder="Enter Personnel Contact"/>
                  @if ($errors->has('personnel_contact'))
                        <div class="alert alert-danger">
                            {{ $errors->first('personnel_contact') }}
                        </div>
                    @endif
              </div>

              <div class = "from-group pt-3">
                  <label for="personnel_address">Address</label>
                  <input type="text" name="personnel_address" class="form-control" placeholder="Enter Personnel Address"/>
                  @if ($errors->has('personnel_address'))
                        <div class="alert alert-danger">
                            {{ $errors->first('personnel_address') }}
                        </div>
                    @endif
              </div>

{{--               <div class = "form-group pt-3">
                  <label for="email">Email</label>
                  <input type="text" name="email" class="form-control" placeholder="Enter Email"/>
                  @if ($errors->has('email'))
                        <div class="alert alert-danger">
                            {{ $errors->first('email') }}
                        </div>
                    @endif
              </div>

                <div class = "form-group pt-3">
                  <label for="password">Password</label>
                  <input type="password" name="password" class="form-control" placeholder="Enter Password"/>
                  @if ($errors->has('password'))
                        <div class="alert alert-danger">
                            {{ $errors->first('password') }}
                        </div>
                    @endif
              </div> --}}
              
              <div class="pr-2 pt-4">
                  <button type="submit" class="btn btn-success">Create</button>
                  <a href="{{route('personnels.index')}}" type="submit" class="btn btn-primary">Back</a>
              </div>
                          
    </div>
        @csrf
        {!! Form::close() !!}
                
@endsection
                    