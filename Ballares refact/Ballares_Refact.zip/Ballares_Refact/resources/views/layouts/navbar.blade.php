<!DOCTYPE html>
<html lang="en">
<head>

    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css"/>
        <script src="https://code.jquery.com/jquery-1.12.4.js" integrity="sha256-Qw82+bXyGq6MydymqBxNPYTaUXXq7c8v3CwiYwLLNXU=" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
        <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
      <script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>  
      <link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css" />


</head>

    <style>
        body {
      color: #233342;
     background-image: url('https://www.teahub.io/photos/full/289-2891161_wallpaper-cat-wall-peeking-funny-minimalism-swift-fox.jpg');
      background-repeat: no-repeat;
      background-size: cover;
      font-family: 'Varela Round', sans-serif;
      font-size: 20px;
      text-decoration-color: darkgrey;
      text-decoration-style: wavy;

    }



    </style>


<body >

<nav class="navbar navbar-expand-lg navbar-blue bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="{{route('animal.index')}}">Animal Shelter </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-5">
@if(Auth::user()->role == "adopter")
      <div class="col-md-8 offset-md-10">


        @elseif(Auth::user()->role == "employee")
        <div class="col-md-8 offset-md-10">


        @elseif(Auth::user()->role == "rescuer")
        <div class="col-md-8 offset-md-10">

      
      @elseif(Auth::user()->role == "admin")
        <li class="nav-item">
          <a class="nav-link" aria-current="page" href="{{route('animal.index')}}">Animals</a>
        </li>
        
        <li class="nav-item">
          <a class="nav-link" aria-current="page" href="{{route('rescuers.index')}}">Rescuers</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" aria-current="page" href="{{route('injury.index')}}">Injury/Disease</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" aria-current="page" href="{{route('adopters.index')}}">Adopters</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" aria-current="page" href="{{route('personnels.index')}}">Personnels</a>
        </li>


        <li class="nav-item">
          <a class="nav-link" aria-current="page" href="{{route('user.disable')}}">Users</a>
        </li>
        

      @endif

      </ul>
    </div>

            <li class="nav-item">
          <div class="col-md-5 offset-md-1">
        <form method="POST" action="{{ route('logout') }}">
          @csrf
          <button type="submit" class="btn btn-danger">{{ __('Logout') }}</button>          
        </form>
      </div>
        </li> 
    
  </div>
</nav>


    <div class="container">

   <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.min.js"></script>

    </div>
    @yield('content')

    <div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.min.js"></script>
  </div>

</body>
</html>