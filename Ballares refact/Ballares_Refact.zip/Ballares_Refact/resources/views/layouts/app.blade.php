<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>Animal Shelter</title>

    <script src="{{ asset('js/app.js') }}" defer></script>


    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
   {{--  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous"> --}}
       {{--  <link rel="stylesheet" href="//cdn.datatables.net/1.10.7/css/jquery.dataTables.min.css"> --}}
        <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">

    <!-- Styles -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">

    <style>
        #table {font-family: Arial, Helvetica, sans-serif; border-collapse: collapse; width: 90%; margin-left: auto; margin-right: auto; margin-top: 5%;}
        #table td, #table th {border: 3px solid #233342; text-align: center;}
        #table tr:hover {background-color: #CE8054;}
        #table th {padding-top: 12px;padding-bottom: 12px; background-color: #4B2B31; color: white;}


    </style>

    <style>
        body {
      color: #233342;
     background-image: url('https://wallpaperaccess.com/full/214614.jpg');
      background-repeat: no-repeat;
      background-size: cover;
      font-family: 'Varela Round', sans-serif;
      font-size: 20px;
      text-decoration-color: darkgrey;
      text-decoration-style: wavy;
    }
    </style>


</head>
<body style="background-color:palegreen;">
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                <a class="navbar-brand" href="{{ url('/') }}">
                    Animal Shelter
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="{{ __('Toggle navigation') }}">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">
                        <form class="navbar-form navbar-left" method="POST" role="search" action="{{route('search')}}">
                            <input type="hidden" name="_token" value="{{ csrf_token() }}">
                            <input type="text" name="search" placeholder="Search Animals">
                            <button type="submit" class="fa fa-search" style="padding: 10px;"></button>
                        </form>
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        @if (Auth::check())
                            <li class="nav-item">
                                <a class="nav-link" href="/">Home</a>
                            </li>
                            <li>
                                <form method="POST" action="{{ route('logout') }}">
                                    {{ Form::token() }}
                                    <button type="submit">{{ __('Logout') }}</button>
                                </form>
                            </li>
                        @else
                            <li class="nav-item">

                                <a class="nav-link" href="/">Home<i class="fas fa-home"></i></a>
                            </li>
{{--                             <li class="nav-item">
                                <a class="nav-link" href="/injury">Contact<i class="fas fa-envelope"></i></a>
                            </li> --}}
                            <li class="dropdown">
                            <a href="#" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">User<span class="caret"></span><i class="fas fa-user-circle"></i></a>
                            <ul class="dropdown-menu">
                         @guest
                            @if (Route::has('login'))
                                <li class="nav-item">
                                    <a class="nav-link" href="{{ route('login') }}">{{ __('Login') }}</a>
                                </li>
                            @endif
                            
                            @if (Route::has('register'))
                                <li class="nav-item">
                                    <a class="nav-link" href="{{ route('register') }}">{{ __('Register') }}</a>
                                </li>
                            @endif
                        @endguest
                        </ul>
                        
                    </li>
                </li>

                        @endif

                    </ul>
                </div>
            </div>
        </nav>
        @yield('content')
    </div>
</body>
</html>

{{--         <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fas fa-user-circle"></i>User Management<span class="caret"></span></a>
          <ul class="dropdown-menu">
            @if (Auth::check())
              <li><a href="">User Profile</a></li>
              <li role="separator" class="divider"></li>
              <li><a href="{{ route('user.logout') }}">Logout</a></li>
            @else
              <li><a href="{{ route('user.signup') }}">Signup</a></li>
              <li><a href="{{ route('user.signin') }}">Signin</a></li>
            @endif
          </ul>
        </li> --}}