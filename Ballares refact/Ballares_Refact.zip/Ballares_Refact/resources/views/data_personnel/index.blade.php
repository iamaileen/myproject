@extends('layouts.master')
@section('title', 'Animal Shelter')
@section('content')


<h1>Personnel Table <button type="button" id="addpersonnel" class="btn btn-success">Add</button></h1>
<div class="row">

	<div class="col-md-15 col-md-offset-1">
        <table id="personnels" class="table table-bordered table-responsive table-striped" style="text-align:center">
			    <thead >
				    <tr>
					    <th>ID</th>
					    <th>NAME</th>
					    <th>ROLE</th>
					    <th>CONTACT</th>
              			<th>ADDRESS</th>
              			<th>GENDER</th>
					    <th>ACTION</th>
				    </tr>
			    </thead>
	    </table>
    <div class="modal fade" id="ipakita" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title" id="ajaxBookModel"></h4>
          </div>
          <div class="modal-body">
            <form action="javascript:void(0)" id="addEditBookForm" name="addEditBookForm" class="form-horizontal" method="POST">
              <input type="hidden" name="id" id="id">
              <div class="form-group">
                <label for="name" class="col-sm-1 control-label">Name</label>
                <div class="col-sm-12">
                  <input type="text" class="form-control" id="personnel_name" name="personnel_name" placeholder="Enter Name" maxlength="50" required="">
                </div>
              </div> 
                <div class="form-group">
                <label class="col-sm-1 control-label">ROLE</label>
                <div class="col-sm-12">
                  <input type="text" class="form-control" id="personnel_role" name="personnel_role" placeholder="Enter Conact" required="">
                </div>
              </div>
               <div class="form-group">
                <label class="col-sm-1 control-label">Contact</label>
                <div class="col-sm-12">
                  <input type="text" class="form-control" id="personnel_contact" name="personnel_contact" placeholder="Enter Conact" required="">
                </div>
              </div>
              <div class="form-group">
                <label for="name" class="col-sm-1 control-label">Address</label>
                <div class="col-sm-12">
                  <input type="text" class="form-control" id="personnel_address" name="rpersonnel_address" placeholder="Enter Address" maxlength="50" required="">
                </div>
              </div>

              <div class="form-group">
                <label class="col-sm-1 control-label">Gender</label>
                <div class="col-sm-12">
                <input type="text" class="form-control" id="personnel_gender" name="personnel_gender" placeholder="Enter Gender" required="">
                </div>
              </div>
              <div class="col-sm-offset-5">
                <button type="submit" class="btn btn-success" id="save_personnel" value="addpersonnel">Save changes
                </button>
                {{-- <a href="{{route('data_personnel.index')}}" type="submit" class="btn btn-primary">Back</a> --}}
              </div>
            </form>
          </div>
          <div class="modal-footer">
            
          </div>
        </div>
      </div>
    </div>
    </div>
</div>


@endsection
@section('scripts')
<script>
    $(document).ready(function() {
	$.ajaxSetup({
        headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
      $('#personnels').DataTable({
            processing: true,
            serverSide: true,
            ajax: "{{route('personnel.index') }}",
            columns: [
              { data: 'id', name: 'id' },
			  { data: 'personnel_name', name: 'personnel_name' },
			  { data: 'personnel_role', name: 'personnel_role' },
			  { data: 'personnel_contact', name: 'personnel_contact' },
              { data: 'personnel_address', name: 'personnel_address' },
              { data: 'personnel_gender', name: 'personnel_gender' },
			  {data: 'Actions', name: 'Actions',orderable:false,},
             ]
        });

        $('body').on('click', '.delete', function () {
       if (confirm("Delete Record?") == true) {
        var id = $(this).data('id');
         
        // ajaxs
        $.ajax({
			type:'POST',
            url: "{{ url('delete-personnel') }}",
            data: { id: id },
            dataType: 'json',
            success: function(res){
              var oTable = $('#personnels').dataTable();
              oTable.fnDraw(false);
           }
        });
       }
    });

    $('#addpersonnel').click(function () {
       $('#addEditBookForm').trigger("reset");
       $('#ajaxBookModel').html("Add Personnel");
       $('#ipakita').modal('show');
    });

    $('body').on('click', '.edit', function () {
        var id = $(this).data('id');
         
        // ajax
        $.ajax({
            type:"POST",
            url: "{{ url('edit-personnel') }}",
            data: { id: id },
            dataType: 'json',
            success: function(res){
              $('#ajaxBookModel').html("Edit Book");
              $('#ipakita').modal('show');
              $('#id').val(res.id);
              $('#personnel_name').val(res.personnel_name);
              $('#personnel_role').val(res.personnel_role);
              $('#personnel_contact').val(res.personnel_contact);
              $('#personnel_address').val(res.personnel_address);
              $('#personnel_gender').val(res.personnel_gender);
           }
        });
    });

    $('body').on('click', '#save_personnel', function (event) {
          var id = $("#id").val();
          var personnel_name = $("#personnel_name").val();
          var personnel_role = $("#personnel_role").val();
          var personnel_contact = $("#personnel_contact").val();
          var personnel_address = $("#personnelr_address").val();
          var personnel_gender = $("#personnel_gender").val();
          $("#save_personnel").html('Please Wait...');
          $("#save_personnel"). attr("disabled", true);
         
          // ajax
          $.ajax({
            type:"POST",
            url: "{{ url('add-personnel') }}",
            data: {
              id:id,
              personnel_name:personnel_name,
              personnel_role:personnel_role,
              personnel_contact:personnel_contact,
              personnel_address:personneladdress,
              personnel_gender:personnel_gender,
            },
            dataType: 'json',
            success: function(res){
            $("#ajax-book-model").modal('hide');
            var oTable = $('#personnels').dataTable();
            oTable.fnDraw(false);
            $("#save_personnel").html('Submit');
            $("#save_personnel"). attr("disabled", false);
           }
        });
    });
    });
</script>
@endsection