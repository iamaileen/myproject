@extends('layouts.master')
@section('title', 'Animal Shelter')
@section('content')


<h1>Rescuer Table <button type="button" id="addrescuer" class="btn btn-success">Add</button></h1>
<div class="row">

	<div class="col-md-15 col-md-offset-1">
        <table id="rescuers" class="table table-bordered table-responsive table-striped" style="text-align:center">
			    <thead >
				    <tr>
					    <th>ID</th>
					    <th>NAME</th>
					    <th>ADDRESS</th>
					    <th>CONTACT</th>
              <th>AGE</th>
              <th>GENDER</th>
					    <th>ACTION</th>
				    </tr>
			    </thead>
	    </table>
    <div class="modal fade" id="ipakita" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title" id="ajaxBookModel"></h4>
          </div>
          <div class="modal-body">
            <form action="javascript:void(0)" id="addEditBookForm" name="addEditBookForm" class="form-horizontal" method="POST">
              <input type="hidden" name="id" id="id">
              <div class="form-group">
                <label for="name" class="col-sm-1 control-label">Name</label>
                <div class="col-sm-12">
                  <input type="text" class="form-control" id="rescuer_name" name="rescuer_name" placeholder="Enter Name" maxlength="50" required="">
                </div>
              </div>  
              <div class="form-group">
                <label for="name" class="col-sm-1 control-label">Address</label>
                <div class="col-sm-12">
                  <input type="text" class="form-control" id="rescuer_address" name="rescuer_address" placeholder="Enter Address" maxlength="50" required="">
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-1 control-label">Contact</label>
                <div class="col-sm-12">
                  <input type="text" class="form-control" id="rescuer_contact" name="rescuer_contact" placeholder="Enter Conact" required="">
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-1 control-label">Age</label>
                <div class="col-sm-12">
                  <input type="text" class="form-control" id="rescuer_age" name="rescuer_age" placeholder="Enter Conact" required="">
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-1 control-label">Gender</label>
                <div class="col-sm-12">
                <input type="text" class="form-control" id="rescuer_gender" name="rescuer_gender" placeholder="Enter Gender" required="">
                </div>
              </div>
              <div class="col-sm-offset-5">
                <button type="submit" class="btn btn-success" id="save_rescuer" value="addrescuer">Save changes
                </button>
                {{-- <a href="{{route('data_rescuer.index')}}" type="submit" class="btn btn-primary">Back</a> --}}
              </div>
            </form>
          </div>
          <div class="modal-footer">
            
          </div>
        </div>
      </div>
    </div>
    </div>
</div>


@endsection
@section('scripts')
<script>
    $(document).ready(function() {
	$.ajaxSetup({
        headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
      $('#rescuers').DataTable({
            processing: true,
            serverSide: true,
            ajax: "{{ route('rescuer.index')}}",
            columns: [
              { data: 'id', name: 'id' },
			  { data: 'rescuer_name', name: 'rescuer_name' },
              { data: 'rescuer_address', name: 'rescuer_address' },
              { data: 'rescuer_contact', name: 'rescuer_contact' },
              { data: 'rescuer_age', name: 'rescuer_age' },
              { data: 'rescuer_gender', name: 'rescuer_gender' },
			  {data: 'Actions', name: 'Actions',orderable:false,},
             ]
        });

        $('body').on('click', '.delete', function () {
       if (confirm("Delete Record?") == true) {
        var id = $(this).data('id');
         
        // ajaxs
        $.ajax({
			type:'POST',
            url: "{{ url('delete-rescuer') }}",
            data: { id: id },
            dataType: 'json',
            success: function(res){
              var oTable = $('#rescuers').dataTable();
              oTable.fnDraw(false);
           }
        });
       }
    });

    $('#addrescuer').click(function () {
       $('#addEditBookForm').trigger("reset");
       $('#ajaxBookModel').html("Add Rescuer");
       $('#ipakita').modal('show');
    });

    $('body').on('click', '.edit', function () {
        var id = $(this).data('id');
         
        // ajax
        $.ajax({
            type:"POST",
            url: "{{ url('edit-rescuer') }}",
            data: { id: id },
            dataType: 'json',
            success: function(res){
              $('#ajaxBookModel').html("Edit Book");
              $('#ipakita').modal('show');
              $('#id').val(res.id);
              $('#rescuer_name').val(res.rescuer_name);
              $('#rescuer_address').val(res.rescuer_address);
              $('#rescuer_contact').val(res.rescuer_contact);
              $('#rescuer_age').val(res.rescuer_age);
              $('#rescuer_gender').val(res.rescuer_gender);
           }
        });
    });

    $('body').on('click', '#save_rescuer', function (event) {
          var id = $("#id").val();
          var rescuer_name = $("#rescuer_name").val();
          var rescuer_address = $("#rescuer_address").val();
          var rescuer_contact = $("#rescuer_contact").val();
          var rescuer_age = $("#rescuer_age").val();
          var rescuer_gender = $("#rescuer_gender").val();
          $("#save_rescuer").html('Please Wait...');
          $("#save_rescuer"). attr("disabled", true);
         
          // ajax
          $.ajax({
            type:"POST",
            url: "{{ url('add-rescuer') }}",
            data: {
              id:id,
              rescuer_name:rescuer_name,
              rescuer_address:rescuer_address,
              rescuer_contact:rescuer_contact,
              rescuer_age:rescuer_age,
              rescuer_gender:rescuer_gender,
            },
            dataType: 'json',
            success: function(res){
            $("#ajax-book-model").modal('hide');
            var oTable = $('#rescuers').dataTable();
            oTable.fnDraw(false);
            $("#save_rescuer").html('Submit');
            $("#save_rescuer"). attr("disabled", false);
           }
        });
    });
    });
</script>
@endsection