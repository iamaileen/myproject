@extends('layouts.app')
@section('content')

@section('title', 'Animals')

<div class="container">
	<table id="table">
		<thead>
			<tr>
				<th>Animal Name</th>
				<th>Breed</th>
				<th>Type</th>
				<th>Gender</th>
				<th>Age</th>
				<th>Rescue Date</th>
                <th>Status</th>
                <th>Image</th>
                
			</tr>
		</thead>
		<tbody>
			<tr>
				<td>{{$animal->animal_name}}</td>
				<td>{{$animal->animal_breed}}</td>
				<td>{{$animal->animal_type}}</td>
				<td>{{$animal->animal_gender}}</td>
				<td>{{$animal->animal_age}}</td>
                <td>{{$animal->rescue_date}}</td>
                <td>{{$animal->adopt_stat}}</td>
				<td><img src="{{ asset($animal->img_path) }}" width="100px" height="100px"></td>
			</tr>
		</tbody>

	</table>
	<div>
			@comments(['model' => $animal])
		</div>

	</div>
@endsection