@extends('layouts.navbar')
@section('title', 'Injuries')
@section('content')
    <div align="right">
      <a href="{{ route('injury.create') }}" class="btn btn-success btn-sm"><i class="fa fa-plus"></i> Create Record</a>
    </div>
    <br />
    <div class="table-responsive">
      <table id="injury_table" class="table table-bordered table-striped">
        <thead>
          <tr>
            <th>NAME</th>
              <th>TYPE </th>
              <th>DESCRIPTION</th>
              <th>ACTION</th>
          </tr>
        </thead>
      </table>
    </div>
  <br />
  <br />

  <script>
    $(document).ready(function()
    {
      $('#injury_table').DataTable({
        processing: true,
        serverSide: true,
        ajax: {
          url: "{{ route('injury.index') }}",
        },
        columns: [
        {
            data: 'injury_name',
            name: 'injury_name'
        },
      {
            data: 'injury_type',
            name: 'injury_type'
        },
      {
            data: 'injury_description',
            name: 'injury_description'
        },
        
        {
            data: 'action',
            name: 'action',
            orderable: false
        }
        ]
      });
    });
  </script>
@endsection