@extends('layouts.design')
@section('content')
    <div class = "card-header">
        Edit Injuries/Diseases Record
    </div>
    @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <div class = "card-body">
          {{ Form::model($injuries,['method'=>'PATCH','route' => ['injury.update', $injuries->id]]) }}

          {{-- {{ method_field('PATCH') }} --}}
              <div class = "form-group">
                  <label for="injury_name">Injury/Disease Name</label>
                  {{ Form::text('injury_name',null,array('class'=>'form-control','id'=>'injury_name')) }}
              </div>

              <div class = "from-group pt-3">
                  <label for="injury_type">Type</label><br>
                  <label>
                  @if ($injuries->injury_type == 'Injury')
                    {{ Form::radio('injury_type', 'injury', true)}}
                    Injury</label> 
                    <label>
                    {{ Form::radio('injury_type', 'Disease', false)}}
                    Disease</label> 
                  @else
                    {{ Form::radio('injury_type', 'Injury', false)}}
                    Injury</label> 
                    <label>
                    {{ Form::radio('injury_type', 'Disease', true)}}
                    Disease</label> 
                  @endif
              </div>

              <div class = "from-group pt-3">
                  <label for="injury_description">Description</label>
                  {{ Form::text('injury_description',null,array('class'=>'form-control','id'=>'injury_description')) }}
              </div>
              
              <div class="pr-2 pt-4">
                  <button address="submit" class="btn btn-success">Update</button>
                  <a href="{{route('injury.index')}}" address="submit" class="btn btn-primary">Back</a>
              </div>
                          
    </div>
        @csrf
        {!! Form::close() !!}
                
@endsection
                    