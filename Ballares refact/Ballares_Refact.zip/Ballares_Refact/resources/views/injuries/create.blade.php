@extends('layouts.design')
@section('content')
    <div class = "card-header">
        Add Injuries Record
    </div>
        <div class = "card-body">
        {!! Form::open(['route' => 'injury.store', 'files' => true]) !!}

              <div class = "form-group">
                  <label for="injury_name">Name</label>
                  <input type="text" name="injury_name" class="form-control" placeholder="Enter Injury/Disease Name"/>
                  @if ($errors->has('injury_name'))
                        <div class="alert alert-danger">
                            {{ $errors->first('injury_name') }}
                        </div>
                    @endif
              </div>

              <div class = "from-group pt-3">
              <label for="injury_type">Type</label><br>
                  <label for="injury_type">
                  <input type="radio" name="injury_type" value="Injury">
                  Injury</label> 
                  <label for="injury_type">
                  <input type="radio" name="injury_type" value="Disease">
                  Disease</label> 
                  @if ($errors->has('injury_type'))
                        <div class="alert alert-danger">
                            {{ $errors->first('injury_type') }}
                        </div>
                    @endif
              </div>

              <div class = "from-group pt-3">
                  <label for="injury_description">Description</label>
                  <input type="text" name="injury_description" class="form-control" placeholder="Add Description"/>
                  @if ($errors->has('injury_description'))
                        <div class="alert alert-danger">
                            {{ $errors->first('injury_description') }}
                        </div>
                    @endif
              </div>
              
              <div class="pr-2 pt-4">
                <a href="{{route('injury.index')}}" type="submit" class="btn btn-primary">Back</a>
                  <button type="submit" class="btn btn-success">Create</button>
                  
              </div>
                          
    </div>

        {!! Form::close() !!}
                
@endsection
                    