@extends('layouts.design')
@section('content')
    <div class = "card-header">
        Send Email
    </div>
        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
        <div class = "card-body">
        {!! Form::open(['route' => 'inquiries.store']) !!}
              <div class = "form-group">
                  <label for="messages_name">Name</label>
                  <input type="text" name="messages_name" class="form-control" placeholder="Enter Name" value="{{old('messages_name')}}" required/>
              </div>

              <div class = "from-group pt-3">
                  <label for="messages_email">Email Address<input type="text" name="messages_email" class="form-control" placeholder="sample@gmail.com" value="{{old('messages_name')}}" required/>
              </div>

              <div class = "from-group pt-3">
                  <label for="messages_phone">Phone</label>
                  <input type="text" name="messages_phone" class="form-control" placeholder="+63 --- ---- ---" value="{{old('messages_name')}}" required/>
              </div>

              <div class = "from-group pt-3">
                  <label for="messages_subject">Subject</label>
                  <input type="text" name="messages_subject" class="form-control" placeholder="Subject" value="{{old('messages_name')}}" required/>
              </div>
              
              <div class = "from-group pt-3">
                  <label for="messages_message">Message</label>
                  <textarea name="messages_message" class="form-control" rows="5" placeholder="Message" value="{{old('messages_name')}}" required></textarea>
              </div>
              
              <div class="pr-2 pt-4">
                  <button type="submit" class="btn btn-success">Create</button>
                  <a href="{{url('/')}}" type="submit" class="btn btn-primary">Back</a>   
            </div>
    </div>
         @csrf
        {!! Form::close() !!}           
@endsection
                    