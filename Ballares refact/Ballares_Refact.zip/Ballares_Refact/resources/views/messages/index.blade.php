@extends('layouts.navbar')

@section('content')
<div class="container pt-3 ">
<body style="background-color:GhostWhite;">
		<div class="row">
			<div class="col-md-15 col-md-offset-1">
				<h2>Emails Table</h2>
			@if ($message = Session::get('success'))
				<div class="alert alert-success alert-block">
					<button type="button" class="close" data-dismiss="alert">×</button> 
						<strong>{{ $message }}</strong>
				</div>
			@endif
			<div class="row">
				<div class="col-md-15 col-md-offset-1">
					<table class="table table-bordered table-responsive table-striped" style="text-align:center">
						<thead>
							<th>Name</th>
							<th>Email</th>
							<th>Phone</th>
							<th>Subject</th>
							<th>Message</th>
							<th>Action</th>
						</thead>
						<tbody>
							@foreach($messages as $message)
								<tr>
									<td>{{$message->messages_name}}</td>
									<td>{{$message->messages_email}}</td>
									<td>{{$message->messages_phone}}</td>
									<td>{{$message->messages_subject}}</td>
									<td>{{$message->messages_message}}</td>
                                    <td>
								    {!! Form::open(['method' => 'DELETE', 'route' => ['messages.destroy', $message->id]]) !!} 
									<button type="submit" data-toggle="modal" class="btn btn-danger"><i class='fa fa-trash'></i> Delete</button>		
									{!! Form::close() !!}
									</td>
								</div>
									
								</tr>
							@endforeach
						</tbody>
					</table>
				</div>
			</div>
		</div>
</body>
@endsection	
</html>