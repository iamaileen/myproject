@extends('layouts.profile')
@section('content')
{{--  PERSONNEL  --}}
@if(Auth::user()->role == "employee")
<div class="container pt-3 ">
<body style="background-color:GhostWhite;">
		<div class="row">
			<div class="col-md-15 col-md-offset-1">
				<h2>Personnels Profile</h2>
			@if ($message = Session::get('success'))
				<div class="alert alert-success alert-block">
					<button type="button" class="close" data-dismiss="alert">×</button> 
						<strong>{{ $message }}</strong>
				</div>
			@endif
			<div class="row">
				<div class="col-md-15 col-md-offset-1">
					<table class="table table-bordered table-responsive table-striped" style="text-align:center">
						<thead>
							<th>ID</th>
							<th>Name</th>
                            <th>Address</th>
                            <th>Role</th>
							<th>Contact</th>
							<th>Gender</th>
                            <th>Edit</th>
						</thead>
						<tbody>
                            <tr>
                                <td>{{$profile->id}}</td>
                                <td>{{$profile->personnel_name}}</td>
                                <td>{{$profile->personnel_address}}</td>
                                <td>{{$profile->personnel_role}}</td>
                                <td>{{$profile->personnel_contact}}</td>
                                <td>{{$profile->personnel_gender}}</td>
                                <td><a href="{{ route('personnels.edit',$profile->id) }}" data-toggle="modal" class="btn btn-success"><i class='fa fa-edit'></i> Edit</a> 
                                </td>
                            </div>
                                
                            </tr>
						</tbody>
					</table>
				</div>
			</div>

            <h2>Animal That Has Been Taken Care Of</h2>
            <div class="row">
				<div class="col-md-15 col-md-offset-1">
					<table class="table table-bordered table-responsive table-striped" style="text-align:center">
						<thead>
							<th>Name</th>
                            <th>Type</th>
							<th>Breed</th>
							<th>Gender</th>
                            <th>Age</th>
                            <th>Image</th>
                            <th>Status</th>
                            {{-- <th>Injury</th> --}}
						</thead>
						<tbody>
                            @foreach($query as $row)
                            <tr>
                                <td>{{$row->animal_name}}</td>
                                <td>{{$row->animal_type}}</td>
                                <td>{{$row->animal_breed}}</td>
                                <td>{{$row->animal_gender}}</td>
                                <td>{{$row->animal_age}}</td>
                                <td><img src="{{ asset($row->img_path) }}" width="100px" height="100px"></td>
                                <td>{{$row->adopt_stat}}</td>
                                {{-- <td>
                                    @foreach($animal_injury as $injure)
										@if($row->id == $injure->animal_id)
											- {{$injure->injury_name}} <br>
										@endif
									@endforeach
					            </td> --}}
				            </tr>
				            @endforeach
		</div>
</body>
</html>


{{--RESCUER--}}
@elseif(Auth::user()->role == "rescuer")
<div class="container pt-3 ">
<body style="background-color:GhostWhite;">
		<div class="row">
			<div class="col-md-15 col-md-offset-1">
				<h2>Rescuer Profile</h2>
			@if ($message = Session::get('success'))
				<div class="alert alert-success alert-block">
					<button type="button" class="close" data-dismiss="alert">×</button> 
						<strong>{{ $message }}</strong>
				</div>
			@endif
			<div class="row">
				<div class="col-md-15 col-md-offset-1">
					<table class="table table-bordered table-responsive table-striped" style="text-align:center">
						<thead>
							<th>ID</th>
							<th>Name</th>
                            <th>Address</th>
							<th>Contact</th>
							<th>Gender</th>
                            <th>Edit</th>
						</thead>
						<tbody>
                            <tr>
                                <td>{{$profile->id}}</td>
                                <td>{{$profile->rescuer_name}}</td>
                                <td>{{$profile->rescuer_address}}</td>
                                <td>{{$profile->rescuer_contact}}</td>
                                <td>{{$profile->rescuer_gender}}</td>
                                <td><a href="{{ route('rescuers.edit',$profile->id) }}" data-toggle="modal" class="btn btn-success"><i class='fa fa-edit'></i> Edit</a> 
                                </td>
                            </div>
                            </tr>
						</tbody>
					</table>
				</div>
			</div>

            <h2>Animal Rescued</h2>
            <div class="row">
				<div class="col-md-15 col-md-offset-1">
					<table class="table table-bordered table-responsive table-striped" style="text-align:center">
						<thead>
							<th>Name</th>
                            <th>Type</th>
							<th>Breed</th>
							<th>Gender</th>
                            <th>Age</th>
                            <th>Status</th>
                            {{-- <th>Injury</th> --}}
                            <th>Image</th>
						</thead>
						<tbody>
                            @foreach($query as $row)
                            <tr>
                                <td>{{$row->animal_name}}</td>
                                <td>{{$row->animal_type}}</td>
                                <td>{{$row->animal_breed}}</td>
                                <td>{{$row->animal_gender}}</td>
                                <td>{{$row->animal_age}}</td>
                                <td>{{$row->adopt_stat}}</td>
                                {{-- <td>
                                    @foreach($animal_injury as $injure)
										@if($row->id == $injure->animal_id)
											- {{$injure->injury_name}} <br>
										@endif
									@endforeach
					            </td> --}}
					            <td><img src="{{ asset($row->img_path) }}" width="100px" height="100px"></td>
				            </tr>
				            @endforeach
						</tbody>
					</table>
				</div>
			</div>

		</div>
</body>
</html>



{{--  ADOPTER  --}}
@elseif(Auth::user()->role == "adopter")
<div class="container pt-3 ">
<body style="background-color:GhostWhite;">
		<div class="row">
			<div class="col-md-15 col-md-offset-1">
				<h2>Adopter Profile</h2>
			@if ($message = Session::get('success'))
				<div class="alert alert-success alert-block">
					<button type="button" class="close" data-dismiss="alert">×</button> 
						<strong>{{ $message }}</strong>
				</div>
			@endif
			<div class="row">
				<div class="col-md-15 col-md-offset-1">
					<table class="table table-bordered table-responsive table-striped" style="text-align:center">
						<thead>
							<th>ID</th>
							<th>Name</th>
                            <th>Address</th>
							<th>Contact</th>
							<th>Gender</th>
                            <th>Edit</th>
						</thead>
						<tbody>
                            <tr>
                                <td>{{$profile->id}}</td>
                                <td>{{$profile->adopter_name}}</td>
                                <td>{{$profile->adopter_address}}</td>
                                <td>{{$profile->adopter_contact}}</td>
                                <td>{{$profile->adopter_gender}}</td>
                                <td><a href="{{ route('adopters.edit',$profile->id) }}" data-toggle="modal" class="btn btn-success"><i class='fa fa-edit'></i> Edit</a> 
                                </td>
                            </div>
                                
                            </tr>
						</tbody>
					</table>
				</div>
			</div>

            <h2>Adopted Animal</h2>
            <div class="row">
				<div class="col-md-15 col-md-offset-1">
					<table class="table table-bordered table-responsive table-striped" style="text-align:center">
						<thead>
							<th>Name</th>
                            <th>Type</th>
							<th>Breed</th>
							<th>Gender</th>
                            <th>Age</th>
                            <th>Image</th>
						</thead>
						<tbody>
                            @foreach($query as $row)
                            <tr>
                                <td>{{$row->animal_name}}</td>
                                <td>{{$row->animal_type}}</td>
                                <td>{{$row->animal_breed}}</td>
                                <td>{{$row->animal_gender}}</td>
                                <td>{{$row->animal_age}}</td>
                                <td><img src="{{ asset($row->img_path) }}" width="100px" height="100px"></td>
				            </tr>
				            @endforeach
						</tbody>
					</table>
				</div>
			</div>
		</div>
</body>

@endif
@endsection	