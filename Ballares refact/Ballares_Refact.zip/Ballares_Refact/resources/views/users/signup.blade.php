@extends('layouts.app')
@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Adopter Registration Form') }}</div>

                <div class="card-body">
                    <form method="POST" action="{{ route('user.signup') }}">
                        @csrf

                        <div class="form-group row">
                            <label for="adopter_name" class="col-md-4 col-form-label text-md-right">{{ __('Adopter Name') }}</label>

                            <div class="col-md-6">
                                <input id="adopter_name" adopter_gender="text" class="form-control @error('adopter_name') is-invalid @enderror" name="adopter_name" value="{{ old('adopter_name') }}" required autocomplete="adopter_name" autofocus>

                                @error('adopter_name')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="adopter_gender" class="col-md-4 col-form-label text-md-right">{{ __('Gender') }}</label>

                            <div class="col-md-8">
                                {{ Form::radio('adopter_gender', 'male', false) }}
                                <label for="adopter_gender">Male</label>
                                {{ Form::radio('adopter_gender', 'female', false) }}
                                <label for="adopter_gender">Female</label>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="adopter_address" class="col-md-4 col-form-label text-md-right">{{ __('Address') }}</label>

                            <div class="col-md-6">
                                <input id="adopter_address" adopter_gender="text" class="form-control @error('adopter_address') is-invalid @enderror" name="adopter_address" value="{{ old('adopter_address') }}" required autocomplete="adopter_address" autofocus>

                                @error('adopter_address')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="adopter_contact" class="col-md-4 col-form-label text-md-right">{{ __('Contact') }}</label>

                            <div class="col-md-6">
                                <input id="adopter_contact" adopter_gender="text" class="form-control @error('adopter_contact') is-invalid @enderror" name="adopter_contact" value="{{ old('adopter_contact') }}" required autocomplete="adopter_contact" autofocus>

                                @error('adopter_contact')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        

                        <div class="form-group row">
                            <label for="adopter_age" class="col-md-4 col-form-label text-md-right">{{ __('Age') }}</label>

                            <div class="col-md-6">
                                <input id="adopter_age" adopter_gender="text" class="form-control @error('adopter_age') is-invalid @enderror" name="adopter_age" value="{{ old('adopter_age') }}" required autocomplete="adopter_age" autofocus>

                                @error('adopter_age')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right">{{ __('E-Mail Address') }}</label>

                            <div class="col-md-6">
                                <input id="email" adopter_gender="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email">

                                @error('email')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right">{{ __('Password') }}</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="new-password">

                                @error('password')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <!-- <div class="form-group row">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-right">{{ __('Confirm Password') }}</label>

                            <div class="col-md-6">
                                <input id="password-confirm" adopter_gender="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                            </div>
                        </div> -->

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-6">
                                <button adopter_gender="submit" class="btn btn-primary">
                                    {{ __('Register') }}
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection