@extends('layouts.navbar')


@section('content')
<div class="container pt-3 ">
<body style="background-color:GhostWhite;">
		<div class="row">
			<div class="col-md-15 col-md-offset-1">
				<h2>Admin Profile</h2>
			@if ($message = Session::get('success'))
				<div class="alert alert-success alert-block">
					<button type="button" class="close" data-dismiss="alert">×</button> 
						<strong>{{ $message }}</strong>
				</div>
			@endif
			<div class="row">
				<div class="col-md-15 col-md-offset-1">
					<table class="table table-bordered table-responsive table-striped" style="text-align:center">
						<thead>
							<th>ID</th>
							<th>Name</th>
                            <th>Email</th>
							<th>Role</th>
							<th>Action</th>
						</thead>
						<tbody>
                            <tr>
                                <td>{{$admin->id}}</td>
                                <td>{{$admin->name}}</td>
                                <td>{{$admin->email}}</td>
                                <td>{{$admin->role}}</td>
                                <td><a href="{{ route('admin.edit',$admin->id) }}" data-toggle="modal" class="btn btn-success"><i class='fa fa-edit'></i> Edit</a></td>
                            </tr>
						</tbody>
					</table>
				</div>
			</div>

	</div>
</body>

		<div class="row">
			<h2>CHARTS</h2>
        <div  class="col-sm-6 col-md-6">
            @if(empty($adoptedanimalsChart))
                <div></div>
            @else
                <div>{!! $adoptedanimalsChart->container() !!}</div>
                {!! $adoptedanimalsChart->script() !!}
            @endif
        </div>
        <div  class="col-sm-6 col-md-6">
            @if(empty($injurydiseaseChart))
                <div></div>
            @else
                <div>{!! $injurydiseaseChart->container() !!}</div>
                {!! $injurydiseaseChart->script() !!}
            @endif
        </div>

    <div  class="col-sm-6 col-md-6">
        @if(empty($rescuedChart))
                <div></div>
        @else
            <div>{!! $rescuedChart->container() !!}</div>
            {!! $rescuedChart->script() !!}
        @endif
    </div>
		</div>

@endsection	
</html>


{{-- 		<div class="row">
        <div  class="col-sm-6 col-md-6">
            @if(empty($adoptedanimalsChart))
                <div></div>
            @else
                <div>{!! $adoptedanimalsChart->container() !!}</div>
                {!! $adoptedanimalsChart->script() !!}
            @endif
        </div>
        <div  class="col-sm-6 col-md-6">
            @if(empty($injurydiseaseChart))
                <div></div>
            @else
                <div>{!! $injurydiseaseChart->container() !!}</div>
                {!! $injurydiseaseChart->script() !!}
            @endif
        </div>

    <div  class="col-sm-6 col-md-6">
        @if(empty($rescuedChart))
                <div></div>
        @else
            <div>{!! $rescuedChart->container() !!}</div>
            {!! $rescuedChart->script() !!}
        @endif
    </div>
		</div> --}}