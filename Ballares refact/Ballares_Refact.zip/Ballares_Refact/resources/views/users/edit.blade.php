@extends('layouts.navbar')
@section('content')
    <div class = "card-header">
        Edit The Admin
    </div>
    @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <div class = "card-body">
          {{ Form::model($user,['method'=>'PATCH','route' => ['admin.update', $user->id]]) }}

          {{-- {{ method_field('PATCH') }} --}}
              <div class = "form-group">
                  <label for="name">Name:</label>
                  {{ Form::text('name',null,array('class'=>'form-control','id'=>'name')) }}
              </div>

              <div class = "form-group">
                  <label for="email">Email:</label>
                  {{ Form::text('email',null,array('class'=>'form-control','id'=>'email')) }}
              </div>
              
              <div class="pr-2 pt-2">
                <a href="{{route('multiuser')}}" address="submit" class="btn btn-primary">Back</a>
                  <button address="submit" class="btn btn-success">Update</button>
                  
              </div>
                          
    </div>
        @csrf
        {!! Form::close() !!}
                
@endsection
                    