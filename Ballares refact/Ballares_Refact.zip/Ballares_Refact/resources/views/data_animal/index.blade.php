@extends('layouts.master')
@section('title', 'Animal Shelter')
@section('content')





<h1>Animal Table <button type="button" id="addanimal" class="btn btn-success">Add</button></h1>
<div class="row">

	<div class="col-md-15 col-md-offset-1">
        <table id="animals" class="table table-bordered table-responsive table-striped" style="text-align:center">
			    <thead >
				    <tr>
					    <th>ID</th>
					    <th>NAME</th>
					    <th>TYPE</th>
					    <th>BREED</th>
             			<th>GENDER</th>
              			<th>AGE</th>
					    <th>IMAGE</th>
					    <th>ACTION</th>
				    </tr>
			    </thead>
	    </table>
    <div class="modal fade" id="ipakita" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title" id="ajaxBookModel"></h4>
          </div>
          <div class="modal-body">
            <form action="javascript:void(0)" id="addEditBookForm" name="addEditBookForm" class="form-horizontal" method="POST">
              <input type="hidden" name="id" id="id">
              <div class="form-group">
                <label for="name" class="col-sm-1 control-label">Name</label>
                <div class="col-sm-12">
                  <input type="text" class="form-control" id="animal_name" name="animal_name" placeholder="Enter Animal Name" maxlength="50" required="">
                </div>
              </div>  
              <div class="form-group">
                <label for="name" class="col-sm-1 control-label">Type</label>
                <div class="col-sm-12">
                  <input type="text" class="form-control" id="animal_type" name="animal_type" placeholder="Enter Animal Type" maxlength="50" required="">
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-1 control-label">Breed</label>
                <div class="col-sm-12">
                  <input type="text" class="form-control" id="animal_breed" name="animal_breed" placeholder="Enter Animal Breed" required="">
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-1 control-label">Gender</label>
                <div class="col-sm-12">
                  <input type="text" class="form-control" id="animal_gender" name="animal_gender" placeholder="Enter Animal Gender" required="">
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-1 control-label">Age</label>
                <div class="col-sm-12">
                <input type="text" class="form-control" id="animal_age" name="animal_age" placeholder="Enter Animal Age" required="">
                </div>
              </div>
              <div class="from-group">
                  <label for="image"  class="col-sm-1 control-label">Choose image</label>
                  <input type="file" class="form-control" id="image" name="img_path"/>
                  @if ($errors->has('img_path'))
                        <div class="alert alert-danger">
                            {{ $errors->first('img_path') }}
                        </div>
                    @endif
              </div>
              <div class="col-sm-offset-5">
                <button type="submit" class="btn btn-success" id="save_animal" value="addanimal">Save changes
                </button>
                {{-- <a href="{{route('data_animal.index')}}" type="submit" class="btn btn-primary">Back</a> --}}
              </div>
            </form>
          </div>
          <div class="modal-footer">
            
          </div>
        </div>
      </div>
    </div>
    </div>
</div>


@endsection
@section('scripts')
<script>
    $(document).ready(function() {
	$.ajaxSetup({
        headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
      $('#animals').DataTable({
            processing: true,
            serverSide: true,
            ajax: "{{ route('animal.index') }}",
            columns: [
              { data: 'id', name: 'id' },
			  { data: 'animal_name', name: 'animal_name' },
              { data: 'animal_type', name: 'animal_type' },
              { data: 'animal_breed', name: 'animal_breed' },
              { data: 'animal_gender', name: 'animal_gender' },
              { data: 'animal_age', name: 'animal_age' },
              { data: 'img_path', name: 'img_path' },
			  {data: 'Actions', name: 'Actions',orderable:false,},
             ]
        });

        $('body').on('click', '.delete', function () {
       if (confirm("Delete Record?") == true) {
        var id = $(this).data('id');
         
        // ajaxs
        $.ajax({
			type:'POST',
            url: "{{ url('delete-animal') }}",
            data: { id: id },
            dataType: 'json',
            success: function(res){
              var oTable = $('#animals').dataTable();
              oTable.fnDraw(false);
           }
        });
       }
    });

    $('#addanimal').click(function () {
       $('#addEditBookForm').trigger("reset");
       $('#ajaxBookModel').html("Add Animal");
       $('#ipakita').modal('show');
    });

    $('body').on('click', '.edit', function () {
        var id = $(this).data('id');
         
        // ajax
        $.ajax({
            type:"POST",
            url: "{{ url('edit-animal') }}",
            data: { id: id },
            dataType: 'json',
            success: function(res){
              $('#ajaxBookModel').html("Edit Book");
              $('#ipakita').modal('show');
              $('#id').val(res.id);
              $('#animal_name').val(res.animal_name);
              $('#animal_type').val(res.animal_type);
              $('#animal_breed').val(res.animal_breed);
              $('#animal_gender').val(res.animal_gender);
              $('#animal_age').val(res.animal_age);
              $('#img_path').val(res.img_path);

           }
        });
    });

    $('body').on('click', '#save_animal', function (event) {
          var id = $("#id").val();
          var animal_name = $("#animal_name").val();
          var animal_type = $("#animal_type").val();
          var animal_breed = $("#animal_breed").val();
          var animal_gender = $("#animal_gender").val();
          var animal_age = $("#animal_age").val();
          var img_path = $("#img_path").val();
          $("#save_animal").html('Please Wait...');
          $("#save_animal"). attr("disabled", true);
         
          // ajax
          $.ajax({
            type:"POST",
            url: "{{ url('add-animal') }}",
            data: {
              id:id,
            animal_name:animal_name,
            animal_type:animal_type,
            animal_breed:animal_breed,
            animal_gender:animal_gender,
            animal_age:animal_age,
            img_path:img_path,
            },
            dataType: 'json',
            success: function(res){
            $("#ajax-book-model").modal('hide');
            var oTable = $('#animals').dataTable();
            oTable.fnDraw(false);
            $("#save_animal").html('Submit');
            $("#save_animal"). attr("disabled", false);
           }
        });
    });
    });
</script>
@endsection