@extends('layouts.design')
@section('content')
    <div class = "card-header">
        Add Adopter Record
    </div>
        <div class = "card-body">
          {!! Form::open(['route' => 'adopters.store']) !!}
              <div class = "form-group">
                  <label for="adopter_name">Name</label>
                  <input type="text" name="adopter_name" class="form-control" placeholder="Enter Adopter Name"/>
                  @if ($errors->has('adopter_name'))
                        <div class="alert alert-danger">
                            {{ $errors->first('adopter_name') }}
                        </div>
                    @endif
              </div>

              <div class = "from-group pt-3">
                  <label for="adopter_contact">Contact</label>
                  <input type="text" name="adopter_contact" class="form-control" placeholder="Enter Adopter Contact"/>
                  @if ($errors->has('adopter_contact'))
                        <div class="alert alert-danger">
                            {{ $errors->first('adopter_contact') }}
                        </div>
                    @endif
              </div>

              <div class = "from-group pt-3">
                  <label for="adopter_address">Address</label>
                  <input type="text" name="adopter_address" class="form-control" placeholder="Enter Adopter Address"/>
                  @if ($errors->has('adopter_address'))
                        <div class="alert alert-danger">
                            {{ $errors->first('adopter_address') }}
                        </div>
                    @endif
              </div>

              <div class = "from-group pt-3">
                  <label for="adopter_age">Age</label>
                  <input type="integer" name="adopter_age" class="form-control" placeholder="Enter adopter age"/>
                  @if ($errors->has('adopter_age'))
                        <div class="alert alert-danger">
                            {{ $errors->first('adopter_age') }}
                        </div>
                    @endif
              </div>

              <div class = "from-group pt-3">
                  <label for="adopter_gender">Gender</label><br>
                  <label for="male">
                  <input type="radio" name="adopter_gender" value="male">
                  Male</label> 
                  <label for="female">
                  <input type="radio" name="adopter_gender" value="female">
                  Female</label> 
                  @if ($errors->has('adopter_gender'))
                        <div class="alert alert-danger">
                            {{ $errors->first('adopter_gender') }}
                        </div>
                    @endif
              </div>
              <div class = "from-group pt-3">
                    <label>Animal for Adoption</label>
                    @foreach ($adopt_animal as $adopt)
                        @if ($adopt->injury_name == null)
                        <div class="form-check form-check-block">
                            {!! Form::checkbox('id[]', $adopt->id, null, array('class' => 'form-check-input','id'=>'animal_id')) !!}
                            {!! Form::label('animal_name', $adopt->animal_name, array('class' => 'form-check-label')) !!}
                        </div>
                        @endif
                     @endforeach  
                     @if ($errors->has('id'))
                        <div class="alert alert-danger">
                            {{ $errors->first('id') }}
                        </div>
                    @endif
                </div>

                <div class = "from-group pt-3">
                  <label for="adopted_date">Adopted Date</label>
                  {{ Form::date('adopted_date',null,array('class'=>'form-control')) }}
                  @if ($errors->has('adopted_date'))
                        <div class="alert alert-danger">
                            {{ $errors->first('adopted_date') }}
                        </div>
                    @endif
              </div>

                <div class = "form-group">
                  <label for="email">Email</label>
                  <input type="text" name="email" class="form-control" placeholder="Enter Email"/>
                  @if ($errors->has('email'))
                        <div class="alert alert-danger">
                            {{ $errors->first('email') }}
                        </div>
                    @endif
              </div>

                <div class = "form-group">
                  <label for="password">Password</label>
                  <input type="password" name="password" class="form-control" placeholder="Enter Password"/>
                  @if ($errors->has('password'))
                        <div class="alert alert-danger">
                            {{ $errors->first('password') }}
                        </div>
                    @endif
              </div>

              
              <div class="pr-2 pt-4">
                  <button type="submit" class="btn btn-success">Create</button>
                  <a href="{{route('adopters.index')}}" type="submit" class="btn btn-primary">Back</a>
              </div>
                          
    </div>
        @csrf
        {!! Form::close() !!}
                
@endsection
                    