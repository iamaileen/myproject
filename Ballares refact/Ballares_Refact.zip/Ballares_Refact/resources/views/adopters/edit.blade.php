@extends('layouts.design')
@section('content')
    <div class = "card-header">
        Edit Adopter Record
    </div>
        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
        <div class = "card-body">
          {{ Form::model($adopter,['method'=>'PATCH','route' => ['adopters.update', $adopter->id]]) }}

          {{-- {{ method_field('PATCH') }} --}}
              <div class = "form-group">
                  <label for="adopter_name">Name</label>
                  {{ Form::text('adopter_name',null,array('class'=>'form-control','id'=>'adopter_name')) }}
              </div>

              <div class = "from-group pt-3">
                  <label for="adopter_contact">Contact</label>
                  {{ Form::text('adopter_contact',null,array('class'=>'form-control','id'=>'adopter_contact')) }}
              </div>

              <div class = "from-group pt-3">
                  <label for="adopter_address">Age</label>
                  {{ Form::text('adopter_address',null,array('class'=>'form-control','id'=>'adopter_address')) }}
              </div>

              <div class = "from-group pt-3">
                  <label for="adopter_age">Age</label>
                  {{ Form::text('adopter_age',null,array('class'=>'form-control','id'=>'adopter_age')) }}
              </div>

              <div class = "from-group pt-3">
                  <label for="adopter_gender">Gender</label><br>
                  <label>
                  @if ($adopter->adopter_gender == 'male')
                    {{ Form::radio('adopter_gender', 'male', true)}}
                    Male</label> 
                    <label>
                    {{ Form::radio('adopter_gender', 'female', false)}}
                    Female</label> 
                  @else
                    {{ Form::radio('adopter_gender', 'male', false)}}
                    Male</label> 
                    <label>
                    {{ Form::radio('adopter_gender', 'female', true)}}
                    Female</label> 
                  @endif
              </div>
            
              <div class = "from-group pt-3">
              <label>Animal for Adoption:</label>
                    @foreach($animal_list as $adopted_id => $id_animal)
                        <div class="form-check form-check-block">
                            @if(in_array($adopted_id, $adopted_animal))
                                {!! Form::checkbox('adopted_id[]', $adopted_id, true, array('class' => 'form-check-input', 
                                'id' => 'id_animal')) !!}

                                {!! Form::label('id_animal',$id_animal, array('class' => 'form-check-label')) !!}
                            @else
                                {!! Form::checkbox('adopted_id[]', $adopted_id, null, array('class' => 'form-check-input', 
                                'id' => 'id_animal')) !!}

                                {!! Form::label('id_animal',$id_animal, array('class' => 'form-check-label')) !!}
                            @endif
                        </div>
                    @endforeach
                </div>

               <div class = "from-group pt-3">
                  <label for="adopted_date">Adopted Date</label>
                  {!! Form::date('adopted_date',null,array('class'=>'form-control','id'=>'adopted_date')) !!}
              </div>

              
              <div class="pr-2 pt-4">
                  <button type="submit" class="btn btn-success">Update</button>
                  <a href="{{url()->previous()}}" type="submit" class="btn btn-primary">Back</a>
              </div>
                          
    </div>
        @csrf
        {!! Form::close() !!}
                
@endsection
                    