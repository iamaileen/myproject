@extends('layouts.navbar')

@section('content')
<div class="container pt-3 ">
		<div class="row">
			<div class="col-md-15 col-md-offset-1">
				<h2>Adopters Table
					<a class="btn btn-primary pull-right" type="button" href="{{route('adopters.create')}}" ><i class="btn btn-success"></i>Add Adopter</a>
				</h2>
			@if ($message = Session::get('success'))
				<div class="alert alert-success alert-block">
					<button type="button" class="close" data-dismiss="alert">×</button> 
						<strong>{{ $message }}</strong>
				</div>
			@endif
			<div class="row">
				<div class="col-md-15 col-md-offset-1">
					<table class="table table-bordered table-responsive table-striped" style="text-align:center">

						<thead>
							<th>ID</th>
							<th>Name</th>
							<th>Contact</th>
							<th>Address</th>
							<th>Age</th>
							<th>Gender</th>
							<th>Animal Adopted</th>
							<th>Date Adopted</th>
							<th>Action</th>
						</thead>
						<tbody>
							@foreach($adopters as $adopter)
								<tr>
									<td>{{$adopter->id}}</td>
									<td>{{$adopter->adopter_name}}</td>
									<td>{{$adopter->adopter_contact}}</td>
									<td>{{$adopter->adopter_address}}</td>
									<td>{{$adopter->adopter_age}}</td>
									<td>{{$adopter->adopter_gender}}</td>
									<td>
									@foreach($animals as $animal)
										@if($animal->adopter_id == $adopter->id)
											- {{$animal->animal_name}} <br>
										@endif
									@endforeach
									</td>
									<td>{{$adopter->adopted_date}}</td>
								{!! Form::open(['method' => 'DELETE', 'route' => ['adopters.destroy', $adopter->id]]) !!}
									<td><a href="{{ route('adopters.edit',$adopter->id) }}" data-toggle="modal" class="btn btn-success"><i class='fa fa-edit'></i> Edit</a> 
									<button type="submit" data-toggle="modal" class="btn btn-danger"><i class='fa fa-trash'></i> Delete</button>		
									{!! Form::close() !!}
									</td>
								
									
								</tr>
							
							@endforeach
						</tbody>
					</table>
				</div>
				</div>
			</div>
		</div>
	</div>
@endsection	
</html>