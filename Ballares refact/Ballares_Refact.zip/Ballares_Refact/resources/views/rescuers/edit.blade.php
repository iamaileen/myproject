@extends('layouts.design')
@section('content')
    <div class = "card-header">
        Edit Rescuer Record
    </div>
    @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <div class = "card-body">
          {{ Form::model($rescuer,['method'=>'PATCH','route' => ['rescuers.update', $rescuer->id]]) }}

          {{-- {{ method_field('PATCH') }} --}}
              <div class = "form-group">
                  <label for="rescuer_name">Name</label>
                  {{ Form::text('rescuer_name',null,array('class'=>'form-control','id'=>'rescuer_name')) }}
              </div>

              <div class = "from-group pt-3">
                  <label for="rescuer_gender">Gender</label><br>
                  <label>
                  @if ($rescuer->rescuer_gender == 'male')
                    {{ Form::radio('rescuer_gender', 'male', true)}}
                    Male</label> 
                    <label>
                    {{ Form::radio('rescuer_gender', 'female', false)}}
                    Female</label> 
                  @else
                    {{ Form::radio('rescuer_gender', 'male', false)}}
                    Male</label> 
                    <label>
                    {{ Form::radio('rescuer_gender', 'female', true)}}
                    Female</label> 
                  @endif
              </div>

              <div class = "from-group pt-3">
                  <label for="rescuer_address">Address</label>
                  {{ Form::text('rescuer_address',null,array('class'=>'form-control','id'=>'rescuer_address')) }}
              </div>

              <div class = "from-group pt-3">
                  <label for="rescuer_contact">contact</label>
                  {{ Form::text('rescuer_contact',null,array('class'=>'form-control','id'=>'rescuer_contact')) }}
              </div>

              <div class = "from-group pt-3">
                  <label for="rescuer_age">Age</label>
                  {{ Form::text('rescuer_age',null,array('class'=>'form-control','id'=>'rescuer_age')) }}
              </div>

              
              <div class="pr-2 pt-4">
                  <button address="submit" class="btn btn-success">Update</button>
                  <a href="{{url()->previous()}}" address="submit" class="btn btn-primary">Back</a>
              </div>
                          
    </div>
        @csrf
        {!! Form::close() !!}
                
@endsection
                    