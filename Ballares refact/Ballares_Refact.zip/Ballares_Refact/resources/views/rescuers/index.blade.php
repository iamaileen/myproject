@extends('layouts.navbar')
@section('title', 'Rescuers')
@section('content')
    <div align="right">
      <a href="{{ route('rescuers.create') }}" class="btn btn-success btn-sm"><i class="fa fa-plus"></i> Create Record</a>
    </div>
    <br />
    <div class="table-responsive">
      <table id="rescuer_table" class="table table-bordered table-striped">
        <thead>
          <tr>
            <th>NAME</th>
            <th>GENDER</th>
            <th>AGE</th>
            <th>ADDRESS</th>
            <th>CONTACT</th>
            <th>ACTION</th>
          </tr>
        </thead>
      </table>
    </div>
  <br />
  <br />

  <script>
    $(document).ready(function()
    {
      $('#rescuer_table').DataTable({
        processing: true,
        serverSide: true,
        ajax: {
          url: "{{ route('rescuers.index') }}",
        },
        columns: [
        {
            data: 'rescuer_name',
            name: 'rescuer_name'
        },

        {
            data: 'rescuer_gender',
            name: 'rescuer_gender'
        },
      {
            data: 'rescuer_age',
            name: 'rescuer_age'
        },

        {
            data: 'rescuer_address',
            name: 'rescuer_address'
        },
      {
            data: 'rescuer_contact',
            name: 'rescuer_contact'
        },
        

        
        {
            data: 'action',
            name: 'action',
            orderable: false
        }
        ]
      });
    });
  </script>
@endsection