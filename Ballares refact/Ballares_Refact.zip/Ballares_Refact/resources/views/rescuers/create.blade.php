@extends('layouts.design')
@section('content')
    <div class = "card-header">
        Add Rescuers Record
    </div>
        <div class = "card-body">
          {!! Form::open(['route' => 'rescuers.store', 'files' => true]) !!}
              <div class = "form-group">
                  <label for="rescuer_name">Name</label>
                  <input type="text" name="rescuer_name" class="form-control" placeholder="Enter Rescuer Name"/>
                  @if ($errors->has('rescuer_name'))
                        <div class="alert alert-danger">
                            {{ $errors->first('rescuer_name') }}
                        </div>
                    @endif
              </div>

              <div class = "from-group pt-3">
                  <label for="rescuer_type">Address</label>
                    <input type="text" name="rescuer_address" class="form-control" placeholder="Rescuer Address"/>
                  @if ($errors->has('rescuer_address'))
                        <div class="alert alert-danger">
                            {{ $errors->first('rescuer_address') }}
                        </div>
                    @endif
                </div>

              <div class = "from-group pt-3">
                  <label for="rescuer_age">Age</label>
                  <input type="text" name="rescuer_age" class="form-control" placeholder="Enter Rescuer Age"/>
                  @if ($errors->has('rescuer_age'))
                        <div class="alert alert-danger">
                            {{ $errors->first('rescuer_age') }}
                        </div>
                    @endif
              </div>

              <div class = "from-group pt-3">
                  <label for="rescuer_gender">Gender</label><br>
                  <label for="male">Male</label> <input type="radio" name="rescuer_gender" value="male">
                  <label for="female">Female</label> <input type="radio" name="rescuer_gender" value="female">
                  @if ($errors->has('rescuer_gender'))
                        <div class="alert alert-danger">
                            {{ $errors->first('rescuer_gender') }}
                        </div>
                    @endif
              </div>

              <div class = "from-group pt-3">
                  <label for="rescuer_breed">Contact</label>
                  <input type="text" name="rescuer_contact" class="form-control" placeholder="Enter Rescuer Contact"/>
                  @if ($errors->has('rescuer_contact'))
                        <div class="alert alert-danger">
                            {{ $errors->first('rescuer_contact') }}
                        </div>
                    @endif
              </div>
              
              <div class="pr-2 pt-4">
                  <button type="submit" class="btn btn-success">Create</button>
                  <a href="{{route('rescuers.index')}}" type="submit" class="btn btn-primary">Back</a>
              </div>
                          
    </div>
        @csrf
        {!! Form::close() !!}
                
@endsection
                    