@extends('layouts.app')
@section('content')
	<table id="table">
			<thead>
				<th>ID</th>
				<th>Name</th>
				<th>Type</th>
				<th>Breed</th>
				<th>Gender</th>
				<th>Age</th>
				{{-- <th>Rescuer</th> --}}
				<th>Date Rescued</th>
				{{-- <th>Adoption Status</th> --}}
				<th>Image</th>
			</thead>
			<tbody>
				@foreach($animals as $animal)
					<tr>
						<td>{{$animal->id}}</td>
						
						<td>{{$animal->animal_name}}</td>
						<td>{{$animal->animal_type}}</td>
						<td>{{$animal->animal_breed}}</td>
						<td>{{$animal->animal_gender}}</td>
						<td>{{$animal->animal_age}}</td>
						{{-- <td>{{$animal->rescuer_name}}</td> --}}
						<td>{{$animal->rescue_date}}</td>
						{{-- <td>{{$animal->adopt_stat}}</td> --}}
						<td><img src="{{ asset($animal->img_path)}}" width="100px" height="100px"></td>
					</tr>
				@endforeach
			</tbody>
	</table>
@endsection	
