<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Animal;
use App\Models\Rescuer;
use App\Models\Injury;
use App\Models\Personnel;
use View;
use Redirect;
use DB;
use DataTables;
use App\Events\QuoteCreated;
use Illuminate\Support\Facades\Event;
use App\Models\AnimalLog;

class AnimalController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if($request->ajax())
        {
            $data = DB::table('animals')->join('rescuers', 'rescuers.id', 'animals.rescuer_id')->join('personnels', 'personnels.id', 'animals.personnel_id')->select('animals.id', 'animals.animal_type', 'animal_breed', 'animal_name', 'animal_gender', 'animal_age', 'rescue_date', 'img_path', 'rescuer_name', 'personnel_name', 'adopt_stat')->get();
            return DataTables::of($data)
                    ->addColumn('action', function($data){
                        $button = '<a href="animal/'.$data->id.'/edit" class="edit btn btn-primary btn-sm">Edit</a>';
                        $button .= '&nbsp;&nbsp;&nbsp;<a href="animal/destroy/'.$data->id.'" class="delete btn btn-danger btn-sm">Delete</a>';
                        return $button;
                    })
                    ->rawColumns(['action'])
                    ->make(true);
        }
        return view('animals.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $rescuer = Rescuer::pluck('rescuer_name', 'id');
        $employee = Personnel::pluck('personnel_name', 'id');
        $injure = Injury::pluck('injury_name', 'id');
      
        return View::make('animals.create', compact('rescuer','injure','employee'));
    }
    

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {   
        $this->validate($request, [
            'animal_name'=>'required|min:2|max:25',
            'animal_type'=>'required',
            'animal_breed'=>'required|min:2|max:25',
            'animal_gender'=>'required',
            'animal_age'=>'required|numeric',
            'img_path'=>'required',
            'rescue_date' => 'required',
            'rescuer_id'=>'required'
        ], [
            'required' => 'Empty Field is not Acceptable',
            'min' => 'Entered data is too short!',
            'max' => 'Entered data is too long!',
            'numeric' => 'Entered data is not a number',
        ]);

      

        if($request->hasFile('img_path'))
        {
            $img_path = $request->file('img_path')->getClientOriginalName();
            $request->file('img_path')->storeAs('public/images', $img_path);
        }
        $animal = new Animal([
            'animal_type' => $request->get('animal_type'),
            'animal_breed' => $request->get('animal_breed'),
            'animal_name' => $request->get('animal_name'),
            'animal_gender' => $request->get('animal_gender'),
            'animal_age' => $request->get('animal_age'),
            'rescue_date' => $request->get('rescue_date'),
            'img_path' => 'storage/images/'.$img_path,
            'rescuer_id' => $request->get('rescuer_id'),
            'personnel_id' => $request->get('personnel_id'),
        ]); 
        if (empty($request->input('injury_id')))
        {
            $animal->adopt_stat = 'adoptable';
            $animal->save();

        }
        else
        {
            $animal->adopt_stat = 'pending';
            $animal->save();
            foreach ($request->injury_id as $injury_id) {
            DB::table('animal_injury')->insert(
                ['injury_id' => $injury_id,
                'animal_id' => $animal->id]
            );
            }
        }

        Event::dispatch(new QuoteCreated($animal));

        return redirect()->route('animal.index')->with('success', 'Animal Added');
        // $input = $request->all();
        // // dd($input);
        // // dd($request->file('img_path')->getClientOriginalName());
        // // dd($request->hasFile('img_path'));
        // // dd($request->all());
        // if($request->hasFile('img_path')){
        //     $animal_img = $request->file('img_path')->getClientOriginalName();
        //     $request->file('img_path')->storeAs('public/images', $animal_img);
        //     $input['img_path'] = 'storage/images/'.$animal_img;
        // }
        // $animal = Animal::create($input);
        // $animalid = Animal::find(DB::table('animals')->latest()->first()->id);
        // dd($animalid);
        // if(empty($request->injury_id))
        //     {$animalid = Animal::find(DB::table('animals')->latest()->first()->id);
        //     $animalid->adopt_stat = 'ready';
        //     $animalid->save();
        // }
        // else
        //     {$animalid = Animal::find(DB::table('animals')->latest()->first()->id);
        //     $animalid->adopt_stat = 'not ready';
        //     $animalid->save();
        // foreach($request->injury_id as $injury_id)
        //     {DB::table('animal_injury')->insert(['injury_id' => $injury_id, 'animal_id' => $animal->id]);}}
        
        // return Redirect::to('animals')->with('success','Record created!');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $animals = DB::table('animals')
        ->join('rescuers', 'rescuers.id', 'animals.rescuer_id')
        ->join('animal_injury', 'animal_injury.animal_id', 'animals.id')
        ->join('injuries','injuries.id', 'animal_injury.injury_id')
        ->select('animals.*', 'rescuers.rescuer_name', 'injuries.injury_name')->get();

        $animal = Animal::find($id);
        $animal_injury = DB::table('animal_injury')->where('animal_id', $id)->pluck('injury_id')->toArray();
        // dd($animal_injury);
        $injury = Injury::pluck('injury_name', 'id');
        $employee = Personnel::pluck('personnel_name', 'id');
        $rescuer = Rescuer::pluck('rescuer_name', 'id');
        // dd($injury);
        // $injury = Injury::pluck('injury_name', 'id');
        return View::make('animals.edit', compact('rescuer', 'animal', 'animal_injury', 'injury','employee'));    
        // return View('animals.edit',compact('rescuer','animal'));
        
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'animal_name'=>'required|min:2|max:25',
            'animal_type'=>'required',
            'animal_breed'=>'required|min:2|max:25',
            'animal_gender'=>'required',
            'animal_age'=>'required|numeric',
            'rescue_date' => 'required',
            'rescuer_id'=>'required'
        ], [
            'required' => 'Empty Field is not Acceptable',
            'min' => 'Entered data is too short!',
            'max' => 'Entered data is too long!',
            'numeric' => 'Entered data is not a number',
        ]);

        $animal = Animal::find($id);
        $input = $request->all();
        $injury_ids = $request->input('injury_id'); 

        if($request->hasFile('img_path')){
            $animal_img = $request->file('img_path')->getClientOriginalName();
            $request->file('img_path')->storeAs('public/images', $animal_img);
            $input['img_path'] = 'storage/images/'.$animal_img;
        }
        $animal->update($input);

        if(empty($injury_ids))
        {
            DB::table('animal_injury')->where('animal_id',$id)->delete();
            $animal->adopt_stat = 'adoptable';
            $animal->save();
        }

        else
        {
            foreach($injury_ids as $injury_id)
            {
                DB::table('animal_injury')->insert(['injury_id' => $injury_id, 'animal_id' => $id]);
                $animal->adopt_stat = 'pending';
                $animal->save();
            }
        }   
        // dd($input);
        // $animal->update($request->all());
        return View('animals.index')->with('success','Record updated!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        DB::table('animal_injury')->where('animal_id', $id)->delete();
        $animal = Animal::find($id);
        $animal->delete();
        return View('animals.index')->with('success','Record Deleted!');
    }
}