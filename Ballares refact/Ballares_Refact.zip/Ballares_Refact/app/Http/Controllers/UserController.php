<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\Models\User;
use App\Models\Personnel;
use App\Models\Adopter;
use App\Models\Rescuer;
use App\Models\Animal;
use DB;
use App\Charts\AdoptedAnimalsChart; 
use App\Charts\InjuryDiseaseChart; 
use App\Charts\RescuedChart;



class UserController extends Controller
{

    // public function getSignin(){
    //     return view('users.signin');
    // }

    // public function postSignin(Request $request){
    //     $this->validate($request, [
    //         'email' => 'email| required',
    //         'password' => 'required| min:4'
    //     ]);
         
     //    if(Auth()->attempt(array('email' => $request->email, 'password' => $request->password, 'status'=> 0)))
     //    {
     //        if(Auth()->user()->role == 'admin')
     //        {
     //            return redirect()->route('user.dashboard');
     //        }
     //        elseif(Auth()->user()->role == 'rescuer')
     //        {
     //            return redirect()->route('user.profile');
     //        }
     //        elseif(Auth()->user()->role == 'employee')
     //        {
     //            return redirect()->route('user.profile'); 
     //        }
     //        elseif(Auth()->user()->role == 'adopter')
     //        {
     //            return redirect()->route('user.profile');    
     //        }
     //        else{
     //            return redirect()->back();
     //        }
     //    }
     //    else{
     //        return redirect()->route('user.signin');
     //    }

     // }

    public function getProfile(){
        $animal_injury = DB::table('animals')
        ->leftJoin('animal_injury', 'animal_injury.animal_id', 'animals.id')
        ->leftJoin('injuries','injuries.id', 'animal_injury.injury_id')
        ->select('animal_injury.animal_id', 'animal_injury.injury_id', 'injuries.injury_name')->get();
        $user = Auth::user()->role;
        if($user == 'employee')
        {
            $profile = Personnel::where('user_id',Auth::id())->first();
            $query = Animal::with('Personnels')->where('personnel_id', $profile->id)->get();
        }
        elseif($user == 'rescuer')
        {
            $profile = Rescuer::where('user_id',Auth::id())->first();
            $query = Animal::with('rescuers')->where('rescuer_id', $profile->id)->get();

        }
        elseif($user == 'adopter')
        {
            $profile = Adopter::where('user_id',Auth::id())->first();
            $query = Animal::with('adopters')->where('adopter_id', $profile->id)->get();
            
        }
        // return view('users.profile', compact('query', 'animal_injury', 'profile'));
        // $animal_injury = DB::table('animals')
        // ->leftJoin('animal_injury', 'animal_injury.animal_id', 'animals.id')
        // ->leftJoin('injuries','injuries.id', 'animal_injury.injury_id')
        // ->select('animal_injury.animal_id', 'animal_injury.injury_id', 'injuries.injury_name')->get();
        // $user = Auth::user()->role;
        // if($user == 'employee')
        // {
        //     $profile = Personnel::where('user_id',Auth::id())->first();
        //     $query = Animal::with('Personnels')->where('personnel_id', $profile->id)->get();
        // }
        // elseif($user == 'rescuer')
        // {
        //     $profile = Rescuer::where('user_id',Auth::id())->first();
        //     $query = Animal::with('rescuers')->where('rescuer_id', $profile->id)->get();

        // }
        // elseif($user == 'adopter')
        // {
        //     $profile = Adopter::where('user_id',Auth::id())->first();
        //     $query = Animal::with('adopters')->where('adopter_id', $profile->id)->get();
            
        // }
        return view('users.profile', compact('query', 'animal_injury', 'profile'));
    }

    public function getDashboard() 
    {



        $adate = DB::table('adopters')
        ->join('animals','adopters.id','=','adopter_id')
        ->select(DB::raw('count(adopters.adopted_date) AS total'), DB::raw('MONTHNAME(adopters.adopted_date) as month'))
        ->groupBy('month')
        ->pluck(DB::raw('count(month) AS total'), 'month')
        ->all();
        $adoptedanimalsChart = new AdoptedAnimalsChart;
        $dataset = $adoptedanimalsChart->labels(array_keys($adate));
        $dataset= $adoptedanimalsChart->dataset('Adopted Per Month', 'horizontalBar', array_values($adate));
        $dataset= $dataset->backgroundColor(collect(['#7158e2','#3ae374', '#ff3838',"#FF851B", "#7FDBFF", "#B10DC9", "#FFDC00", "#001f3f", "#39CCCC", "#01FF70", "#85144b", "#F012BE", "#3D9970", "#111111", "#AAAAAA"]));
        $adoptedanimalsChart->options([
            'responsive' => true,
            'legend' => ['display' => true],
            'tooltips' => ['enabled'=>true],
            'aspectRatio' => 1,
            'scales' => [
                'yAxes'=> [[
                            'display'=>true,
                            'ticks'=> ['beginAtZero'=> true],
                            'gridLines'=> ['display'=> true],
                          ]],
                'xAxes'=> [[
                            'categoryPercentage'=> 0.8,
                            'barPercentage' => 1,
                            'ticks' => ['beginAtZero' => true],
                            'gridLines' => ['display' => true],
                            'display' => true
                          ]],
            ],
        ]);

        $rescueddate = DB::table('animals')
        ->join('rescuers','rescuers.id','=','rescuer_id')
        ->select(DB::raw('count(animals.rescue_date) AS total'), DB::raw('MONTHNAME(animals.rescue_date) as month'))
        ->groupBy('month')
        ->pluck(DB::raw('count(month) AS total'), 'month')
        ->all();
        $rescuedChart = new RescuedChart;
        $dataset = $rescuedChart->labels(array_keys($rescueddate));
        $dataset= $rescuedChart->dataset('Rescued Per Month', 'bar', array_values($rescueddate));
        $dataset= $dataset->backgroundColor(collect(['#7158e2','#3ae374', '#ff3838',"#FF851B", "#7FDBFF", "#B10DC9", "#FFDC00", "#001f3f", "#39CCCC", "#01FF70", "#85144b", "#F012BE", "#3D9970", "#111111", "#AAAAAA"]));
        $rescuedChart->options([
            'responsive' => true,
            'legend' => ['display' => true],
            'tooltips' => ['enabled'=>true],
            'aspectRatio' => 1,
            'scales' => [
                'yAxes'=> [[
                            'display'=>true,
                            'ticks'=> ['beginAtZero'=> true],
                            'gridLines'=> ['display'=> true],
                          ]],
                'xAxes'=> [[
                            'categoryPercentage'=> 0.8,
                            'barPercentage' => 1,
                            'ticks' => ['beginAtZero' => true],
                            'gridLines' => ['display' => true],
                            'display' => true
                          ]],
            ],
        ]);

        $injurydisease = DB::table('animals')->leftJoin('animal_injury', 'animals.id', 'animal_injury.animal_id')->leftJoin('injuries', 'injuries.id', 'animal_injury.injury_id')->whereNotNull('injuries.id')->groupBy('injury_name')->pluck(DB::raw('count(animal_name)'),'injury_name')->all();
        $injurydiseaseChart = new InjuryDiseaseChart;
        $dataset = $injurydiseaseChart->labels(array_keys($injurydisease));
        $dataset= $injurydiseaseChart->dataset('Common Diseases/Injuries', 'pie', array_values($injurydisease));
        $dataset= $dataset->backgroundColor(collect(['#7158e2','#3ae374', '#ff3838',"#FF851B", "#7FDBFF", "#B10DC9", "#FFDC00", "#001f3f", "#39CCCC", "#01FF70", "#85144b", "#F012BE", "#3D9970", "#111111", "#AAAAAA"]));
        $injurydiseaseChart->options([
            'responsive' => true,
            'legend' => ['display' => true],
            'tooltips' => ['enabled'=>true],
            'aspectRatio' => 1,
            'scales' => [
                'yAxes'=> [[
                            'display'=>false,
                            'ticks'=> ['beginAtZero'=> false],
                            'gridLines'=> ['display'=> false],
                          ]],
                'xAxes'=> [[
                            'categoryPercentage'=> 0.8,
                            'barPercentage' => 1,
                            'ticks' => ['beginAtZero' => false],
                            'gridLines' => ['display' => false],
                            'display' => false
                          ]],
            ],
        ]);

        $admin = User::find(Auth::id());

        return view('users.multiuser', compact('admin', 'adoptedanimalsChart', 'rescuedChart', 'injurydiseaseChart'));

    }

    public function adminEdit($id)
    {
        $user = User::find($id);
        return view('users.edit', compact('user'));
    }

    public function adminUpdate(Request $request, $id)
    {
        $user = User::find($id);
        $user->update($request->all());
        return redirect()->route('multiuser')->with('success', 'UPDATED!');
    }

    // public function getSignup()
    // {
    //     return view('users.signup');
    // }

    // public function postSignup(Request $request)
    // {
    //     $this->validate($request, [
    //         'email' => 'email|required|unique:users',
    //         'password' => 'required|min:4'
    //     ]);

    //     $user = new User([
    //     	'name' => $request->input('adopter_name'),
    //         'email' => $request->input('email'),
    //         'role' => 'adopter',
    //         'password' => bcrypt($request->input('password'))
    //     ]);
    //     $user->save();

    //     $request->input('type') == 'adopter';
    //     {
    //         $adopter = new Adopter;
    //         $adopter->user_id = $user->id;
    //         $adopter->adopter_name = $request->adopter_name;
    //         $adopter->adopter_contact = $request->adopter_contact;
    //         $adopter->adopter_address = $request->adopter_address;
    //         $adopter->adopter_age = $request->adopter_age;
    //         $adopter->adopter_gender = $request->adopter_gender;
    //         $adopter->save();
    //     }

    //     Auth::login($user);
    //     return redirect()->route('user.profile');
    // }

    // public function getLogout()
    // {
    //     Auth::logout();
    //     return redirect()->route('home');
    // }

    public function back()
    {
        return redirect()->back();
    }

    public function getUser() 
    {
        $users = DB::table('users')->where('role','<>','admin')->get();
        return view('users.disable', compact('users'));
    }

    public function userBan($id)
    {
        $user = User::find($id);
        if($user->status == 0)
        {
            $user->status = 1;
            $user->save();
        }
        else
        {
            $user->status = 0;
            $user->save();
        }
        return redirect()->back();
    }

    
}