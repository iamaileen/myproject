<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Adopter;
use App\Models\Animal;
use View;
use Redirect;
use DB;
use Auth;
use App\Models\User;


class AdopterController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $adopters = DB::table('adopters')
        ->select('adopters.*')
        ->get();

        $animals = DB::table('animals')
        ->leftJoin('adopters', 'adopters.id', 'animals.adopter_id')
        ->select('animals.id', 'animals.animal_name', 'animals.adopter_id')
        ->get();

        // dump($animals);
        // dd($adopters);


        return View::make('adopters.index',compact('adopters', 'animals'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        // dd($adopt_animal);
        $adopt_animal = DB::table('animals')
        ->leftJoin('animal_injury', 'animal_injury.animal_id', 'animals.id')
        ->leftJoin('injuries', 'injuries.id', 'animal_injury.injury_id')
        ->select('animals.id', 'injuries.injury_name', 'animals.animal_name')
        ->where('animals.adopt_stat', 'adoptable')
        ->get();

        // dd($adopt_animal);
        return View::make('adopters.create', compact('adopt_animal'));  
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
        public function store(Request $request)
        {
            // dd($request->all());
            $this->validate($request, [
                'adopter_name'=>'required|min:2|max:25',
                'adopter_address'=>'required|min:5|max:25',
                'adopter_age'=>'required|numeric',
                'adopter_gender'=>'required',
                
                'id'=>'required',
            ], [
                'required' => 'Empty Field is not Acceptable',
                'min' => 'Entered data is too short!',
                'max' => 'Entered data is too long!',
                'numeric' => 'Entered data is not a number',
            ]);

        $user = new User([
            'name' => $request->input('adopter_name'),
            'email' => $request->input('email'),
            'role' => 'adopter',
            'password' => bcrypt($request->input('password'))
        ]);
        $user->save();

            $adopter = new Adopter;
            $adopter->user_id = $user->id;
            $adopter->adopter_name = $request->adopter_name;
            $adopter->adopter_contact = $request->adopter_contact;
            $adopter->adopter_address = $request->adopter_address;
            $adopter->adopter_age = $request->adopter_age;
            $adopter->adopter_gender = $request->adopter_gender;
            $adopter->adopted_date = $request->adopted_date;
            $adopter->save();


//          $last = DB::table('adopters')->latest()->first();
//             // dd($last->id);
//             // dd($request->id);
//             foreach($request->id as $animal_id)
//             {
//                 $animal = Animal::find($animal_id);
//                 $animal->adopter_id = $last->id;
//                 $animal->adopt_stat = 'adopted';
//                 $animal->save();
//             }


            $last = Adopter::all()->last();
            // dd($last->id);
            // dd($request->id);
            foreach($request->id as $animal_id)
            {
                $animal = Animal::find($animal_id);
                $animal->adopter_id = $last->id;
                $animal->adopt_stat = 'adopted';
                $animal->save();
            }

            return Redirect::to('adopters')->with('success','Adopter Added!');
            // dd($the);
                
        }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $adopter = Adopter::find($id);

        $animal_list = DB::table('animals')->where('adopt_stat', 'adoptable')->orWhere('adopter_id', $id)
        ->pluck('animal_name', 'animals.id');

        $adopted_animal = DB::table('adopters')
        ->leftJoin('animals', 'animals.adopter_id', 'adopters.id')
        ->where('adopters.id', $id)
        ->pluck('animals.id')->toArray();;
        
        // dd($adopter, $animal_list, $adopted_animal);
        
        return View::make('adopters.edit', compact('adopter', 'adopted_animal', 'animal_list'));  
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'adopter_name'=>'required|min:2|max:25',
            'adopter_address'=>'required|min:5|max:25',
            'adopter_age'=>'required|numeric',
            'adopter_gender'=>'required',

        ], [
            'required' => 'Empty Field is not Acceptable',
            'min' => 'Entered data is too short!',
            'max' => 'Entered data is too long!',
            'numeric' => 'Entered data is not a number',
        ]);

        $adopter = Adopter::find($id);
        $input = $request->all();
        // dd($input);
        $adopted_ids = $request->input('adopted_id');
        // dd($adopted_ids);
        $animal_list = DB::table('animals')->where('adopt_stat', 'adoptable')->orWhere('adopter_id', $id)
        ->pluck('animals.id', 'animal_name');
        // dd($animal_list);
        // if(empty($adopted_ids))
        {
            $adopter->update($input);
            foreach($animal_list as $animal)
            {  
                DB::table('animals')
                ->where('animals.adopter_id', $id)
                ->update(['adopter_id' => null, 'adopt_stat' => 'adoptable']);
            } 
        }

        // else
        {
            $adopter->update($input);
            foreach($adopted_ids as $adopted_id)
            {
                // dump($adopted_id);
                DB::table('animals')
                ->where('animals.id', $adopted_id)
                ->update(['adopter_id' => $id, 'adopt_stat' => 'adopted']);
            }
        }

        if(Auth::user()->role == "adopter")
        {
            return redirect()->route('user.multiuser')->with('success', 'Profile Updated');
        }
        else
        { 
            return redirect()->route('adopters.index')->with('success', 'Record Added');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        DB::table('animals')->where('animals.adopter_id', $id)
        ->update(['adopter_id' => null, 'adopt_stat' => 'adoptable']);

        $adopter = Adopter::find($id);
        $adopter->delete();
        return Redirect::to('adopters')->with('success','Record Deleted!');
    }
}
