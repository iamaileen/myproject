<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Personnel;

class DataPersonnelController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(request()->ajax()) {
            return datatables()->of(Personnel::select('*'))
            ->addColumn('Actions', 'data_personnel.action')
            ->rawColumns(['Actions'])
            ->addIndexColumn()
            ->make(true);
        }
        return view('data_personnel.index');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $personnel = $request->id;
        $personnel   =   Personnel::updateOrCreate(
                    [
                     'id' => $personnel
                    ],
                    [
                    'personnel_name' => $request->personnel_name, 
                    'personnel_role' => $request->personnel_role,
                    'personnel_contact' => $request->personnel_contact,
                    'personnel_address' => $request->personnel_address,
                    'personnel_gender' => $request->personnel_gender,
                    
                    ]);        
        return Response()->json($personnel);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {
        $where = array('id' => $request->id);
        $personnel  = Personnel::where($where)->first();
     
        return Response()->json($personnel);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        $personnel = Personnel::where('id',$request->id)->delete();
        return Response()->json($personnel);
    }
}
