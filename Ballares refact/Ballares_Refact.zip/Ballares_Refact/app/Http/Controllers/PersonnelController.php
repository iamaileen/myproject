<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Personnel;
use View;
use Redirect;
use DB;
use Auth;
use DataTables;
use App\Models\User;


class PersonnelController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if($request->ajax())
        {
            $data = DB::table('personnels')
            ->select('personnels.id', 'personnel_name', 'personnel_role', 'personnel_contact', 'personnel_address', 'personnel_gender')
            ->get();
            return DataTables::of($data)
                    ->addColumn('action', function($data){
                        $button = '<a href="personnels/'.$data->id.'/edit" class="edit btn btn-primary btn-sm">Edit</a>';
                        $button .= '&nbsp;&nbsp;&nbsp;<a href="personnels/destroy/'.$data->id.'" class="delete btn btn-danger btn-sm">Delete</a>';
                        return $button;
                    })
                    ->rawColumns(['action'])
                    ->make(true);
        }
        return view('personnels.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return View::make('personnels.create');    
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'personnel_name'=>'required|min:5|max:25',
            // 'personnel_role'=>'required',
            'personnel_gender'=>'required',
            'personnel_address'=>'required|min:5|max:25',
            'personnel_contact'=>'required|numeric',
        ], [
            'required' => 'Empty Field is not Acceptable',
            'min' => 'Entered data is too short!',
            'max' => 'Entered data is too long!',
            'numeric' => 'Entered data is not a number',
        ]);

        // $user = new User([
        //     'name' => $request->input('personnel_name'),
        //     'email' => $request->input('email'),
        //     'role' => 'personnel',
        //     'password' => bcrypt($request->input('password'))
        // ]);
        // $user->save();



        // dd($request->all());
        Personnel::create($request->all());
        return Redirect::to('personnels')->with('success','Record Added!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $personnel = Personnel::find($id);
        return View('personnels.edit',compact('personnel'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'personnel_name'=>'required',
            // 'personnel_role'=>'required',
            'personnel_address'=>'required',
            'personnel_contact'=>'required',
            'personnel_gender'=>'required',
        ]);
        
        $personnel = Personnel::find($id);
        $input = $request->all();
        // $input = $request->all();
        // dd($input);
        // dd($input);
        
        $personnel->update($input);
        if(Auth::user()->role == "personnel")
        {
            return redirect()->route('user.multiuser')->with('success', 'Profile Updated');
        }
        else
        { 
            return redirect()->route('personnels.index')->with('success', 'Record Added');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $personnels = Personnel::findOrFail($id);
        $personnels->delete();
        return Redirect::to('personnels')->with('success','Record Deleted!');
    }
}
