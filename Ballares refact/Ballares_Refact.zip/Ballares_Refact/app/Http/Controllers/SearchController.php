<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Spatie\Searchable\Search;
use App\Models\Animal;

class SearchController extends Controller
{
    public function search(Request $request)
    {
        // dd($request);
    	$results = (new Search())
   		->registerModel(Animal::class, 'animal_type', 'animal_breed', 'animal_name',
            'animal_gender', 'animal_age', 'rescue_date','adopt_stat')
   		->search($request->input('search'));
   		return view('search', compact('results'));
    }

    public function show($id)
    {
    	$animal = \App\Models\Animal::find($id);
    	return view('show', compact('animal'));
    }
}