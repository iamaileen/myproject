<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Injury;

class DataInjuryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(request()->ajax()) {
            return datatables()->of(Injury::select('*'))
            ->addColumn('Actions', 'data_injury.action')
            ->rawColumns(['Actions'])
            ->addIndexColumn()
            ->make(true);
        }
        return view('data_injury.index');
    }

        /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */

    public function store(Request $request)
    {
        $injury = $request->id;
        $injury   =   Injury::updateOrCreate(
                    [
                     'id' => $injury
                    ],
                    [
                    'injury_name' => $request->injury_name, 
                    'injury_type' => $request->injury_type,
                    'injury_description' => $request->injury_description,
                    
                    ]);        
        return Response()->json($injury);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {
        $where = array('id' => $request->id);
        $injury  = Injury::where($where)->first();
     
        return Response()->json($injury);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        $injury = Injury::where('id',$request->id)->delete();
        return Response()->json($injury);
    }
}
