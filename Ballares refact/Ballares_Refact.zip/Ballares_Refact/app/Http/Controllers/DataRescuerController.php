<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Rescuer;

class DataRescuerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(request()->ajax()) {
            return datatables()->of(Rescuer::select('*'))
            ->addColumn('Actions', 'data_rescuer.action')
            ->rawColumns(['Actions'])
            ->addIndexColumn()
            ->make(true);
        }
        return view('data_rescuer.index');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $rescuer = $request->id;
        $rescuer   =   Rescuer::updateOrCreate(
                    [
                     'id' => $rescuer
                    ],
                    [
                    'rescuer_name' => $request->rescuer_name, 
                    'rescuer_address' => $request->rescuer_address,
                    'rescuer_contact' => $request->rescuer_contact,
                    'rescuer_age' => $request->rescuer_age,
                    'rescuer_gender' => $request->rescuer_gender,
                    
                    ]);        
        return Response()->json($rescuer);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {
        $where = array('id' => $request->id);
        $rescuer  = Rescuer::where($where)->first();
     
        return Response()->json($rescuer);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        $rescuer = Rescuer::where('id',$request->id)->delete();
        return Response()->json($rescuer);
    }
}
