<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Animal;
use View;
use DB;

class LandingController extends Controller
{
    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $animals = DB::table('animals')
        ->leftJoin('rescuers', 'rescuers.id', 'animals.rescuer_id')
        ->select('animals.*', 'rescuers.rescuer_name')
        ->where('animals.adopt_stat', 'adoptable')
        ->get();
        // dd($animals);
        
        $animal_injury = DB::table('animals')
        ->leftJoin('animal_injury', 'animal_injury.animal_id', 'animals.id')
        ->leftJoin('injuries','injuries.id', 'animal_injury.injury_id')
        ->select('animal_injury.animal_id', 'animal_injury.injury_id', 'injuries.injury_name')->get();
        // dd($animal_injury);

        return View::make('welcome',compact('animals', 'animal_injury')); 
    }

    public function search(Request $request)
    {
        $search = $request->get('search');
        if($search != "")
        {
            $animals = DB::table('animals')
            ->whereNested(function($query) use ($search){$query->where('adopt_stat','adoptable');
                $query->where('animal_breed','like','%'.$search.'%')
                ->orWhere('animal_name','like','%'.$search.'%')
                ;})
            ->select('animals.*','rescuer_name')
            ->leftJoin('rescuers','rescuers.id','=','animals.rescuer_id')
            ->orderBy('id','asc')->get();

            if(count($animals)>0)
            {
                return View::make('search', compact('animals'));}
            else
            {
                return View::make('search', compact('animals'));}
            }

        else
        {
            $animals = DB::table('animals')
            ->where('adopt_stat','adoptable')
            ->select('animals.*','rescuer_name')
            ->leftJoin('rescuers','rescuers.id','=','animals.rescuer_id')
            ->orderBy('id','asc')->get();
            return View::make('welcome', compact('animals'));}
    }
}
