<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Animal;

class DataAnimalController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(request()->ajax()) {
            return datatables()->of(Animal::select('*'))
            ->addColumn('Actions', 'data_animal.action')
            ->rawColumns(['Actions'])
            ->addIndexColumn()
            ->make(true);
        }
        return view('data_animal.index');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $animal = $request->id;
        $animal  =   Animal::updateOrCreate(
                    [
                     'id' => $animal
                    ],
                    [
                    'animal_name' => $request->animal_name, 
                    'animal_type' => $request->animal_type,
                    'animal_breed' => $request->animal_breed,
                    'animal_gender' => $request->animal_gender,
                    'animal_age' => $request->animal_age,
                    'img_path' => $request->img_path,
                    
                    
                    ]);        
        return Response()->json($animal);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {
        $where = array('id' => $request->id);
        $animal  = Animal::where($where)->first();
     
        return Response()->json($animal);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        $animal = Animal::where('id',$request->id)->delete();
        return Response()->json($animal);
    }
}
