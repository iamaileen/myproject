<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Injury extends Model
{
    use HasFactory;
    protected $fillable = ['injury_name', 'injury_type', 'injury_description'];
    public $timestamps=false;
    protected $guarded = ['id'];

    public function animals()
    {
    	return $this->belongsToMany('App\Models\Animals');
    }
}
