<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Searchable\Searchable;
use Spatie\Searchable\SearchResult;
use Laravelista\Comments\Commentable;

class Animal extends Model implements Searchable
{
    use HasFactory;

    use Commentable;


    protected $fillable = ['animal_name', 'animal_type', 'animal_breed', 'animal_gender', 'animal_age', 'img_path', 'rescuer_id', 'personnel_id', 'personnel_id', 'rescue_date', 'adopt_stat'];
    public $timestamps=false;
    protected $guarded = ['id'];
    public $searchableType = 'Animal List';
    

    public function injury()
    {
    	return $this->belongsToMany('App\Models\Injury');
    }

    public function personnels()
    {
    	return $this->belongsTo('App\Models\Personnel');
    }

    public function rescuers()
    {
    	return $this->belongsTo('App\Models\Rescuer');
    }

    public function adopters() 
    {
        return $this->belongsTo('App\Models\Adopter');
    }

    public function getSearchResult(): SearchResult
    {
        $url = route('show', $this->id);
        // dd($this->animal_name);
        return new \Spatie\Searchable\SearchResult($this, $this->animal_name, $url);
    }
}