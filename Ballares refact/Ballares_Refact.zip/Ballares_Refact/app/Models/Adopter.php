<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Adopter extends Model
{
    use HasFactory;
    protected $fillable = ['adopter_name', 'adopter_contact', 'adopter_address', 'adopter_age', 'adopter_gender','user_id'];
    public $timestamps=false;
    protected $guarded = ['id'];

    public function animals()
    {
    	return $this->hasMany('App\Models\Animal');
    }
}
