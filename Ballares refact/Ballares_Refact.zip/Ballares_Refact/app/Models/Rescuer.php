<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Rescuer extends Model
{
    use HasFactory;
    protected $fillable = ['rescuer_name', 'rescuer_address', 'rescuer_contact', 'rescuer_age',
        'rescuer_gender', 'user_id'];
    public $timestamps=false;
    protected $guarded = ['id'];

    public function animals()
    {
    	return $this->hasMany('App\Models\Animal');
    }
}
