<?php

namespace App\Listeners;

use App\Events\QuoteCreated;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Support\Facades\Mail;

class SendUserNotification
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  QuoteCreated  $event
     * @return void
     */
    public function handle(QuoteCreated $event)
    {
        $id = $event->id;
        $animal_type = $event->animal_type;
        $animal_breed = $event->animal_breed;
        $animal_name = $event->animal_name;
        $animal_gender = $event->animal_gender;
        $animal_age = $event->animal_age;
        $rescue_date = $event->rescue_date;
        $email = 'aileenballares21@gmail.com';
        Mail::send(
            'email_send',
            ['id'=>$id, 'animal_type'=>$animal_type, 'animal_breed'=>$animal_breed, 'animal_name'=>$animal_name, 'animal_gender'=>$animal_gender, 'animal_age'=>$animal_age, 'rescue_date'=>$rescue_date],
            function($message) use($email) {
                $message->from('admin@shelter.com','Admin');
                $message->to($email, 'You');
                $message->subject('New Animal Rescued!');
            }
        );
    }
}
